/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006, 2007  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.cells.mediatedpattrec.gui;

import java.awt.Color;
import java.awt.Graphics;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;

import com.oat.Algorithm;
import com.oat.AlgorithmEpochCompleteListener;
import com.oat.Problem;
import com.oat.Solution;
import com.oat.domains.cells.mediatedpattrec.algorithms.MediatedClonalSelection;
import com.oat.domains.cells.opt.Cell;
import com.oat.domains.cells.opt.problems.Optimisation;
import com.oat.domains.cells.patrec.problems.PatternRecognition;
import com.oat.explorer.gui.AlgorithmChangedListener;
import com.oat.explorer.gui.ClearEventListener;
import com.oat.explorer.gui.plot.GenericProblemPlot;
import com.oat.utils.BinaryDecodeMode;
import com.oat.utils.BitStringUtils;

/**
 * Description: 
 *  
 * Date: 06/11/2007<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class MediatedClonalSelectionViewer extends GenericProblemPlot
	implements AlgorithmEpochCompleteListener, ClearEventListener, AlgorithmChangedListener
{	
	protected MediatedClonalSelection algorithm;
	
	protected PatternRecognition problem;	
	protected LinkedList<Color> bcellColours;
	protected LinkedList<Color> tcellColours;
	
	
	public MediatedClonalSelectionViewer()
	{
		setName("Mediated View");
		bcellColours = new LinkedList<Color>();
		tcellColours = new LinkedList<Color>();
	}
	
	@Override
	public void algorithmChangedEvent(Algorithm a)
	{
		synchronized(this)
		{			
			algorithm = null;
			clear();
		
			if(a instanceof MediatedClonalSelection)
			{
				algorithm = (MediatedClonalSelection) a;
			}
		}
		
		repaint();
	}
	
	@Override
	public void problemChangedEvent(Problem p)
	{
		synchronized(this)
		{			
			clear();
		
			if(p instanceof PatternRecognition)
			{
				problem = (PatternRecognition) p;
			}
		}
		
		repaint();
	}

	@Override
	public void clear()
	{
		synchronized(this)
		{
			bcellColours.clear();
			tcellColours.clear();
		}
	}

	@Override
	public <T extends Solution> void epochCompleteEvent(Problem p, LinkedList<T> currentPop)
	{		
		synchronized(this)
		{
			if(problem == null || algorithm == null)
			{
				return;
			}					
			// b cells
			populateColourList(algorithm.getBCells(), bcellColours);
			// t cells
			populateColourList(algorithm.getTCells(), tcellColours);
			// connections
		}
		
		repaint();
	}	
	
	protected void populateColourList(LinkedList<Cell> cells, LinkedList<Color> colours)
	{
		colours.clear();
		
		if(cells == null)
		{
			return;
		}
		
		// make sure they all have decoded information
		for (Cell c : cells)
		{
			if(c.getDecodedData() == null)
			{
				double [] data = BitStringUtils.decode(BinaryDecodeMode.GrayCode, c.getData(), Optimisation.minmax);
				c.setDecodedData(data);
			}
		}
		
		// order them in some way
		Collections.sort(cells, new ColourCompariator());
		
		for (Cell c : cells)
		{
			Color col = vectorToColor(c.getDecodedData());
			colours.add(col);
		}

	}
	
	/**
	 * 
	 * Description: 
	 * Compares its two arguments for order.  Returns a negative integer,
     * zero, or a positive integer as the first argument is less than, equal
     * to, or greater than the second.<p>
	 * Date: 07/11/2007<br/>
	 * @author Jason Brownlee 
	 *
	 * <br/>
	 * <pre>
	 * Change History
	 * ----------------------------------------------------------------------------
	 * 
	 * </pre>
	 */
	protected class ColourCompariator implements Comparator<Cell>
	{
		@Override
		public int compare(Cell o1, Cell o2)
		{
			double [] v1 = o1.getDecodedData();
			double [] v2 = o2.getDecodedData();

			int index1 = 0;
			for (int i = 1; i < v1.length; i++)
			{
				if(v1[i] > v1[index1])
				{
					index1 = i;
				}
			}
			
			int index2 = 0;
			for (int i = 1; i < v2.length; i++)
			{
				if(v2[i] > v2[index2])
				{
					index2 = i;
				}
			}
			
			if(v1[index1] < v2[index2])
			{
				return -1;
			}
			else if(v1[index1] > v2[index2])
			{
				return +1;
			}
			
			return 0;
		}		
	}
	
	
	protected Color vectorToColor(double [] v)
	{		
		return new Color((float)v[0], (float)v[1], (float)v[2]);
	}

	@Override
	protected void paintComponent(Graphics g)
	{
		synchronized(this)
		{
			if(problem == null)
			{
				super.plotUnavailable(g);
				return;
			}
			
			// clear
			g.setColor(Color.WHITE);
			g.fillRect(0,0,getWidth(),getHeight());
			
			// calculate things			
			int height = (int) Math.floor((double)getHeight() / 2.0); 
			
			// draw b cells
			int bwidth = (int) Math.floor((double)getWidth() / bcellColours.size());
			for (int i = 0; i < bcellColours.size(); i++)
			{
				drawColor(g, bcellColours.get(i), i*bwidth, 0, bwidth, height);				
			}
			
			// draw t cells
			int twidth = (int) Math.floor((double)getWidth() / tcellColours.size());
			for (int i = 0; i < tcellColours.size(); i++)
			{
				drawColor(g, tcellColours.get(i), i*twidth, getHeight()-height, twidth, height);				
			}			
		}
	}	
	
	public void drawColor(Graphics g, Color c, int x, int y, int width, int height)
	{
		g.setColor(c);
		g.fillRect(x, y, width, height);				
		g.setColor(Color.BLACK);
		g.drawRect(x, y, width, height);
	}	
}
