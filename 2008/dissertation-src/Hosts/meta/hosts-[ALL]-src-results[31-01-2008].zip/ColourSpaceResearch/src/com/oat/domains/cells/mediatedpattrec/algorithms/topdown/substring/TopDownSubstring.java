/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006, 2007  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.cells.mediatedpattrec.algorithms.topdown.substring;

import java.util.Collections;
import java.util.LinkedList;
import java.util.Random;

import com.oat.EpochAlgorithm;
import com.oat.InvalidConfigurationException;
import com.oat.Problem;
import com.oat.domains.cells.mediatedpattrec.CellUtils;
import com.oat.domains.cells.mediatedpattrec.algorithms.MediatedClonalSelection;
import com.oat.domains.cells.mediatedpattrec.problems.MediatedPatternRecognition;
import com.oat.domains.cells.opt.Cell;
import com.oat.domains.cells.opt.DegenerateCell;
import com.oat.domains.cells.patrec.CellSet;
import com.oat.utils.ArrayUtils;
import com.oat.utils.EvolutionUtils;
import com.oat.utils.RandomUtils;

/**
 * Description: 
 *  
 * Date: 08/11/2007<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class TopDownSubstring extends EpochAlgorithm<CellSet>
	implements MediatedClonalSelection
{
	// config
	protected long seed = 1;
	
	protected int numBCells = 100;
	protected int numTCells = 100;
	
	protected int numBCellClones = 10;
	protected int numTCellClones = 10;		
	
	// data
	protected Random rand;
	protected LinkedList<DegenerateCell> bcells;
	protected LinkedList<Cell> tcells;
	
	
	@Override
	protected LinkedList<CellSet> internalInitialiseBeforeRun(Problem problem)
	{	
		rand = new Random(seed);		
		
		// bcells
		bcells = new LinkedList<DegenerateCell>();		
		for (int i = 0; i < numTCells; i++)
		{
			boolean [] data = RandomUtils.randomBitString(rand, 3, 64);
			boolean [] mask = RandomUtils.randomBitString(rand, 3, 64);
			DegenerateCell c = new DegenerateCell(data, mask);
			bcells.add(c);
		}
		
		// tcells
		tcells = new LinkedList<Cell>();		
		for (int i = 0; i < numTCells; i++)
		{
			boolean [] data = RandomUtils.randomBitString(rand, 3, 64);
			Cell c = new Cell(data);
			tcells.add(c);
		}
		
		// no initial population
		return null;
	}	
	
	@Override
	public LinkedList<Cell> getBCells()
	{
		return null;
	}

	@Override
	public LinkedList<Cell> getTCells()
	{
		return tcells;
	}
	
	
	
	
	
	
	protected Cell evaluateAndSelectTCell(DegenerateCell bcell, LinkedList<Cell> tCells)
	{		
		// assess first
		evaluateTCells(bcell, tCells);		
		// random tie handling
		Collections.shuffle(tCells);
		// order by utility
		Collections.sort(tCells);	
		return tCells.getFirst();
	}
	
	protected void evaluateTCells(DegenerateCell bcell, LinkedList<Cell> tCells)
	{		
		boolean [] d1 = bcell.getData();
		boolean [] m1 = bcell.getMask();
		
		for(Cell c : tCells)
		{			
			// assess against masked hamming
			double s = CellUtils.maskHammingDistance(d1, m1, c.getData());
			c.evaluated(s);
		}
	}
		
	
	
	
	protected DegenerateCell evaluateAndSelectBCell(
			MediatedPatternRecognition p, 
			LinkedList<DegenerateCell> pop, 
			int subProblemNumber)
	{
		// assess first
		evaluateBCells(p, pop, subProblemNumber);		
		// random tie handling
		Collections.shuffle(pop);
		// order by utility
		Collections.sort(pop);	
		return pop.getFirst();
	}
	
	
	protected void evaluateBCells(MediatedPatternRecognition p, LinkedList<DegenerateCell> bcells, int subProblemNumber)
	{		
		for(DegenerateCell c : bcells)
		{
			p.costSubStructure(c, subProblemNumber);
		}
	}
	
	
	protected Cell exposure(MediatedPatternRecognition p, int patternNo)
	{		
		// activate b cell
		DegenerateCell activatedBCell = evaluateAndSelectBCell(p, bcells, patternNo);
		// activate t cell
		Cell bmu = evaluateAndSelectTCell(activatedBCell, tcells);		
		// back propagate bcells
		backPropagateBCells(p, patternNo, activatedBCell);		
		// back propagate tcells
		backPropagateTCells(activatedBCell, bmu);		
		return bmu;		
	}
	
	protected void backPropagateBCells(MediatedPatternRecognition p, int patternNo, DegenerateCell bcell)
	{
		// clone b cell
		LinkedList<DegenerateCell> bCellClones = CellUtils.cloningAndMutation(bcell, numBCellClones, rand);
		// evaluate
		evaluateBCells(p, bCellClones, patternNo);
		// similarity-affinity replacement (exclude clones)
		LinkedList<DegenerateCell> bCellExclude = new LinkedList<DegenerateCell>();
		for(DegenerateCell c : bCellClones)
		{
			// most similar for substring
			DegenerateCell mostSimilar = CellUtils.getMostSimilarMaskedWithExclusion(c, bcells, bCellExclude);				
			if(c.getScore() < mostSimilar.getScore())
			{
				bcells.remove(mostSimilar);
				bcells.add(c);
				bCellExclude.add(c);
			}
		}
	}
	
	protected void backPropagateTCells(DegenerateCell bcell, Cell tcell)
	{		
		// clone t cell
		LinkedList<Cell> tCellClones = CellUtils.cloningAndMutation(tcell, numTCellClones, rand);
		// evaluate t cell clones against b cell
		evaluateTCells(bcell, tCellClones);
		// similarity-affinity replacement (exclude clones)
		LinkedList<Cell> tCellExclude = new LinkedList<Cell>();
		for(Cell c : tCellClones)
		{
			// most similar for entire bitstring
			Cell mostSimilar = CellUtils.getMostSimilarHammingWithExclusion(c, tcells, tCellExclude);				
			if(c.getScore() < mostSimilar.getScore())
			{
				tcells.remove(mostSimilar);
				tcells.add(c);
				tCellExclude.add(c);
			}
		}
	}

	@Override
	protected LinkedList<CellSet> internalExecuteEpoch(Problem problem, LinkedList<CellSet> cp)
	{
		MediatedPatternRecognition p = (MediatedPatternRecognition) problem;			
		int numSubProblems = p.getNumInfections();		
		Cell [] bmus = new Cell[numSubProblems];		
		
		// process each sub problem
		for (int i = 0; i < numSubProblems; i++)
		{
			bmus[i] = exposure(p, i);
		}		
		
		// create a cell set
		LinkedList<CellSet> nextgen = new LinkedList<CellSet>();
		nextgen.add(new CellSet(bmus));
		return nextgen;
	}

	@Override
	protected void internalPostEvaluation(Problem problem, LinkedList<CellSet> oldPopulation, LinkedList<CellSet> newPopulation)
	{}

	@Override
	public void validateConfiguration() throws InvalidConfigurationException
	{}

	@Override
	public String getName()
	{
		return "TopDown Substring";
	}

	public long getSeed()
	{
		return seed;
	}

	public void setSeed(long seed)
	{
		this.seed = seed;
	}
}
