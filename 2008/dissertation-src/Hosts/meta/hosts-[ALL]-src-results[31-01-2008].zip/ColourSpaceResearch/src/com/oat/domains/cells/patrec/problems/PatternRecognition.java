/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006, 2007  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.cells.patrec.problems;

import java.util.Random;

import com.oat.InitialisationException;
import com.oat.InvalidConfigurationException;
import com.oat.Problem;
import com.oat.Solution;
import com.oat.SolutionEvaluationException;
import com.oat.domains.cells.opt.Cell;
import com.oat.domains.cells.opt.DegenerateCell;
import com.oat.domains.cells.opt.problems.Optimisation;
import com.oat.domains.cells.patrec.CellSet;
import com.oat.domains.tissues.InfectionProblem;
import com.oat.utils.BinaryDecodeMode;
import com.oat.utils.MeasureUtils;
import com.oat.utils.RandomUtils;

/**
 * Description: Pattern Recognition Problem 
 *  
 * Date: 31/10/2007<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class PatternRecognition extends Problem
	implements InfectionProblem
{
	// config
	protected long seed = 5;
	protected BinaryDecodeMode decodeMode = BinaryDecodeMode.GrayCode;
	protected int numPatterns = 10;
	protected int commonComponents = 3;
		
	// data
	protected Optimisation [] subproblems;
	
	

	@Override
	public void checkSolutionForSafety(Solution solution)
			throws SolutionEvaluationException
	{
		if(solution instanceof CellSet)
		{
			CellSet c = (CellSet) solution;
			if(c.getCells().length != numPatterns)
			{
				throw new SolutionEvaluationException("Number of cells "+c.getCells().length+" does not match the expected number of patterns "+numPatterns+".");
			}
		}
		else
		{
			throw new SolutionEvaluationException("Unknown type: " + solution.getClass().getName());
		}		
	}

	@Override
	public void cleanupAfterRun() throws InitialisationException
	{
		// cleanup if required
		for (int i = 0; i < numPatterns; i++)
		{
			subproblems[i].cleanupAfterRun();
		}
	}

	@Override
	public void initialiseBeforeRun() throws InitialisationException
	{
		Random rand = new Random(seed);		
		
		// create the random set
		boolean [][] set = RandomUtils.randomBitStringSet(rand, 64*3, numPatterns, 64);		
		// force commonality
		for (int i = 0; i < commonComponents; i++)
		{
			int patternNo1 = rand.nextInt(numPatterns);
			int patternNo2;
			while((patternNo2 = rand.nextInt(numPatterns)) == patternNo1); // contine until we have a different pattern			
			int commonComponent = rand.nextInt(3);			
			// copy
			System.arraycopy(set[patternNo1], 64*commonComponent, set[patternNo2], 64*commonComponent, 64);
		}
		
		// create the problems
		subproblems = new Optimisation[numPatterns];
		for (int i = 0; i < numPatterns; i++)
		{
			// create
			subproblems[i] = new Optimisation();
			// initialise
			subproblems[i].initialiseBeforeRunManually(set[i]);
		}
	}

	@Override
	public boolean isMinimization()
	{
		return true;
	}
	
	
	@Override
	protected double problemSpecificCost(Solution solution)
			throws SolutionEvaluationException
	{
		if(solution instanceof CellSet)
		{			
			CellSet c = (CellSet) solution;	
			Cell [] cells = c.getCells();
			double [] errors = new double[numPatterns];
			// process all patterns, expect cells are provided in order of the patterns
			for (int i = 0; i < numPatterns; i++)
			{
				// evaluate cells against the problem
				costCell(cells[i], i);				
				// store errors
				errors[i] = cells[i].getScore(); // Euclidean distance
			}
			
			// RMSE (root mean squared error)
			return MeasureUtils.calculateRMSE(errors);
		}
		
		throw new SolutionEvaluationException("Unsupported type: " + solution.getClass().getName());
	}	
	
	/**
	 * 
	 * @param solution
	 * @param subProblemNumber
	 * @throws SolutionEvaluationException
	 */
	public void costCell(Cell solution, int subProblemNumber)
			throws SolutionEvaluationException
	{
		// NOTE: i do not use cost(), because cost() on the subproblem will not re-evaluate solutions
		// that have already been evaluated. i want this behaviour
		double s = subproblems[subProblemNumber].costCell(solution);
		solution.evaluated(s);
	}
	
	public void costCell(DegenerateCell solution, int subProblemNumber)
		throws SolutionEvaluationException
	{
		// NOTE: i do not use cost(), because cost() on the subproblem will not re-evaluate solutions
		// that have already been evaluated. i want this behaviour
		double s = subproblems[subProblemNumber].costCell(solution);
		solution.evaluated(s);
	}
	
	public void costCellHamming(Cell solution, int subProblemNumber)
		throws SolutionEvaluationException
	{
		// NOTE: i do not use cost(), because cost() on the subproblem will not re-evaluate solutions
		// that have already been evaluated. i want this behaviour
		double s = subproblems[subProblemNumber].costCellHamming(solution);
		solution.evaluated(s);
	}
	
	/**
	 * Assess a full length solution by a single component
	 */
	public void costCellByComponent(Cell solution, int subProblemNumber, int componentNumber)
	{
		// delegated
		subproblems[subProblemNumber].costCellByComponent(solution, componentNumber);		
	}
	
	/**
	 * 
	 * @param partialSolution
	 * @param subProblemNumber
	 * @throws SolutionEvaluationException
	 */
	public void costSubStructure(DegenerateCell partialSolution, int subProblemNumber)
		throws SolutionEvaluationException
	{
		subproblems[subProblemNumber].costSubStructure(partialSolution);
	}
	
	/**
	 * 
	 * @param partialSolution
	 * @param subProblemNumber
	 * @throws SolutionEvaluationException
	 */
	public void costSingleFeature(Cell partialSolution, int subProblemNumber)
		throws SolutionEvaluationException
	{
		subproblems[subProblemNumber].costSingleFeature(partialSolution);
	}	

	@Override
	protected void validateConfigurationInternal()
			throws InvalidConfigurationException
	{
		if(decodeMode == null)
		{
			throw new InvalidConfigurationException("Decode mode not set.");
		}
	}

	@Override
	public String getName()
	{
		return "Colour Space Pattern Recognition";
	}	

	public long getSeed()
	{
		return seed;
	}

	public void setSeed(long seed)
	{
		this.seed = seed;
	}
	
	@Override
    public boolean isUserConfigurable()
    {
    	return true;
    }

	public int getNumInfections()
	{
		return numPatterns;
	}

	public void setNumPatterns(int numPatterns)
	{
		this.numPatterns = numPatterns;
	}

	public Optimisation[] getInfections()
	{
		return subproblems;
	}
	
	
}
