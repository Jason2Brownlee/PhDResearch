/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006, 2007  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.hosts.population;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Random;

import com.oat.Algorithm;
import com.oat.EpochAlgorithm;
import com.oat.InvalidConfigurationException;
import com.oat.Problem;
import com.oat.domains.cells.opt.Cell;
import com.oat.domains.cells.opt.problems.Optimisation;
import com.oat.domains.cells.patrec.CellSet;
import com.oat.domains.hosts.HER;
import com.oat.domains.hosts.HabitatProblem;
import com.oat.domains.hosts.Host;
import com.oat.domains.hosts.HostAlgorithm;
import com.oat.domains.hosts.HostRCCSA;
import com.oat.domains.tissues.ExposureListener;
import com.oat.domains.tissues.recirulation.algorithms.ReplacementCellularClonalSelectionAlgorithm;
import com.oat.utils.EvolutionUtils;

/**
 * Description: 
 *  
 * Date: 25/01/2008<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public abstract class PopulationHostClonalSelectionAlgorithm extends EpochAlgorithm<CellSet> 
	implements HostAlgorithm
{		
	// config
	protected int numHosts = 10;
	protected long seed = 1;
	protected int numCells = 50;
	protected int selectionSize = 1;
	protected int cloneSize = 5;
	protected int probabilistExposureDurationLength = 15;
	protected HER exposureMode = HER.Probabilistic;

	// general state
	protected HostRCCSA [] hosts;
	protected Random rand;	
	protected LinkedList<ExposureListener> listeners;
	// probabilistic exposure state
	protected double [][] histogram;
	protected int currentDurationLength;
	protected int [] currentSelection;	
	
	
	public PopulationHostClonalSelectionAlgorithm()
	{
		listeners = new LinkedList<ExposureListener>();
	}		
	
	protected void initialiseProbabilisticExposures(int numHabitats)
	{
		currentDurationLength = 0;
		histogram = new double[numHabitats][numHosts];		 
		currentSelection = new int[numHabitats];
		Arrays.fill(currentSelection, -1);
	}

	public Cell repertoireExposureInfection(HabitatProblem p, int habitatNumber)
	{
		// check for a reset
		if(currentSelection[habitatNumber] == -1 || 
				currentDurationLength >= probabilistExposureDurationLength)
		{
			// make selection
			int selection = EvolutionUtils.biasedRouletteWheelSelection(histogram[habitatNumber], rand);
			// store selection
			currentSelection[habitatNumber] = selection;
			// reset count
			currentDurationLength = 0;
			// increment the frequency			
			histogram[habitatNumber][currentSelection[habitatNumber]]++;			
		}				
		
		// perform an exposure
		currentDurationLength++;		
		// simple one-to-one exposure scheme
		return doSpecificExposure(currentSelection[habitatNumber], p, habitatNumber);
	}

	
	public Cell repertoireExposureRandom(HabitatProblem p, int habitatNumber)
	{
		// select repertoire (wraps around the number of repertories)
		int repNo = rand.nextInt(numHosts);
		// simple one-to-one exposure scheme
		return doSpecificExposure(repNo, p, habitatNumber);
	}
	
	public Cell repertoireExposurePoint(HabitatProblem p, int habitatNumber)
	{
		// always the same
		int repNo = 1;		
		// simple one-to-one exposure scheme
		return doSpecificExposure(repNo, p, habitatNumber);
	}
	
	public Cell repertoireExposureAsymmetric(HabitatProblem p, int habitatNumber)
	{
		// select repertoire (wraps around the number of repertories)
		int repNo = habitatNumber % numHosts;				
		// trigger exposure event
		return doSpecificExposure(repNo, p, habitatNumber);
	}
	
	public Cell repertoireExposureSymmetric(HabitatProblem p, int habitatNumber)
	{
		LinkedList<Cell> repertoireBMUs = new LinkedList<Cell>();
		
		// expose to each repertoire
		for (int i = 0; i < hosts.length; i++)
		{
			// exposure
			Cell bmu = doSpecificExposure(i, p, habitatNumber);
			// record
			repertoireBMUs.add(bmu);
		}
		
		Collections.shuffle(repertoireBMUs, rand); // random tie handling
		Collections.sort(repertoireBMUs); // order by affinity
		return repertoireBMUs.getFirst(); // return the best
	}
	
	
	protected Cell doSpecificExposure(int hostNumber, HabitatProblem p, int habitatNumber)
	{
		// retrieve host
		ReplacementCellularClonalSelectionAlgorithm host = hosts[hostNumber];
		// exposure
		Cell bmu = host.exposure(p, habitatNumber);
		// trigger event
		triggerExposureEvent(hostNumber, host, habitatNumber, p.getHabiats()[habitatNumber]);
		return bmu;
	}
	
	
	
	public Cell exposure(HabitatProblem p, int infectionNumber)
	{
		Cell bmu = null;
		
		switch(exposureMode)
		{			
		case Asymmetric:
			bmu = repertoireExposureAsymmetric(p, infectionNumber);
			break;
		
		case Symmetric:
			bmu = repertoireExposureSymmetric(p, infectionNumber);
			break;
			
		case Random:
			bmu = repertoireExposureRandom(p, infectionNumber);
			break;
			
		case Point:
			bmu = repertoireExposurePoint(p, infectionNumber);
			break;
			
		case Probabilistic: 
			bmu = repertoireExposureInfection(p, infectionNumber);
			break;
			
		default:
			throw new RuntimeException("Invalid exposure mode: " + exposureMode);
		}
		
		return bmu;
	}

	
	@Override
	protected LinkedList<CellSet> internalInitialiseBeforeRun(Problem problem)
	{
		rand = new Random(seed);
		// prepare exposure things
		HabitatProblem p = (HabitatProblem) problem;
		initialiseProbabilisticExposures(p.getNumHabitats());
		// prepare tissues
		hosts = prepareHosts(problem);		
		return null;
	}	
	
	protected HostRCCSA[] prepareHosts(Problem problem)
	{
		HostRCCSA [] ccsas = new HostRCCSA[numHosts];
		for (int i = 0; i < ccsas.length; i++)
		{
			// create
			ccsas[i] = new HostRCCSA();
			// configure
			ccsas[i].setSeed(rand.nextLong());
			ccsas[i].setNumCells(numCells);
			ccsas[i].setSelectionSize(selectionSize);
			ccsas[i].setCloningSize(cloneSize);
			// initialise
			ccsas[i].doInternalInitialiseBeforeRun(problem);
		}
		
		return ccsas;
	}
	
	
	/**
	 * All about host-host interactions
	 * @param p
	 */
	public abstract void hostInteractions(HabitatProblem p);
	
	
	public CellSet systemExposure(HabitatProblem p)
	{
		int numSubProblems = p.getNumHabitats();		
		Cell [] bmus = new Cell[numSubProblems];
		// process each sub problem
		for (int i = 0; i < numSubProblems; i++)
		{
			bmus[i] = exposure(p, i);
		}		
		return new CellSet(bmus);
	}
	
	
	@Override
	protected LinkedList<CellSet> internalExecuteEpoch(Problem problem, LinkedList<CellSet> population)
	{
		HabitatProblem p = (HabitatProblem) problem;
		// perform exposure
		LinkedList<CellSet> nextgen = new LinkedList<CellSet>();
		CellSet set = systemExposure(p);
		nextgen.add(set);		
		// special population things
		hostInteractions(p);		
		return nextgen;
	}

	
	public void registerExposureListener(ExposureListener aListener)
	{
		listeners.add(aListener);
	}
	
	protected void triggerExposureEvent(int repNo, Algorithm rep, int patNo, Optimisation pat)
	{
		for(ExposureListener list : listeners)
		{
			list.exposure(repNo, rep, patNo, pat);
		}
	}
	
	public boolean removeExposureListener(ExposureListener aListener)
	{
		return listeners.remove(aListener);
	}


	@Override
	protected void internalPostEvaluation(Problem problem, LinkedList<CellSet> oldPopulation, LinkedList<CellSet> newPopulation)
	{
		for (int i = 0; i < hosts.length; i++)
		{
			hosts[i].doInternalPostEvaluation(problem, oldPopulation, newPopulation);
		}
	}
	
	@Override
	public Host[] getHosts()
	{
		return hosts;
	}

	@Override
	public void validateConfiguration() 
		throws InvalidConfigurationException
	{
		// sub repertoire configuration
		if(numCells<=0)
		{
			throw new InvalidConfigurationException("numCells size must be > 0.");
		}
		if(selectionSize>numCells)
		{
			throw new InvalidConfigurationException("Selection size must be less than the repertoire size.");
		}
		if(selectionSize<=0)
		{
			throw new InvalidConfigurationException("Selection size must be > 0.");
		}
		if(cloneSize<=0)
		{
			throw new InvalidConfigurationException("Clone size must be > 0.");
		}
		if(cloneSize>numCells)
		{
			throw new InvalidConfigurationException("Clone size must be less than the repertoire size.");
		}
		
		// master repertoire configuration
		if(numHosts<=0)
		{
			throw new InvalidConfigurationException("numHosts must be > 0.");
		}
		
		// cannot validate sub-repertoires because they are not created yet
	}

	public int getNumHosts()
	{
		return numHosts;
	}

	public void setNumHosts(int numHosts)
	{
		this.numHosts = numHosts;
	}

	public int getNumCells()
	{
		return numCells;
	}

	public void setNumCells(int numCells)
	{
		this.numCells = numCells;
	}

	public int getSelectionSize()
	{
		return selectionSize;
	}

	public void setSelectionSize(int selectionSize)
	{
		this.selectionSize = selectionSize;
	}

	public int getCloneSize()
	{
		return cloneSize;
	}

	public void setCloneSize(int cloneSize)
	{
		this.cloneSize = cloneSize;
	}

	public int getProbabilistExposureDurationLength()
	{
		return probabilistExposureDurationLength;
	}

	public void setProbabilistExposureDurationLength(
			int probabilistExposureDurationLength)
	{
		this.probabilistExposureDurationLength = probabilistExposureDurationLength;
	}

	public HER getExposureMode()
	{
		return exposureMode;
	}

	public void setExposureMode(HER exposureMode)
	{
		this.exposureMode = exposureMode;
	}
}
