/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006, 2007  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.cells.network.algorithms.dualexposure;

import java.util.LinkedList;
import java.util.Random;

import com.oat.AlgorithmRunException;
import com.oat.EpochAlgorithm;
import com.oat.InvalidConfigurationException;
import com.oat.Problem;
import com.oat.domains.cells.mediatedpattrec.CellUtils;
import com.oat.domains.cells.mediatedpattrec.MappedCell;
import com.oat.domains.cells.network.algorithms.Tissue;
import com.oat.domains.cells.network.algorithms.ClonalSelectionMapping;
import com.oat.domains.cells.network.problems.PRProblem;
import com.oat.domains.cells.opt.Cell;
import com.oat.domains.cells.opt.problems.Optimisation;
import com.oat.domains.cells.patrec.CellSet;
import com.oat.utils.AlgorithmUtils;

/**
 * Description: 
 *  
 * Date: 14/11/2007<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class DualExposureDecoupled extends EpochAlgorithm<CellSet>
	implements Tissue<MappedCell>, ClonalSelectionMapping<MappedCell>
{
	// config
	protected long seed = 1;
	protected int repertoireSize = -1;
	protected int selectionSize = 1;
	protected int cloningSize = 5;
	
	// data
	protected Random rand;
	protected LinkedList<MappedCell> cells;
	
	
	
	@Override
	protected LinkedList<CellSet> internalInitialiseBeforeRun(Problem problem)
	{		
		PRProblem p = (PRProblem) problem;
		
		// must be even
		if((p.getNumInfections() % 2) != 0)
		{
			throw new AlgorithmRunException("Expect an even number of patterns.");
		}
		repertoireSize = ((PRProblem)problem).getNumInfections() * 10;
		rand = new Random(seed);
		cells = CellUtils.getRandomMappedRepertoire(rand, repertoireSize);		
		// no initial population
		return null;
	}	
	
	
	@Override
	public LinkedList<MappedCell> getRepertoire()
	{
		return cells;
	}	
	

	protected void assessRepertoireAgainstAntigen(PRProblem p, int pattNo, LinkedList<MappedCell> repertoire)
	{
		for(Cell c : repertoire)
		{
			p.costCell(c, pattNo);
		}
	}	
	
	protected void assessMappedRepertoireAgainstAntigen(PRProblem p, int pattNo, LinkedList<MappedCell> repertoire)
	{
		for(MappedCell c : repertoire)
		{
			// decode as required
			CellUtils.forceDecodeSecondaryMapping(c);
			Optimisation o = p.getInfections()[pattNo];
			double dist = AlgorithmUtils.euclideanDistance(c.getDecoded2(), o.getGoalcoordinate());
			c.evaluated(dist);
		}
	}
	
	protected void replaceIntoRepertoire(LinkedList<MappedCell> progeny, LinkedList<MappedCell> repertoire)
	{
		// decode the repertoire
		for(MappedCell c : repertoire)
		{
			CellUtils.forceDecode(c);
		}
		
		for(MappedCell c : progeny)
		{
			CellUtils.forceDecode(c);
			
			// Euclidean similarity tournament for competition
			MappedCell similar = CellUtils.getMostSimilarEuclideanWithExclusion(c, repertoire, progeny);
			// fitness tournament for resources
			if(c.getScore() < similar.getScore())
			{
				repertoire.remove(similar);
				repertoire.add(c);
			}
		}
	}	
	
	protected void replaceMappedIntoRepertoire(LinkedList<MappedCell> progeny, LinkedList<MappedCell> repertoire)
	{
		// decode the repertoire
		for(MappedCell c : repertoire)
		{
			CellUtils.forceDecodeSecondaryMapping(c);
		}
		
		for(MappedCell c : progeny)
		{
			CellUtils.forceDecodeSecondaryMapping(c);
			// Euclidean similarity tournament for competition
			MappedCell similar = CellUtils.getMostSimilarEuclideanMappingWithExclusion(c, repertoire, progeny);
			// fitness tournament for resources
			if(c.getScore() < similar.getScore())
			{
				repertoire.remove(similar);
				repertoire.add(c);
			}
		}
	}
	
	protected MappedCell exposure1(PRProblem p, int pattNo)
	{			
		// assess repertoire
		assessRepertoireAgainstAntigen(p, pattNo, cells);
		// select the activated set
		LinkedList<MappedCell> selected = CellUtils.selectActivatedSet(cells, rand, selectionSize);
		// cloning and mutation
		LinkedList<MappedCell> clones = CellUtils.cloningAndMutationMapping(selected, cloningSize, rand);
		// assess the clones against the antigen
		assessRepertoireAgainstAntigen(p, pattNo, clones);		
		// compete for position within the repertoire
		replaceIntoRepertoire(clones, cells);
		// return the bmu
		return selected.getFirst();
	}
	
	protected MappedCell exposure2(PRProblem p, int pattNo)
	{			
		// assess repertoire
		assessMappedRepertoireAgainstAntigen(p, pattNo, cells);
		// select the activated set
		LinkedList<MappedCell> selected = CellUtils.selectActivatedSet(cells, rand, selectionSize);
		// cloning and mutation
		LinkedList<MappedCell> clones = CellUtils.cloningAndMutationMapping(selected, cloningSize, rand);
		// assess the clones against the antigen
		assessMappedRepertoireAgainstAntigen(p, pattNo, clones);
		// compete for position within the repertoire (similarity based on secondary mapping)
		replaceMappedIntoRepertoire(clones, cells);
		// return the bmu
		return selected.getFirst();
	}
	
	
	protected CellSet exposureManager(PRProblem p)
	{
		int numPatterns = p.getNumInfections(); 
		Cell [] bmus = new Cell[numPatterns];
		
		for (int i = 0; i < numPatterns; i+=2)
		{
			// expose the primary representation to the first antigen
			MappedCell bmu1 = exposure1(p, i);		
			// expose the secondary representation to the second antigen
			MappedCell bmu2 = exposure2(p, i+1);
			
			// store
			bmus[i] = new Cell(bmu1.getData()); // primary representation
			bmus[i+1] = new Cell(bmu2.getData2()); // secondary representation
		}
		
		CellSet set = new CellSet(bmus);
		return set;
	}
	

	@Override
	protected LinkedList<CellSet> internalExecuteEpoch(Problem problem, LinkedList<CellSet> cp)
	{
		PRProblem p = (PRProblem) problem;		

		CellSet epochResult = exposureManager(p);
		
		// create a cell set
		LinkedList<CellSet> nextgen = new LinkedList<CellSet>();
		nextgen.add(epochResult);
		return nextgen;
	}

	@Override
	protected void internalPostEvaluation(Problem problem, LinkedList<CellSet> oldPopulation, LinkedList<CellSet> newPopulation)
	{}

	@Override
	public void validateConfiguration() throws InvalidConfigurationException
	{}

	@Override
	public String getName()
	{
		return "DualExposure Decoupled";
	}

	public long getSeed()
	{
		return seed;
	}

	public void setSeed(long seed)
	{
		this.seed = seed;
	}
}
