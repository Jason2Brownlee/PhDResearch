/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006, 2007  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.cells.mediatedpattrec.algorithms.bottomup.cells.manytomany;

import java.util.Collections;
import java.util.LinkedList;
import java.util.Random;

import com.oat.EpochAlgorithm;
import com.oat.InvalidConfigurationException;
import com.oat.Problem;
import com.oat.domains.cells.mediatedpattrec.CellUtils;
import com.oat.domains.cells.mediatedpattrec.MappedCell;
import com.oat.domains.cells.mediatedpattrec.algorithms.MediatedClonalSelection;
import com.oat.domains.cells.mediatedpattrec.problems.MediatedPatternRecognition;
import com.oat.domains.cells.opt.Cell;
import com.oat.domains.cells.patrec.CellSet;
import com.oat.utils.AlgorithmUtils;

/**
 * Description: 
 *  
 * Date: 12/11/2007<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class BottomUpMappingManyToMany extends EpochAlgorithm<CellSet>	
	implements MediatedClonalSelection
{
	// config
	protected long seed = 1;
	// repertoire size
	protected int numBCells = 100;
	protected int numTCells = 100;
	// clones
	protected int numBCellClones = 1;
	protected int numTCellClones = 1;		
	// selection
	protected int numSelectedBCell = 10;
	protected int numSelectedTCell = 10;		
	
	// data
	protected Random rand;
	protected LinkedList<MappedCell> bcells;
	protected LinkedList<MappedCell> tcells;	
	
	
	@Override
	protected LinkedList<CellSet> internalInitialiseBeforeRun(Problem problem)
	{	
		rand = new Random(seed);			
		// bcells
		bcells = CellUtils.getRandomMappedRepertoire(rand, numBCells);			
		// tcells
		tcells = CellUtils.getRandomMappedRepertoire(rand, numTCells);
		
		// no initial population
		return null;
	}
	
	@Override
	public LinkedList<MappedCell> getBCells()
	{
		return bcells;
	}

	@Override
	public LinkedList<MappedCell> getTCells()
	{
		return tcells;
	}
	
	
	protected void evaluateRepertoireAgainstAntigenEuclidean(MediatedPatternRecognition p, int pNum, LinkedList<MappedCell> repertoire)
	{
		for(MappedCell c : repertoire)
		{
			p.costCell(c, pNum);
		}
	}
	
	
	protected LinkedList<MappedCell> selectBCells(MediatedPatternRecognition p, int pNum, LinkedList<MappedCell> bCells)
	{
		// assess first
		evaluateRepertoireAgainstAntigenEuclidean(p, pNum, bCells);		
		// order by utility
		Collections.shuffle(bCells, rand);
		Collections.sort(bCells);	
		
		LinkedList<MappedCell> selected = new LinkedList<MappedCell>();
		for (int i = 0; i < numSelectedBCell; i++)
		{
			selected.add(bCells.get(i));
		}
		return selected;
	}
	
	protected void assessRepertoireAgainstActivatedcell(LinkedList<MappedCell> activatedCells, LinkedList<MappedCell> repertoire)
	{
		// process each repertoire cell
		for (MappedCell rc : repertoire)
		{
			// sum distance to all activated cells
			CellUtils.forceDecodeSecondaryMapping(rc);
			double sum = 0.0;	
			for(MappedCell ac : activatedCells)
			{
				CellUtils.forceDecodeSecondaryMapping(ac);
				sum += AlgorithmUtils.euclideanDistance(rc.getDecoded2(), ac.getDecoded2());				
			}
			rc.evaluated(sum);
		}
	}
	
	protected LinkedList<MappedCell> selectTCells(LinkedList<MappedCell> activatedBCells, LinkedList<MappedCell> tCells)
	{		
		assessRepertoireAgainstActivatedcell(activatedBCells, tCells);
		
		// order by utility
		Collections.shuffle(tCells, rand);
		Collections.sort(tCells);
		
		LinkedList<MappedCell> selected = new LinkedList<MappedCell>();
		for (int i = 0; i < numSelectedTCell; i++)
		{
			selected.add(tCells.get(i));
		}
		return selected;
	}
	

	protected MappedCell exposure(MediatedPatternRecognition p, int patternNo)
	{			
		// activate b cell against antigen
		LinkedList<MappedCell> activatedBCells = selectBCells(p, patternNo, bcells);
		// activate t cell against activated b-cell
		LinkedList<MappedCell> activatedTCells = selectTCells(activatedBCells, tcells);
		// back propagate bcells
		backPropagateBCells(activatedBCells, activatedTCells);
		// back propagate tcells
		backPropagateTCells(p, patternNo, activatedTCells);
		
		// best
		return activatedTCells.getFirst();		
	}	
	
	protected void backPropagateBCells(LinkedList<MappedCell> activatedBCells, LinkedList<MappedCell> activatedTCells)
	{			
		// assess the repertoire with regard to their mapping to the activated t-cell
		assessRepertoireAgainstActivatedcell(activatedTCells, bcells); 	
		
		for(MappedCell bc : activatedBCells)
		{
			// clone b cell
			LinkedList<MappedCell> bCellClones = CellUtils.cloningAndMutation(bc, numBCellClones, rand);
			// assess clones with regard to their mapping to the activated t-cell
			assessRepertoireAgainstActivatedcell(activatedTCells, bCellClones); 
			// parents compete with children
			MappedCell parent = bc;
			MappedCell child = bCellClones.getFirst();
			if(child.getScore() < parent.getScore())
			{
				bcells.remove(parent);
				bcells.add(child);
			}
		}
	}
	
	protected void backPropagateTCells(MediatedPatternRecognition p, int patternNo, LinkedList<MappedCell> activatedTCells)
	{
		// asses repertoire based on match to antigen
		evaluateRepertoireAgainstAntigenEuclidean(p, patternNo, tcells);		
		
		for(MappedCell tc : activatedTCells)
		{
			// clone t cell
			LinkedList<MappedCell> tCellClones = CellUtils.cloningAndMutation(tc, numTCellClones, rand);
			// assess clones based on match to antigen
			evaluateRepertoireAgainstAntigenEuclidean(p, patternNo, tCellClones); 
			// parents compete with children
			MappedCell parent = tc;
			MappedCell child = tCellClones.getFirst();
			if(child.getScore() < parent.getScore())
			{
				tcells.remove(parent);
				tcells.add(child);
			}
		}
	}

	@Override
	protected LinkedList<CellSet> internalExecuteEpoch(Problem problem, LinkedList<CellSet> cp)
	{
		MediatedPatternRecognition p = (MediatedPatternRecognition) problem;			
		int numSubProblems = p.getNumInfections();		
		Cell [] bmus = new Cell[numSubProblems];		
		
		// process each sub problem
		for (int i = 0; i < numSubProblems; i++)
		{
			bmus[i] = exposure(p, i);
		}		
		
		// create a cell set
		LinkedList<CellSet> nextgen = new LinkedList<CellSet>();
		nextgen.add(new CellSet(bmus));
		return nextgen;
	}

	@Override
	protected void internalPostEvaluation(Problem problem, LinkedList<CellSet> oldPopulation, LinkedList<CellSet> newPopulation)
	{}

	@Override
	public void validateConfiguration() throws InvalidConfigurationException
	{}

	@Override
	public String getName()
	{
		return "BottomUp Many-to-Many Mapping (Euclidean Mapping)";
	}

	public long getSeed()
	{
		return seed;
	}

	public void setSeed(long seed)
	{
		this.seed = seed;
	}
}
