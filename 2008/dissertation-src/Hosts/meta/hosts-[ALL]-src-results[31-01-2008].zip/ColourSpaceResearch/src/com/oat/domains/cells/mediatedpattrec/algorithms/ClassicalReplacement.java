/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006, 2007  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.cells.mediatedpattrec.algorithms;

import java.util.Collections;
import java.util.LinkedList;
import java.util.Random;

import com.oat.EpochAlgorithm;
import com.oat.InvalidConfigurationException;
import com.oat.Problem;
import com.oat.domains.cells.mediatedpattrec.CellUtils;
import com.oat.domains.cells.mediatedpattrec.problems.MediatedPatternRecognition;
import com.oat.domains.cells.opt.Cell;
import com.oat.domains.cells.patrec.CellSet;
import com.oat.utils.ArrayUtils;
import com.oat.utils.EvolutionUtils;
import com.oat.utils.RandomUtils;

/**
 * Description: Classical Replacement
 *  
 * Date: 07/11/2007<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class ClassicalReplacement extends EpochAlgorithm<CellSet>	
	implements MediatedClonalSelection
{
	// config
	protected long seed = 1;	
	protected int numCells = 100;	
	protected int numClones = 5;
	
	// data
	protected Random rand;
	protected LinkedList<Cell> cells;
	
	
	
	@Override
	protected LinkedList<CellSet> internalInitialiseBeforeRun(Problem problem)
	{	
		rand = new Random(seed);	
		
		// cells
		cells = new LinkedList<Cell>();		
		for (int i = 0; i < numCells; i++)
		{
			boolean [] data = RandomUtils.randomBitString(rand, 3, 64);
			Cell c = new Cell(data);
			cells.add(c);
		}
		
		// no initial population
		return null;
	}	
	
	


	@Override
	public LinkedList<Cell> getBCells()
	{
		return null;
	}
	@Override
	public LinkedList<Cell> getTCells()
	{
		return cells;
	}




	protected LinkedList<Cell> cloningAndMutation(Cell bmu, int numClones)
	{
		LinkedList<Cell> tmp = new LinkedList<Cell>();
		tmp.add(bmu);
		return cloningAndMutation(tmp, numClones);
	}
	
	protected LinkedList<Cell> cloningAndMutation(LinkedList<Cell> selectedSet, int numClones)
	{
		LinkedList<Cell> newPop = new LinkedList<Cell>();
		
		for(Cell current : selectedSet)
		{			
			for (int j = 0; j < numClones; j++)
			{
				// copy
				boolean [] cloneData = ArrayUtils.copyArray(current.getData());
				// mutate
				EvolutionUtils.binaryMutate(cloneData, rand, 1.0/cloneData.length);
				// store
				Cell clone = new Cell(cloneData);
				newPop.add(clone);
			}
		}
		
		return newPop;
	}	
	
	protected Cell evaluateAndSelectBMU(
			MediatedPatternRecognition p, 
			LinkedList<Cell> pop, 
			int subProblemNumber)
	{
		// assess first
		evaluateCells(p, pop, subProblemNumber);		
		// order by utility
		Collections.sort(pop);	
		// tie handling
		LinkedList<Cell> selected = new LinkedList<Cell>();
		for (int i = 0; i < pop.size(); i++)
		{
			if(pop.getFirst().getScore() == pop.get(i).getScore())
			{
				selected.add(pop.get(i));
			}
		}		
		return selected.get(rand.nextInt(selected.size()));
	}
	
	
	protected void evaluateCells(MediatedPatternRecognition p, LinkedList<Cell> bcells, int subProblemNumber)
	{
		for(Cell c : bcells)
		{
			p.costCell(c, subProblemNumber);
		}
	}
	
	
	protected Cell exposure(MediatedPatternRecognition p, int patternNo)
	{		
		// locate bmu
		Cell bmu = evaluateAndSelectBMU(p, cells, patternNo);		
		// cloning and replacement
		backPropagateCells(p, patternNo, bmu);
		
		return bmu;		
	}
	
	
	protected void backPropagateCells(MediatedPatternRecognition p, int patternNo, Cell bmu)
	{
		// clones
		LinkedList<Cell> cellClones = cloningAndMutation(bmu, numClones);		
		// evaluate clones
		evaluateCells(p, cellClones, patternNo); 		
		// similarity-affinity replacement (exclude clones)
		LinkedList<Cell> exclude = new LinkedList<Cell>();
		for(Cell c : cellClones)
		{
			//Cell mostSimilar = CellUtils.getMostSimilarEuclideanWithExclusion(c, cells, exclude);
			Cell mostSimilar = CellUtils.getMostSimilarHammingWithExclusion(c, cells, exclude);
						
			if(c.getScore() < mostSimilar.getScore())
			{
				cells.remove(mostSimilar);
				cells.add(c);
				exclude.add(c);
			}
		}
	}

	@Override
	protected LinkedList<CellSet> internalExecuteEpoch(Problem problem, LinkedList<CellSet> cp)
	{
		MediatedPatternRecognition p = (MediatedPatternRecognition) problem;			
		int numSubProblems = p.getNumInfections();		
		Cell [] bmus = new Cell[numSubProblems];		
		
		// process each sub problem
		for (int i = 0; i < numSubProblems; i++)
		{
			bmus[i] = exposure(p, i);
		}		
		
		// create a cell set
		LinkedList<CellSet> nextgen = new LinkedList<CellSet>();
		nextgen.add(new CellSet(bmus));
		return nextgen;
	}

	@Override
	protected void internalPostEvaluation(Problem problem, LinkedList<CellSet> oldPopulation, LinkedList<CellSet> newPopulation)
	{}

	@Override
	public void validateConfiguration() throws InvalidConfigurationException
	{}

	@Override
	public String getName()
	{
		return "Classical Replacement";
	}

	public long getSeed()
	{
		return seed;
	}

	public void setSeed(long seed)
	{
		this.seed = seed;
	}
}
