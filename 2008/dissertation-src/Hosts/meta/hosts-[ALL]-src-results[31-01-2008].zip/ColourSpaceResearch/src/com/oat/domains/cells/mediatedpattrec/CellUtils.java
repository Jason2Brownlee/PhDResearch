/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006, 2007  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.cells.mediatedpattrec;

import java.util.Collections;
import java.util.LinkedList;
import java.util.Random;

import com.oat.domains.cells.opt.Cell;
import com.oat.domains.cells.opt.DegenerateCell;
import com.oat.domains.cells.opt.problems.Optimisation;
import com.oat.domains.tissues.homing.HomingCell;
import com.oat.utils.AlgorithmUtils;
import com.oat.utils.ArrayUtils;
import com.oat.utils.BinaryDecodeMode;
import com.oat.utils.BitStringUtils;
import com.oat.utils.EvolutionUtils;
import com.oat.utils.RandomUtils;

/**
 * Description: 
 *  
 * Date: 07/11/2007<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class CellUtils
{
	
	public static <C extends Cell> LinkedList<C> selectActivatedSet(LinkedList<C> repertoire, Random rand, int selectionSize)
	{
		return selectActivatedSet(repertoire, null, rand, selectionSize);
	}	
	
	public static <C extends Cell> LinkedList<C> selectActivatedSet(LinkedList<C> repertoire, LinkedList<C> exclude, Random rand, int selectionSize)
	{
		Collections.shuffle(repertoire, rand);
		// order by utility
		Collections.sort(repertoire);	
		
		LinkedList<C> selectedSet = new LinkedList<C>();		
		for (int i = 0; selectedSet.size() < selectionSize && i < repertoire.size(); i++)
		{			
			C current = repertoire.get(i);			
			// check if using exclusion and current should be excluded
			if(exclude != null && exclude.contains(current))
			{
				continue;
			}
			// store
			selectedSet.add(current);
		}
		
		if(selectedSet.size() != selectionSize)
		{
			throw new RuntimeException("Insufficient cells in the repertoire to select activated set (used exclusion="+(exclude != null)+")");
		}
		
		return selectedSet;
	}
	
		
	public static double averageHammingDistance(LinkedList<Cell> cells)
	{
		Cell [] cArray = new Cell[cells.size()];
		cells.toArray(cArray);
		return averageHammingDistance(cArray);
	}
	
	/**
	 * Average of the average distances between a given cell and all other cells in the repertoire
	 * 
	 * @param cells
	 * @return
	 */
	public static double averageHammingDistance(Cell [] cells)
	{
		double mSum = 0.0;
	
		for (int i = 0; i < cells.length; i++)
		{			
			// caluclate average distance for this cell
			double sum = 0.0;
			boolean [] base = cells[i].getData();
			for (int j = 0; j < cells.length; j++)
			{				
				sum += BitStringUtils.hammingDistance(base, cells[j].getData());
			}
			// sum the averages
			mSum += (sum / cells.length);
		}
		
		// average the averages
		return mSum / cells.length;
	}
	
	public static double averageMappedHammingDistance(LinkedList<MappedCell> cells)
	{
		MappedCell [] cArray = new MappedCell[cells.size()];
		cells.toArray(cArray);
		return averageMappedHammingDistance(cArray);
	}
	
	/**
	 * Average of the average distances between a given cell and all other cells in the repertoire
	 * 
	 * @param cells
	 * @return
	 */
	public static double averageMappedHammingDistance(MappedCell [] cells)
	{
		double mSum = 0.0;
	
		for (int i = 0; i < cells.length; i++)
		{			
			// caluclate average distance for this cell
			double sum = 0.0;
			boolean [] base = cells[i].getData2();
			for (int j = 0; j < cells.length; j++)
			{				
				sum += BitStringUtils.hammingDistance(base, cells[j].getData2());
			}
			// sum the averages
			mSum += (sum / cells.length);
		}
		
		// average the averages
		return mSum / cells.length;
	}
	
	
	
	public static LinkedList<Cell> getRandomRepertoire(Random rand, int size)
	{
		LinkedList<Cell> repertoire = new LinkedList<Cell>();		
		for (int i = 0; i < size; i++)
		{
			boolean [] data = RandomUtils.randomBitString(rand, 3, 64);
			repertoire.add(new Cell(data));
		}
		return repertoire;
	}
	
	public static boolean [][] getRandomRepertoireArray(Random rand, int size)
	{
		boolean [][] r = new boolean[size][];
		for (int i = 0; i < r.length; i++)
		{
			r[i] = RandomUtils.randomBitString(rand, 3, 64);
		}
		return r;
	}
	
	public static LinkedList<MappedCell> getRandomMappedRepertoire(Random rand, int size)
	{
		LinkedList<MappedCell> repertoire = new LinkedList<MappedCell>();		
		for (int i = 0; i < size; i++)
		{
			boolean [] data1 = RandomUtils.randomBitString(rand, 3, 64);
			boolean [] data2 = RandomUtils.randomBitString(rand, 3, 64);
			repertoire.add(new MappedCell(data1, data2));
		}
		return repertoire;
	}
	
	public static Cell createMasterCellFromDegenerateCells(Cell g1, Cell g2, Cell g3)
	{
		boolean [] b = new boolean[3*64];
		
		// 1
		int off = 0;
		System.arraycopy(g1.getData(), 0, b, 0, g1.getData().length);
		off += g1.getData().length;
		// 2
		System.arraycopy(g2.getData(), 0, b, off, g2.getData().length);
		off += g2.getData().length;
		// 3
		System.arraycopy(g3.getData(), 0, b, off, g3.getData().length);		
		off += g3.getData().length;
		
		if(off != b.length)
		{
			throw new RuntimeException("Error in master cell creation");
		}
		
		return new Cell(b);
	}
	
	
	public static double componentDistance(Cell wholeCell, Cell componentCell)
	{
		// create an artificial vector
		double [] data = new double[]{wholeCell.getDecodedData()[componentCell.getGene()]};
		// euclidean for the single thing
		return AlgorithmUtils.euclideanDistance(componentCell.getDecodedData(), data);
	}
	
	
	
	public static LinkedList<DegenerateCell> cloningAndMutation(DegenerateCell bmu, int numClones, Random rand)
	{
		LinkedList<DegenerateCell> newPop = new LinkedList<DegenerateCell>();		
					
		for (int j = 0; j < numClones; j++)
		{
			// copy
			boolean [] cloneData = ArrayUtils.copyArray(bmu.getData());
			boolean [] cloneMask = ArrayUtils.copyArray(bmu.getMask());
			// mutate
			EvolutionUtils.binaryMutate(cloneData, rand, 1.0/cloneData.length);
			EvolutionUtils.binaryMutate(cloneMask, rand, 1.0/cloneMask.length);
			// store
			DegenerateCell clone = new DegenerateCell(cloneData, cloneMask);
			newPop.add(clone);
		}		
		
		return newPop;
	}
	
	
	public static LinkedList<HomingCell> cloningAndMutationHoming(HomingCell bmu, int numClones, Random rand)
	{
		LinkedList<HomingCell> newPop = new LinkedList<HomingCell>();
		
		for (int j = 0; j < numClones; j++)
		{
			// copy
			boolean [] cloneData = ArrayUtils.copyArray(bmu.getData());
			// mutate
			EvolutionUtils.binaryMutate(cloneData, rand, 1.0/cloneData.length);
			// create with gene - no harm if gene is not used
			HomingCell clone = new HomingCell(cloneData, bmu.getGene());
			newPop.add(clone);
		}
		
		return newPop;
	}
	
	
	public static LinkedList<Cell> cloningAndMutation(Cell bmu, int numClones, Random rand)
	{
		LinkedList<Cell> newPop = new LinkedList<Cell>();
		
		for (int j = 0; j < numClones; j++)
		{
			// copy
			boolean [] cloneData = ArrayUtils.copyArray(bmu.getData());
			// mutate
			EvolutionUtils.binaryMutate(cloneData, rand, 1.0/cloneData.length);
			// create with gene - no harm if gene is not used
			Cell clone = new Cell(cloneData, bmu.getGene());
			newPop.add(clone);
		}
		
		return newPop;
	}
	
	public static LinkedList<MappedCell> cloningAndMutation(MappedCell bmu, int numClones, Random rand)
	{
		LinkedList<MappedCell> newPop = new LinkedList<MappedCell>();
		
		for (int j = 0; j < numClones; j++)
		{
			// copy
			boolean [] cloneData1 = ArrayUtils.copyArray(bmu.getData());
			boolean [] cloneData2 = ArrayUtils.copyArray(bmu.getData2());
			// mutate
			EvolutionUtils.binaryMutate(cloneData1, rand, 1.0/cloneData1.length);
			EvolutionUtils.binaryMutate(cloneData2, rand, 1.0/cloneData2.length);
			// create
			MappedCell clone = new MappedCell(cloneData1, cloneData2);
			newPop.add(clone);
		}
		
		return newPop;
	}
	
	public static LinkedList<MappedCell> cloningAndMutationMapping(LinkedList<MappedCell> selectedSet, int numClones, Random rand)
	{
		LinkedList<MappedCell> newPop = new LinkedList<MappedCell>();
		
		for(MappedCell current : selectedSet)
		{			
			newPop.addAll(cloningAndMutation(current, numClones, rand));
		}
		
		return newPop;
	}
	
	
	public static LinkedList<Cell> cloningAndMutation(LinkedList<Cell> selectedSet, int numClones, Random rand)
	{
		LinkedList<Cell> newPop = new LinkedList<Cell>();
		
		for(Cell current : selectedSet)
		{			
			newPop.addAll(cloningAndMutation(current, numClones, rand));
		}
		
		return newPop;
	}
	
	public static LinkedList<HomingCell> cloningAndMutationHoming(LinkedList<HomingCell> selectedSet, int numClones, Random rand)
	{
		LinkedList<HomingCell> newPop = new LinkedList<HomingCell>();
		
		for(HomingCell current : selectedSet)
		{			
			newPop.addAll(cloningAndMutationHoming(current, numClones, rand));
		}
		
		return newPop;
	}
	
	
	public static void forceDecodeComponent(Cell c)
	{
		if(c.getGene() == -1)
		{
			throw new RuntimeException("Cannot decode component, provided cell is not a component.");
		}
		
		// decode the single value
		if(c.getDecodedData() == null)
		{
			// decode will make sure the cell has enough bits!
			double [] data = BitStringUtils.decode(BinaryDecodeMode.GrayCode, c.getData(), new double[][]{Optimisation.minmax[c.getGene()]});
			// store
			c.setDecodedData(data);
		}
	}
	
	public static void forceDecode(Cell c)
	{
		if(c.getDecodedData() == null)
		{
			double [] data = BitStringUtils.decode(BinaryDecodeMode.GrayCode, c.getData(), Optimisation.minmax);
			c.setDecodedData(data);
		}
	}
	
	public static void forceDecode(DegenerateCell c)
	{
		if(c.getDecodedData() == null)
		{
			double [] data = BitStringUtils.decode(BinaryDecodeMode.GrayCode, c.getData(), Optimisation.minmax);
			c.setDecodedData(data);
		}
	}
	
	public static void forceDecodeSecondaryMapping(MappedCell c)
	{
		if(c.getDecoded2() == null)
		{
			boolean [] rep2 = c.getData2();
			double [] data = BitStringUtils.decode(BinaryDecodeMode.GrayCode, rep2, Optimisation.minmax);
			c.setDecoded2(data);
		}
	}
	
	
	public static double maskHammingDistance(boolean [] data1, boolean [] mask1, boolean [] data2)
	{		
		// number of differences
		int count = 0;
		
		for (int i = 0; i < mask1.length; i++)
		{
			if(mask1[i])
			{
				// check for match
				if(data1[i] != data2[i])
				{
					count++;
				}
			}
		}
		
		return count;
	}
	
	public static double maskHammingDistance(boolean [] data1, boolean [] mask1, boolean [] data2, boolean [] mask2)
	{		
		// number of differences
		int count = 0;
		
		for (int i = 0; i < mask1.length; i++)
		{
			// have to exist in both strings
			if(mask1[i] && mask2[i])
			{
				// check for match
				if(data1[i] != data2[i])
				{
					count++;
				}
			}
		}
		
		return count;
	}
	
	
	
	public static <C extends Cell> C getMostSimilarHammingWithExclusion(C cell, LinkedList<C> set, LinkedList<C> exclude)
	{
		double  min = Double.POSITIVE_INFINITY;
		C best = null;
		
		for(C c : set)
		{
			if(exclude!=null && exclude.contains(c))
			{
				continue;
			}
			
			double d = BitStringUtils.hammingDistance(cell.getData(), c.getData());

			if(d < min)
			{
				min = d;
				best = c;
			}
		}
		
		return best;		
	}
	
	public static <C extends Cell> C getMostSimilarEuclideanWithExclusion(C cell, LinkedList<C> set, LinkedList<C> exclude)
	{
		double  min = Double.POSITIVE_INFINITY;
		C best = null;
		
		for(C c : set)
		{
			if(exclude!= null && exclude.contains(c))
			{
				continue;
			}
			
			double d = AlgorithmUtils.euclideanDistance(cell.getDecodedData(), c.getDecodedData());
			if(d < min)
			{
				min = d;
				best = c;
			}
		}
		
		return best;		
	}
	
	public static <C extends Cell> C getMostSimilarEuclideanByComponentWithExclusion(
			C cell, LinkedList<C> set, 
			LinkedList<C> exclude, 
			int component)
	{
		double  min = Double.POSITIVE_INFINITY;
		C best = null;
		
		for(C c : set)
		{
			if(exclude!= null && exclude.contains(c))
			{
				continue;
			}
			
			double d = Math.abs(cell.getDecodedData()[component] - c.getDecodedData()[component]);
			
			if(d < min)
			{
				min = d;
				best = c;
			}
		}
		
		return best;		
	}
	
	
	public static <C extends MappedCell> C getMostSimilarEuclideanMappingWithExclusion(C cell, LinkedList<C> set, LinkedList<C> exclude)
	{
		double  min = Double.POSITIVE_INFINITY;
		C best = null;
		
		for(C c : set)
		{
			if(exclude!= null && exclude.contains(c))
			{
				continue;
			}
			
			double d = AlgorithmUtils.euclideanDistance(cell.getDecoded2(), c.getDecoded2());
			if(d < min)
			{
				min = d;
				best = c;
			}
		}
		
		return best;		
	}
	public static <C extends MappedCell> C getMostSimilarHammingMappingWithExclusion(C cell, LinkedList<C> set, LinkedList<C> exclude)
	{
		double  min = Double.POSITIVE_INFINITY;
		C best = null;
		
		for(C c : set)
		{
			if(exclude!= null && exclude.contains(c))
			{
				continue;
			}
			
			double d = BitStringUtils.hammingDistance(cell.getData2(), c.getData2());
			if(d < min)
			{
				min = d;
				best = c;
			}
		}
		
		return best;		
	}
	
	
	
	public static <C extends DegenerateCell> C getMostSimilarMaskedWithExclusion(C cell, LinkedList<C> set, LinkedList<C> exclude)
	{
		double  min = Double.POSITIVE_INFINITY;
		C best = null;
		
		for(C c : set)
		{
			if(exclude!= null && exclude.contains(c))
			{
				continue;
			}
			
			double d = maskHammingDistance(cell.getData(), cell.getMask(), c.getData(), c.getMask());
			if(d < min)
			{
				min = d;
				best = c;
			}
		}
		
		return best;		
	}
}
