/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006, 2007  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.cells.mediatedpattrec.gui;

import java.awt.Color;
import java.awt.Graphics;
import java.util.LinkedList;

import com.oat.AlgorithmEpochCompleteListener;
import com.oat.Problem;
import com.oat.Solution;
import com.oat.domains.cells.opt.Cell;
import com.oat.domains.cells.opt.problems.Optimisation;
import com.oat.domains.cells.patrec.CellSet;
import com.oat.domains.cells.patrec.problems.PatternRecognition;
import com.oat.explorer.gui.ClearEventListener;
import com.oat.explorer.gui.plot.GenericProblemPlot;

/**
 * Description: 
 *  
 * Date: 06/11/2007<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class MedatedPatternRecognitionViewer extends GenericProblemPlot
	implements AlgorithmEpochCompleteListener, ClearEventListener
{	
	protected PatternRecognition problem;	
	protected LinkedList<Color> problemColours;
	protected LinkedList<Color> popColours;
	
	
	public MedatedPatternRecognitionViewer()
	{
		setName("Population View");
		problemColours = new LinkedList<Color>();
		popColours = new LinkedList<Color>();
	}
	
	@Override
	public void problemChangedEvent(Problem p)
	{
		synchronized(this)
		{			
			clear();
		
			if(p instanceof PatternRecognition)
			{
				problem = (PatternRecognition) p;
			}
		}
		
		repaint();
	}

	@Override
	public void clear()
	{
		synchronized(this)
		{
			problemColours.clear();
			popColours.clear();
		}
	}

	@Override
	public <T extends Solution> void epochCompleteEvent(Problem p, LinkedList<T> currentPop)
	{		
		synchronized(this)
		{
			if(problem == null)
			{
				return;
			}			
			// lazy, so we know the problem has been initialised
			if(problemColours.isEmpty())
			{
				Optimisation [] subprobs = problem.getInfections();
				for (int i = 0; i < subprobs.length; i++)
				{
					double [] optima = subprobs[i].getGlobalOptima()[0].getCoordinate();
					problemColours.add(vectorToColor(optima));
				}
			}
			// convert the current population to colours
			popColours.clear();
			
			// expect a population of size 1
			if(currentPop.size() == 1)
			{
				Cell [] cells = ((CellSet)currentPop.getFirst()).getCells();
				
				for (Solution s : cells)
				{
					Color c = vectorToColor(((Cell)s).getDecodedData());
					popColours.add(c);
				}
			}
		}		
		
		repaint();
	}	
	
	protected Color vectorToColor(double [] v)
	{		
		return new Color((float)v[0], (float)v[1], (float)v[2]);
	}

	@Override
	protected void paintComponent(Graphics g)
	{
		synchronized(this)
		{
			if(problem == null)
			{
				super.plotUnavailable(g);
				return;
			}
			
			// clear
			g.setColor(Color.WHITE);
			g.fillRect(0,0,getWidth(),getHeight());
			
			// calculate things
			int width = (int) Math.floor((double)getWidth() / 2.0);
			int height = (int) Math.floor((double)getHeight() / problemColours.size()); 
			
			int h2 = height/2;
			int w2 = width/2; 
			int w3 = w2/3;
			
			// draw the population colours
			for (int i = 0; i < popColours.size(); i++)
			{
				drawColor(g, popColours.get(i), 0, i*height, width, height);
				Color [] components = getComponents(popColours.get(i));
				for (int j = 0; j < components.length; j++)
				{
					drawColor(g, components[j], 0+(j*w3), i*height+(h2/2), w3, h2);
				}
			}
			
			// draw the problem colours
			for (int i = 0; i < problemColours.size(); i++)
			{
				drawColor(g, problemColours.get(i), width, i*height, width, height);
				Color [] components = getComponents(problemColours.get(i));
				for (int j = 0; j < components.length; j++)
				{
					drawColor(g, components[j], width+(j*w3), i*height+(h2/2), w3, h2);
				}
			}		
		}
	}
	
	public Color [] getComponents(Color c)
	{
		Color [] comp = new Color[3];		
		float [] components = c.getComponents(null);
		
		comp[0] = new Color(components[0], 0, 0);
		comp[1] = new Color(0, components[1], 0);
		comp[1] = new Color(0, 0, components[2]);
		
		return comp;
	}
	
	public void drawColor(Graphics g, Color c, int x, int y, int width, int height)
	{
		g.setColor(c);
		g.fillRect(x, y, width, height);				
		g.setColor(Color.BLACK);
		g.drawRect(x, y, width, height);
	}
	
}
