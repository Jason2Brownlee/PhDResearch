/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006-2008  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.experimenter;

import java.io.File;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.LinkedList;

import com.oat.Domain;
import com.oat.RunProbe;
import com.oat.StopCondition;
import com.oat.experimenter.Experiment;
import com.oat.experimenter.ExperimentalRun;
import com.oat.experimenter.ExperimentalRunMatrix;
import com.oat.experimenter.RunResult;
import com.oat.experimenter.TemplateExperiment;
import com.oat.experimenter.stats.AnalysisException;
import com.oat.experimenter.stats.RunStatisticSummary;
import com.oat.experimenter.stats.analysis.StatisticalComparisonTest;
import com.oat.utils.FileUtils;

/**
 * Description: Provides some base functionality for doing analysis on clonal selection studies 
 *  
 * Date: 29/01/2008<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public abstract class ClonalSelectionTemplateExperiment extends TemplateExperiment
{
	@Override
	public boolean performAnalysys()
	{
		return true;
	}
	
	@Override
	public void performAnalsys(Experiment experiment)
	{
		super.performAnalsys(experiment);		
		
		ExperimentalRunMatrix matrix = experimentToMatrix(experiment);
		// load results
		RunResult [][][] results = loadRunResults(experiment, matrix);
		// select statistics to report on
		LinkedList<RunProbe> reportStats = getReportingStatistics();	
		// prepare run matrix
		ExperimentalRun [][] runMatrix = runListToRunMatrix(experiment, matrix);
		
		
		// significance report
		if(useStatisticalSignificanceHack())
		{
			System.out.println(">Generating significance analysis report...");
			generateSignificanceReport(experiment, runMatrix, results, reportStats);
		}
		else
		{
			System.out.println(">Skipping significance analysis...");
		}
	}	
	
	
	
	protected String summariseSignificance(RunStatisticSummary [] resultsForMeasure, Experiment exp)
	{
		StatisticalComparisonTest [][] pairwiseResults = pairwiseStatisticalComparisonTests(resultsForMeasure);
		
		// calculate frequencies
		int rejectTrue = 0;
		int rejectFalse = 0;
		for (int i = 0; i < pairwiseResults.length; i++)
		{
			for (int j = i+1; j < pairwiseResults.length; j++)
			{
				if(pairwiseResults[i][j].canRejectNullHypothesis())
				{
					rejectTrue++;
				}
				else
				{
					rejectFalse++;
				}
			}			
		}
		
		StringBuffer b = new StringBuffer();
		
		// check for holistic true outcome
		if(rejectTrue >= rejectFalse)
		{
			b.append("True");
			
			// locate all false
			if(rejectTrue != resultsForMeasure.length)
			{
				for (int i = 0; i < pairwiseResults.length; i++)
				{
					for (int j = i+1; j < pairwiseResults.length; j++)
					{
						if(!pairwiseResults[i][j].canRejectNullHypothesis())
						{
							b.append(", ");
							String r1 = exp.getAlgorithmNameForRunId(resultsForMeasure[i].getExperimentalRunName());
							String r2 = exp.getAlgorithmNameForRunId(resultsForMeasure[j].getExperimentalRunName());
							b.append("False for "+r1+" and "+r2);
						}
					}
				}
			}
		}
		else
		{
			b.append("False");
			
			// locate all true
			if(rejectTrue != resultsForMeasure.length)
			{
				for (int i = 0; i < pairwiseResults.length; i++)
				{
					for (int j = i+1; j < pairwiseResults.length; j++)
					{
						if(pairwiseResults[i][j].canRejectNullHypothesis())
						{
							b.append(", ");
							String r1 = exp.getAlgorithmNameForRunId(resultsForMeasure[i].getExperimentalRunName());
							String r2 = exp.getAlgorithmNameForRunId(resultsForMeasure[j].getExperimentalRunName());
							b.append("True for "+r1+" and "+r2);
						}
					}
				}
			}
		}
		
		return b.toString();
	}
	
	public StatisticalComparisonTest getStatisticalComparisonTestInstance()
	{
		throw new UnsupportedOperationException("getStatisticalComparisonTestInstance() is not supported!");
	}
	
	protected int algorithmStackSize()
	{
		throw new UnsupportedOperationException("algorithmStackSize() is not supported!");
	}
	
	public boolean useStatisticalSignificanceHack()
	{
		return false;
	}
	
	
    public StatisticalComparisonTest [][] pairwiseStatisticalComparisonTests(RunStatisticSummary [] results)
    {
    	StatisticalComparisonTest [][] tests = new StatisticalComparisonTest[results.length][results.length];
    	
    	// across the top
    	for (int x = 0; x < tests.length; x++)
		{
			for (int y = x+1; y < tests[x].length; y++)
			{
				tests[x][y] = getStatisticalComparisonTestInstance();
				try
				{
					tests[x][y].evaluate(results[x], results[y]);
				}
				catch (AnalysisException e)
				{
					throw new RuntimeException("Something unexpected happened calculating pairwise statistics: " + e.getMessage(), e);
				}
			}
		}
    	
    	return tests;
    }
    
	/**
	 * Create a analysis report and output it to csv in the experiment directory 
	 * includes statistical significance hack
	 * 
	 * @param exp
	 * @param runMatrix
	 * @param results
	 * @param statistics
	 */
	public void generateSignificanceReport(
			Experiment exp, 
			ExperimentalRun [][] runMatrix, 
			RunResult [][][] results, 
			LinkedList<RunProbe> statistics)
	{
		int groupSize = algorithmStackSize();
		int numsig = runMatrix[0].length / groupSize;
		
		// pre-calculate all summary statistics
		RunStatisticSummary [][][] summaries = new RunStatisticSummary[statistics.size()][][];
		for (int i = 0; i < summaries.length; i++)
		{
			summaries[i] = calculateStatSummary(statistics.get(i), runMatrix, results);
		}
		
		// CSV result matrix
		NumberFormat f = new DecimalFormat();
		// rows = header + (problems * algorithms) + numsig
		int rows = 1 + (runMatrix.length * runMatrix[0].length) + numsig;
		// cols = p-header + a-header + (stats * 2)
		int cols = (1 + 1 + (statistics.size()*2));
		String [][] csv = new String[rows][cols];
		int col = 0;
		int row = 0;
		
		// add header row
		csv[row][col++] = "Problem";
		csv[row][col++] = "Algorithm";
		for (int i = 0; i < statistics.size(); i++)
		{
			// for mean and stdev
			csv[row][col++] = statistics.get(i).getName();
			csv[row][col++] = statistics.get(i).getName();
		}
		row++; // increment row
		
		// for each problem
		boolean perge;
		LinkedList<RunStatisticSummary> [] collection = new LinkedList[statistics.size()];  
		for (int j = 0; j < collection.length; j++)
		{
			collection[j] = new LinkedList<RunStatisticSummary>(); 
		}
		
		for (int i = 0; i < runMatrix.length; i++)
		{			
			perge = true;
			
			// for each algorithm executed on this problem
			for (int j = 0, alg = 0; j < runMatrix[i].length + numsig; j++)
			{				
				col = 0; // reset the columns
				
				if(perge && alg != 0 && (alg%groupSize)==0) 
				{
					csv[row][col++] = "Significant";
					csv[row][col++] = "-";
					
					// calculate significance and purge
					for (int j2 = 0; j2 < statistics.size(); j2++)
					{
						// calculate for this statistic
						String r = summariseSignificance(collection[j2].toArray(new RunStatisticSummary[collection[j2].size()]), exp);	
						csv[row][col++] = r; // significance
						csv[row][col++] = "-"; // skip
						// clear
						collection[j2].clear();
					}
					perge = false;
				}
				else
				{					
					perge = true;
					// add the problem name
					csv[row][col++] = runMatrix[i][alg].getProblem().getName();
					// add the algorithm name
					csv[row][col++] = runMatrix[i][alg].getAlgorithm().getName();
					
					// for each probe of interest collected on this problem-algorithm combination
					for (int j2 = 0; j2 < statistics.size(); j2++)
					{
						// retrieve and format
						csv[row][col++] = f.format(summaries[j2][i][alg].getMean());
						csv[row][col++] = f.format(summaries[j2][i][alg].getStdev());	
						collection[j2].add(summaries[j2][i][alg]);
					}			
					alg++;
				}			
				row++; // increment row	
			}
		}		
		
		System.out.println(">Successfully generated significance report data");
		String filename = "significance-report.csv";
		File outputFile = new File(exp.getExperimentHomeDir() + "/" + filename);
		try
		{
			FileUtils.writeCSV(csv, outputFile);
		}
		catch (Exception e1)
		{
			throw new RuntimeException("Something unexpected happened while outputting significance report.", e1);
		}
		System.out.println(">Successfully saved significance report data to file: " + outputFile.getName());
	}	
}
