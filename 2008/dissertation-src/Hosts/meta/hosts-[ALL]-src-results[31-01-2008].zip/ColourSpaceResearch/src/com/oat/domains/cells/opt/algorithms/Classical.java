/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006, 2007  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.cells.opt.algorithms;

import java.util.Collections;
import java.util.LinkedList;
import java.util.Random;

import com.oat.EpochAlgorithm;
import com.oat.InvalidConfigurationException;
import com.oat.Problem;
import com.oat.domains.cells.opt.Cell;
import com.oat.utils.ArrayUtils;
import com.oat.utils.EvolutionUtils;
import com.oat.utils.RandomUtils;

/**
 * Description: Classical clonal selection with a holistic solution representation 
 *  
 * Date: 30/10/2007<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class Classical extends EpochAlgorithm<Cell>
{
	// config
	protected long seed = 1;
	protected int repertoireSize = 100;
	protected int selectionSize = 20;
	protected int cloningSize = 5;	
	protected double mutationRate = 1.0/(3.0*64.0);
	
	// data
	protected Random rand;
	
	@Override
	protected LinkedList<Cell> internalInitialiseBeforeRun(Problem problem)
	{
		rand = new Random(seed);
		LinkedList<Cell> cells = new LinkedList<Cell>();
		
		for (int i = 0; i < repertoireSize; i++)
		{
			boolean [] data = RandomUtils.randomBitString(rand, 3, 64);
			Cell c = new Cell(data);			
			cells.add(c);
		}		
		return cells;
	}

	@Override
	protected LinkedList<Cell> internalExecuteEpoch(Problem problem, LinkedList<Cell> pop)
	{
		// order by utility
		Collections.sort(pop);
		LinkedList<Cell> newPop = new LinkedList<Cell>();
		
		for (int i = 0; i < selectionSize; i++)
		{
			Cell current = (problem.isMinimization()) ? pop.get(i) : pop.get(pop.size()-1-i);			
			for (int j = 0; j < cloningSize; j++)
			{
				// copy
				boolean [] cloneData = ArrayUtils.copyArray(current.getData());
				// mutate
				EvolutionUtils.binaryMutate(cloneData, rand, mutationRate);
				// store
				Cell clone = new Cell(cloneData);
				newPop.add(clone);
			}
		}
		
		return newPop;
	}

	@Override
	protected void internalPostEvaluation(Problem problem, LinkedList<Cell> oldPopulation, LinkedList<Cell> newPopulation)
	{}

	@Override
	public void validateConfiguration() throws InvalidConfigurationException
	{
		if(repertoireSize<0)
		{
			throw new InvalidConfigurationException("Invalid repertoireSize " + repertoireSize);
		}
	}

	@Override
	public String getName()
	{
		return "Convential";
	}

	public long getSeed()
	{
		return seed;
	}

	public void setSeed(long seed)
	{
		this.seed = seed;
	}

}
