/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006-2008  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.hosts.generation.evolution.algorithms;

import java.util.LinkedList;
import java.util.Random;

import com.oat.Problem;
import com.oat.domains.cells.mediatedpattrec.CellUtils;
import com.oat.domains.cells.opt.Cell;
import com.oat.domains.cells.patrec.CellSet;
import com.oat.domains.hosts.HabitatProblem;
import com.oat.domains.hosts.HostRCCSA;
import com.oat.domains.hosts.generation.GenerationalHostClonalSelectionAlgorithm;
import com.oat.domains.hosts.probes.AverageHostError;
import com.oat.utils.ArrayUtils;
import com.oat.utils.EvolutionUtils;

/**
 * Description: 
 *  
 * Date: 25/01/2008<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class EvolvedImmunityHostClonalSelectionAlgorithm extends
		GenerationalHostClonalSelectionAlgorithm
{
	// repertoire wide crossover
	protected double crossoverProbability = 0.90;
	// mutation probability per cell (50 in 9600 bits)
	protected double mutationProbability = 1.0 / (3.0*64.0);
	
	// state 
	protected boolean [][][] genetics;

	

	@Override
	protected HostRCCSA[] createNextGeneration(HostRCCSA[] pop, HabitatProblem p)
	{
		// assess current parents
		double [] scores = new double[numHosts];
		for (int i = 0; i < scores.length; i++)
		{
			scores[i] = AverageHostError.calculateHostBMUError(pop[i], p.getHabiats());
		}		
		//System.out.println(">scores: " + Arrays.toString(scores));
		
		// select parents
		int [] parents = new int[numHosts];
		for (int i = 0; i < numHosts; i++)
		{
			// make selection
			parents[i] = EvolutionUtils.biasedRouletteWheelSelection(scores, rand);
		}
		
		boolean [][][] newGenetics = new boolean[numHosts][][];
		HostRCCSA [] nextGeneration = new HostRCCSA[numHosts];
		
		// create children
		for (int i = 0; i < numHosts; i+=2)
		{
			int p1 = parents[i];
			int p2 = parents[i+1];
			// create
			boolean [][][] twoChildren = createChildren(genetics[p1], genetics[p2]);
			for (int j = 0; j < twoChildren.length; j++)
			{
				// save genetics
				newGenetics[i+j] = twoChildren[j];
				// create a the host 
				nextGeneration[i+j] = createHost(twoChildren[j]);				 
			}
		}
		
		// replace genetics
		genetics = newGenetics;
		// return next generation
		return nextGeneration;
	}
	
	protected boolean [][][] createChildren(boolean [][] p1, boolean [][] p2)
	{
		boolean [][][] children = new boolean [2][numCells][];		
		// default no cross point
		int crossPoint = 0;
		
		if(rand.nextDouble() < crossoverProbability)
		{
			do
			{
				crossPoint = rand.nextInt(numCells); 
			}
			// force a cross point
			while(crossPoint==0 && crossPoint==numCells-1);
		}
		
		// replicate all cells
		for (int i = 0; i < numCells; i++)
		{			 			
			if(i < crossPoint)
			{
				// straight copy
				children[0][i] = ArrayUtils.copyArray(p1[i]);
				children[1][i] = ArrayUtils.copyArray(p2[i]);
			}
			else
			{
				// reverse
				children[1][i] = ArrayUtils.copyArray(p1[i]);
				children[0][i] = ArrayUtils.copyArray(p2[i]);
			}
			
			// mutation
			EvolutionUtils.binaryMutate(children[1][i], rand, mutationProbability);
			EvolutionUtils.binaryMutate(children[0][i], rand, mutationProbability);
		}
		
		
		return children;
	}
	
	
	@Override
	protected LinkedList<CellSet> internalInitialiseBeforeRun(Problem problem)
	{		
		epochCount = 0;
		rand = new Random(seed);
		// prepare exposure things
		HabitatProblem p = (HabitatProblem) problem;
		initialiseProbabilisticExposures(p.getNumHabitats());
		// prepare genetics
		prepareGenetics();
		// prepare hosts
		hosts = prepareHosts(problem);		
		return null;
	}	
	
	protected void prepareGenetics()
	{
		genetics = new boolean[numHosts][][];
		for (int i = 0; i < genetics.length; i++)
		{
			genetics[i] = CellUtils.getRandomRepertoireArray(rand, numCells);
		}
	}
	
	protected HostRCCSA[] prepareHosts(Problem problem)
	{
		Evolved_RCCSA [] ccsas = new Evolved_RCCSA[numHosts];
		for (int i = 0; i < ccsas.length; i++)
		{
			ccsas[i] = createHost(genetics[i]);
		}
		
		return ccsas;
	}
	
	protected Evolved_RCCSA createHost(boolean [][] cellData)
	{
		Evolved_RCCSA host = new Evolved_RCCSA();
		
		host.setSeed(rand.nextLong());
		host.setNumCells(numCells);
		host.setSelectionSize(selectionSize);
		host.setCloningSize(cloneSize);
		
		// create repertoire
		LinkedList<Cell> cells = new LinkedList<Cell>();
		for (int j = 0; j < numCells; j++)
		{
			cells.add(new Cell(cellData[j]));
		}		
		// initialize
		host.evolveInternalInitialiseBeforeRun(cells);
		
		return host;
	}
	
	
	@Override
	public String getName()
	{
		return "Evolved Immunity Host Clonal Selection Algorithm (EI-HCSA)";
	}
}
