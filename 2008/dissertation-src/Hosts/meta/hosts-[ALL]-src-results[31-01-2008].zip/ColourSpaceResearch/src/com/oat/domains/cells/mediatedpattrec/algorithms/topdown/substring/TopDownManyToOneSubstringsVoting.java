/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006, 2007  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.cells.mediatedpattrec.algorithms.topdown.substring;

import java.util.Collections;
import java.util.LinkedList;
import java.util.Random;

import com.oat.EpochAlgorithm;
import com.oat.InvalidConfigurationException;
import com.oat.Problem;
import com.oat.domains.cells.mediatedpattrec.CellUtils;
import com.oat.domains.cells.mediatedpattrec.algorithms.MediatedClonalSelection;
import com.oat.domains.cells.mediatedpattrec.problems.MediatedPatternRecognition;
import com.oat.domains.cells.opt.Cell;
import com.oat.domains.cells.opt.DegenerateCell;
import com.oat.domains.cells.patrec.CellSet;
import com.oat.utils.RandomUtils;

/**
 * Description: Many to one cells  (top-down approach)
 *  
 * Date: 08/11/2007<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class TopDownManyToOneSubstringsVoting extends EpochAlgorithm<CellSet>
	implements MediatedClonalSelection
{
	// config
	protected long seed = 1;
	
	protected int numBCells = 100;
	protected int numTCells = 50;
	
	protected int numBCellsSelected = 10;
	
	protected int numTCellClones = 5;
	
	// data
	protected Random rand;
	protected LinkedList<DegenerateCell> bcells;
	protected LinkedList<Cell> tcells;
	
	
	@Override
	protected LinkedList<CellSet> internalInitialiseBeforeRun(Problem problem)
	{	
		rand = new Random(seed);		
		
		// bcells
		bcells = new LinkedList<DegenerateCell>();		
		for (int i = 0; i < numBCells; i++)
		{
			boolean [] data = RandomUtils.randomBitString(rand, 3, 64);
			boolean [] mask = RandomUtils.randomBitString(rand, 3, 64);
			DegenerateCell c = new DegenerateCell(data, mask);
			bcells.add(c);
		}
		
		// tcells
		tcells = new LinkedList<Cell>();		
		for (int i = 0; i < numTCells; i++)
		{
			boolean [] data = RandomUtils.randomBitString(rand, 3, 64);
			Cell c = new Cell(data);
			tcells.add(c);
		}
		
		// no initial population
		return null;
	}	
	
	@Override
	public LinkedList<Cell> getBCells()
	{
		return null;
	}

	@Override
	public LinkedList<Cell> getTCells()
	{
		return tcells;
	}
	
	
	/**
	 * Looking for the highest activation count
	 * 
	 * @param tCells
	 * @return
	 */
	protected Cell getMostActivatedTcell(LinkedList<Cell> tCells)
	{
		Collections.shuffle(tCells, rand);
		Collections.sort(tCells);
		return tCells.getLast(); // highest score
	}
	
	
	
	protected LinkedList<DegenerateCell> evaluateAndSelectBCell(
			MediatedPatternRecognition p, 
			LinkedList<DegenerateCell> pop, 
			int subProblemNumber)
	{
		// assess first
		evaluateBCells(p, pop, subProblemNumber);		
		// tie handling - random
		Collections.shuffle(pop, rand);		
		// order by utility
		Collections.sort(pop);			
		// select n best
		LinkedList<DegenerateCell> selected = new LinkedList<DegenerateCell>();
		for (int i = 0; i < numBCellsSelected; i++)
		{
			selected.add(pop.get(i));
		}		
		return selected;
	}
	
	
	protected void evaluateBCells(MediatedPatternRecognition p, LinkedList<DegenerateCell> bcells, int subProblemNumber)
	{
		for(DegenerateCell c : bcells)
		{
			p.costSubStructure(c, subProblemNumber);
		}
	}
	
	protected void activateTcells(LinkedList<DegenerateCell> activatedCells, LinkedList<Cell> repertoire)
	{
		// zero all t cell scores
		for(Cell tc : repertoire)
		{
			tc.evaluated(0);
		}
		
		// activate t cell for each activated component
		for(DegenerateCell bc : activatedCells)
		{
			// select the BMU
			Cell activatedTCell = evaluateAndSelectTCell(bc, repertoire);
			// increment the activation count
			activatedTCell.evaluated(activatedTCell.getScore() + 1);
		}		
	}
	
	protected Cell evaluateAndSelectTCell(DegenerateCell bcell, LinkedList<Cell> tCells)
	{				
		Cell best = null;
		double bestScore = Integer.MAX_VALUE; 
		
		// assess first
		for(Cell c : tCells)
		{
			double dist = CellUtils.maskHammingDistance(bcell.getData(), bcell.getMask(), c.getData());	
			
			if(dist < bestScore)
			{
				bestScore = dist;
				best = c;
			}
		}
		
		return best;
	}
	
	
	
	
	
	protected Cell exposure(MediatedPatternRecognition p, int patternNo)
	{		
		// activate b cell
		LinkedList<DegenerateCell> activatedBCells = evaluateAndSelectBCell(p, bcells, patternNo);			
		
		// get the most activated t cell
		activateTcells(activatedBCells, tcells);
		Cell bmu = getMostActivatedTcell(tcells);
		
		// back propagate bcells
		backPropagateBCells(p, patternNo, activatedBCells);				
		// back propagate tcells
		backPropagateTCells(activatedBCells, bmu);
		
		return bmu;		
	}
	
	
	protected void backPropagateBCells(MediatedPatternRecognition p, int patternNo, LinkedList<DegenerateCell> activatedBCells)
	{				
		for(DegenerateCell bc : activatedBCells)
		{
			// 1 clone b cell
			LinkedList<DegenerateCell> bCellClones = CellUtils.cloningAndMutation(bc, 1, rand);
			// evaluate clones
			evaluateBCells(p, bCellClones, patternNo);
			
			// child with parent
			DegenerateCell child = bCellClones.getFirst();
			DegenerateCell parent = bc;
			
			if(child.getScore() < parent.getScore())
			{
				bcells.remove(parent);
				bcells.add(child);
			}
		}
	}
	
	
	protected void backPropagateTCells(LinkedList<DegenerateCell> activatedBCells, Cell tcell)
	{
		// clone 
		LinkedList<Cell> tCellClones = CellUtils.cloningAndMutation(tcell, numTCellClones, rand);
		
		// activate t cells
		activateTcells(activatedBCells, tCellClones);
		
		// similarity-affinity replacement (exclude clones)
		LinkedList<Cell> tCellExclude = new LinkedList<Cell>();
		for(Cell c : tCellClones)
		{
			Cell mostSimilar = CellUtils.getMostSimilarHammingWithExclusion(c, tcells, tCellExclude);	

			// scores are larger the better
			if(c.getScore() > mostSimilar.getScore())
			{
				tcells.remove(mostSimilar);
				tcells.add(c);
				tCellExclude.add(c);
			}
		}
	}


	@Override
	protected LinkedList<CellSet> internalExecuteEpoch(Problem problem, LinkedList<CellSet> cp)
	{
		MediatedPatternRecognition p = (MediatedPatternRecognition) problem;			
		int numSubProblems = p.getNumInfections();		
		Cell [] bmus = new Cell[numSubProblems];
		
		// process each sub problem
		for (int i = 0; i < numSubProblems; i++)
		{
			bmus[i] = exposure(p, i);
		}		
		
		// create a cell set
		LinkedList<CellSet> nextgen = new LinkedList<CellSet>();
		nextgen.add(new CellSet(bmus));
		return nextgen;
	}

	@Override
	protected void internalPostEvaluation(Problem problem, LinkedList<CellSet> oldPopulation, LinkedList<CellSet> newPopulation)
	{}

	@Override
	public void validateConfiguration() throws InvalidConfigurationException
	{}

	@Override
	public String getName()
	{
		return "TopDown ManyToOne Substring (voting)";
	}

	public long getSeed()
	{
		return seed;
	}

	public void setSeed(long seed)
	{
		this.seed = seed;
	}
}
