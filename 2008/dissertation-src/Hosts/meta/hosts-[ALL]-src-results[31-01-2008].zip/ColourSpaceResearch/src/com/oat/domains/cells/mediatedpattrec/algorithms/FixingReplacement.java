/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006, 2007  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.cells.mediatedpattrec.algorithms;

import java.util.Collections;
import java.util.LinkedList;
import java.util.Random;

import com.oat.EpochAlgorithm;
import com.oat.InvalidConfigurationException;
import com.oat.Problem;
import com.oat.domains.cells.mediatedpattrec.problems.MediatedPatternRecognition;
import com.oat.domains.cells.opt.Cell;
import com.oat.domains.cells.patrec.CellSet;
import com.oat.utils.ArrayUtils;
import com.oat.utils.EvolutionUtils;
import com.oat.utils.RandomUtils;

/**
 * Description: 
 *  
 * Date: 09/11/2007<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class FixingReplacement extends EpochAlgorithm<CellSet>	
	implements MediatedClonalSelection
{
	// config
	protected long seed = 1;	
	protected int numCells = 100;	
	protected int numClones = 10;
	
	// data
	protected Random rand;
	protected LinkedList<Cell> cells;
	
	
	
	@Override
	protected LinkedList<CellSet> internalInitialiseBeforeRun(Problem problem)
	{	
		rand = new Random(seed);	
		
		// cells
		cells = new LinkedList<Cell>();		
		for (int i = 0; i < numCells; i++)
		{
			boolean [] data = RandomUtils.randomBitString(rand, 3, 64);
			Cell c = new Cell(data);
			cells.add(c);
		}
		
		// no initial population
		return null;
	}	
	
	


	@Override
	public LinkedList<Cell> getBCells()
	{
		return null;
	}
	@Override
	public LinkedList<Cell> getTCells()
	{
		return cells;
	}




	protected LinkedList<Cell> cloningAndMutation(Cell bmu, int numClones)
	{
		LinkedList<Cell> newPop = new LinkedList<Cell>();
		
					
		for (int j = 0; j < numClones; j++)
		{
			// copy
			boolean [] cloneData = ArrayUtils.copyArray(bmu.getData());
			// mutate
			EvolutionUtils.binaryMutate(cloneData, rand, 1.0/cloneData.length);
			// store
			Cell clone = new Cell(cloneData);
			newPop.add(clone);
		}		
		
		return newPop;
	}
	
	protected Cell evaluateRepertoireAgainstAntigenAndSelectBMU(MediatedPatternRecognition p, int subProblemNumber, LinkedList<Cell> repertoire)
	{
		// assess first
		evaluateCellsAgainstAntigen(p, subProblemNumber, repertoire);		
		// random tie handling
		Collections.shuffle(repertoire);
		// order by utility
		Collections.sort(repertoire);	
		return repertoire.getFirst();
	}	
	
	protected void evaluateCellsAgainstAntigen(MediatedPatternRecognition p, int subProblemNumber, LinkedList<Cell> repertoire)
	{
		for(Cell c : repertoire)
		{
			p.costCell(c, subProblemNumber);
		}
	}	
	
	LinkedList<Cell> tmpPop = new LinkedList<Cell>();
	 
	
	protected Cell exposure(MediatedPatternRecognition p, int patternNo)
	{		
		// locate bmu
		Cell bmu = evaluateRepertoireAgainstAntigenAndSelectBMU(p, patternNo, cells);		
		// cloning and replacement
		backPropagateCells(p, patternNo, bmu);
		
		return bmu;		
	}
	
	
	protected void backPropagateCells(MediatedPatternRecognition p, int patternNo, Cell bmu)
	{
		// clones
		LinkedList<Cell> cellClones = cloningAndMutation(bmu, numClones);		
		
		tmpPop.addAll(cellClones);
		
		/*
		// evaluate clones
		evaluateCellsAgainstAntigen(p, patternNo, cellClones); 		

		
		for(Cell c : cellClones)
		{
			LinkedList<Cell> sample = RandomUtils.randomSampleWithOutReselection(cells, 20, rand);
			Cell mostSimilar = CellUtils.getMostSimilarEuclideanWithExclusion(c, sample, null);
						
			if(c.getScore() < mostSimilar.getScore())
			{
				cells.remove(mostSimilar);
				cells.add(c);
			}
		}
		*/
	}

	@Override
	protected LinkedList<CellSet> internalExecuteEpoch(Problem problem, LinkedList<CellSet> cp)
	{
		MediatedPatternRecognition p = (MediatedPatternRecognition) problem;			
		int numSubProblems = p.getNumInfections();		
		Cell [] bmus = new Cell[numSubProblems];		
		tmpPop.clear();
		
		// process each sub problem
		for (int i = 0; i < numSubProblems; i++)
		{
			bmus[i] = exposure(p, i);
		}		
		
		cells.clear();
		cells.addAll(tmpPop);
		
		// create a cell set
		LinkedList<CellSet> nextgen = new LinkedList<CellSet>();
		nextgen.add(new CellSet(bmus));
		return nextgen;
	}

	@Override
	protected void internalPostEvaluation(Problem problem, LinkedList<CellSet> oldPopulation, LinkedList<CellSet> newPopulation)
	{}

	@Override
	public void validateConfiguration() throws InvalidConfigurationException
	{}

	@Override
	public String getName()
	{
		return "Fixing Replacement";
	}

	public long getSeed()
	{
		return seed;
	}

	public void setSeed(long seed)
	{
		this.seed = seed;
	}
}
