/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006, 2007  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.cells.mediatedpattrec.algorithms.topdown.cells.onetomany;

import java.util.Collections;
import java.util.LinkedList;
import java.util.Random;

import com.oat.EpochAlgorithm;
import com.oat.InvalidConfigurationException;
import com.oat.Problem;
import com.oat.domains.cells.mediatedpattrec.CellUtils;
import com.oat.domains.cells.mediatedpattrec.algorithms.MediatedClonalSelection;
import com.oat.domains.cells.mediatedpattrec.problems.MediatedPatternRecognition;
import com.oat.domains.cells.opt.Cell;
import com.oat.domains.cells.patrec.CellSet;
import com.oat.utils.AlgorithmUtils;
import com.oat.utils.RandomUtils;

/**
 * Description: One to Many Cell 
 *  
 * Date: 09/11/2007<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class TopDownOneToManyCells extends EpochAlgorithm<CellSet>
	implements MediatedClonalSelection
{
	// config
	protected long seed = 1;
	
	protected int numBCells = 50;
	protected int numTCells = 100;
	
	// select one b cell
	protected int numTCellsSelected = 10;
	
	protected int numBCellClones = 5;
	// clone one t cell for each of the 10 selected
	
	// data
	protected Random rand;
	protected LinkedList<Cell> bcells;
	protected LinkedList<Cell> tcells;
	
	
	@Override
	protected LinkedList<CellSet> internalInitialiseBeforeRun(Problem problem)
	{	
		rand = new Random(seed);			
		// bcells
		bcells = CellUtils.getRandomRepertoire(rand, numBCells);			
		// tcells
		tcells = CellUtils.getRandomRepertoire(rand, numTCells);
		
		// no initial population
		return null;
	}	
	
	@Override
	public LinkedList<Cell> getBCells()
	{
		return bcells;
	}

	@Override
	public LinkedList<Cell> getTCells()
	{
		return tcells;
	}	
	
	
	protected Cell evaluateAndSelectBCell(MediatedPatternRecognition p, LinkedList<Cell> pop, int subProblemNumber)
	{
		// assess first
		evaluateBCells(p, pop, subProblemNumber);
		// tie handling - random
		Collections.shuffle(pop, rand);		
		// order by utility
		Collections.sort(pop);			
		return pop.getFirst();
	}	
	protected void evaluateBCells(MediatedPatternRecognition p, LinkedList<Cell> bcells, int subProblemNumber)
	{
		for(Cell c : bcells)
		{
			p.costCell(c, subProblemNumber);
		}
	}
	
	protected void activateTcells(Cell bBMU, LinkedList<Cell> repertoire)
	{
		for(Cell wholeCell : repertoire)
		{
			CellUtils.forceDecode(wholeCell);
			double dist = AlgorithmUtils.euclideanDistance(wholeCell.getDecodedData(), bBMU.getDecodedData());			
			wholeCell.evaluated(dist);
		}
	}
	protected LinkedList<Cell> getMostActivatedTcell(LinkedList<Cell> tCells)
	{
		Collections.shuffle(tCells, rand);
		Collections.sort(tCells);
		
		LinkedList<Cell> selected = new LinkedList<Cell>();
		for (int i = 0; i < numTCellsSelected; i++)
		{
			selected.add(tCells.get(i));
		}
		
		return selected;
	}
	
	protected Cell exposure(MediatedPatternRecognition p, int patternNo)
	{		
		// activate b cell
		Cell bBMU = evaluateAndSelectBCell(p, bcells, patternNo);
		// activate the t cells
		activateTcells(bBMU, tcells);
		LinkedList<Cell> activatedTCells = getMostActivatedTcell(tcells);
		// bmu is best
		Cell tBMU = activatedTCells.getFirst();		
		// back propagate bcells
		backPropagateBCells(p, patternNo, bBMU);				
		// back propagate tcells
		backPropagateTCells(bBMU, activatedTCells);
		
		return tBMU;		
	}
	
	
	protected void backPropagateBCells(MediatedPatternRecognition p, int patternNo, Cell bBMU)
	{
		// clone and mutate
		LinkedList<Cell> bCellClones = CellUtils.cloningAndMutation(bBMU, numBCellClones, rand);
		// evaluate clones
		evaluateBCells(p, bCellClones, patternNo);
		
		// similarity-affinity replacement (exclude clones)
		LinkedList<Cell> bCellExclude = new LinkedList<Cell>();
		for(Cell c : bCellClones)
		{
			Cell mostSimilar = CellUtils.getMostSimilarEuclideanWithExclusion(c, bcells, bCellExclude);
			if(c.getScore() < mostSimilar.getScore())
			{
				bcells.remove(mostSimilar);
				bcells.add(c);
				bCellExclude.add(c);
			}
		}
	}	
	
	protected void backPropagateTCells(Cell bBMU, LinkedList<Cell> activatedTCells)
	{
		for(Cell tc : activatedTCells)
		{
			// 1 clone t cell
			LinkedList<Cell> tCellClones = CellUtils.cloningAndMutation(tc, 1, rand);
			// evaluate clones
			activateTcells(bBMU, tCellClones);			
			// child with parent
			Cell child = tCellClones.getFirst();
			Cell parent = tc;
			// competition for replacement
			if(child.getScore() < parent.getScore())
			{
				tcells.remove(parent);
				tcells.add(child);
			}
		}
	}


	@Override
	protected LinkedList<CellSet> internalExecuteEpoch(Problem problem, LinkedList<CellSet> cp)
	{
		MediatedPatternRecognition p = (MediatedPatternRecognition) problem;			
		int numSubProblems = p.getNumInfections();		
		Cell [] bmus = new Cell[numSubProblems];		
		
		// process each sub problem
		for (int i = 0; i < numSubProblems; i++)
		{
			bmus[i] = exposure(p, i);
		}		
		
		// create a cell set
		LinkedList<CellSet> nextgen = new LinkedList<CellSet>();
		nextgen.add(new CellSet(bmus));
		return nextgen;
	}

	@Override
	protected void internalPostEvaluation(Problem problem, LinkedList<CellSet> oldPopulation, LinkedList<CellSet> newPopulation)
	{}

	@Override
	public void validateConfiguration() throws InvalidConfigurationException
	{}

	@Override
	public String getName()
	{
		return "TopDown OneToMany Cells (distance)";
	}

	public long getSeed()
	{
		return seed;
	}

	public void setSeed(long seed)
	{
		this.seed = seed;
	}
}
