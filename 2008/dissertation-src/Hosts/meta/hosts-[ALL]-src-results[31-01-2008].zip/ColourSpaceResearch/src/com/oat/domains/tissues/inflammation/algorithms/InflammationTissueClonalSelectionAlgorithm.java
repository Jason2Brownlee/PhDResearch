/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006-2008  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.tissues.inflammation.algorithms;

import com.oat.Algorithm;
import com.oat.AlgorithmRunException;
import com.oat.Problem;
import com.oat.domains.cells.opt.problems.Optimisation;
import com.oat.domains.cells.patrec.CellSet;
import com.oat.domains.tissues.ExposureListener;
import com.oat.domains.tissues.InfectionProblem;
import com.oat.domains.tissues.recirulation.algorithms.RecirculationTissueClonalSelectionAlgorithm;
import com.oat.domains.tissues.recirulation.algorithms.ReplacementCellularClonalSelectionAlgorithm;
import com.oat.utils.AlgorithmUtils;

/**
 * Description: 
 *  
 * Date: 21/01/2008<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class InflammationTissueClonalSelectionAlgorithm extends
		RecirculationTissueClonalSelectionAlgorithm
{
	// config
	protected int maximumRepertoireSize = 60;
	
	
	public InflammationTissueClonalSelectionAlgorithm()
	{
		// register special listener
		registerExposureListener(new InternalExposureListener());
	}
	
	protected class InternalExposureListener implements ExposureListener
	{
		@Override
		public void exposure(int repertoireNumber, Algorithm repertoire,
				int patternNumber, Optimisation antigen)
		{
			// increase selected repertoire size
			increaseRepertoireSizeToMaximum((ReplacementCellularClonalSelectionAlgorithm)repertoire);
		}		
	}
	
	@Override
	public CellSet systemExposure(InfectionProblem p)
	{
		// execute system exposures
		CellSet result = super.systemExposure(p);
		// decrease repertoire sizes
		decreaseRepertoireSizes();
		// return the result
		return result;
	}
	
	protected void increaseRepertoireSizeToMaximum(ReplacementCellularClonalSelectionAlgorithm repertoire)
	{
		repertoire.setNumCells(maximumRepertoireSize);		
	}
	
	protected void decreaseRepertoireSizes()
	{
		for (int i = 0; i < tissues.length; i++)			
		{
			// check for an assigned size larger than the default
			int currentSize = tissues[i].getNumCells();			
			if(currentSize > numCells)
			{
				// decrease allocated size
				int allocatedSize = currentSize - 1;
				tissues[i].setNumCells(allocatedSize);
				
				// check if used size exceeds allocated size
				while(tissues[i].getRepertoire().size() > allocatedSize)
				{
					// delete a random element
					int selection = rand.nextInt(tissues[i].getRepertoire().size());
					tissues[i].getRepertoire().remove(selection);
				}
			}
			
			// check for invalid sizes
			if(!AlgorithmUtils.inBounds(tissues[i].getNumCells(), numCells, maximumRepertoireSize))
			{
				throw new AlgorithmRunException("Invalid configured repertoire size " + tissues[i].getNumCells());
			}
			if(!AlgorithmUtils.inBounds(tissues[i].getRepertoire().size(), numCells, maximumRepertoireSize))
			{
				throw new AlgorithmRunException("Invalid actual repertoire size " + tissues[i].getRepertoire().size());
			}
		}
	}	
	
	
	protected ReplacementCellularClonalSelectionAlgorithm[] prepareTissues(Problem problem)
	{
		InflammationRCCSA [] ccsas = new InflammationRCCSA[numTissues];
		for (int i = 0; i < ccsas.length; i++)
		{
			// create
			ccsas[i] = new InflammationRCCSA();
			// configure
			ccsas[i].setSeed(rand.nextLong());
			ccsas[i].setNumCells(numCells);
			ccsas[i].setSelectionSize(selectionSize);
			ccsas[i].setCloningSize(cloneSize);
			// initialise (hack)
			ccsas[i].doInternalInitialiseBeforeRun(problem);
		}
		
		return ccsas;
	}


	@Override
	public String getName()
	{
		return "Inflammation Tissue Clonal Selection Algorithm (ITCSA)";
	}


	public int getMaximumRepertoireSize()
	{
		return maximumRepertoireSize;
	}
	public void setMaximumRepertoireSize(int maximumRepertoireSize)
	{
		this.maximumRepertoireSize = maximumRepertoireSize;
	}
	
}
