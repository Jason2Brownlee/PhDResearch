/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006, 2007  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.cells.spatial.algorithms.degenerate;

import java.util.LinkedList;
import java.util.Random;

import com.oat.EpochAlgorithm;
import com.oat.InvalidConfigurationException;
import com.oat.Problem;
import com.oat.domains.cells.opt.Cell;
import com.oat.domains.cells.opt.problems.Optimisation;
import com.oat.domains.cells.patrec.CellSet;
import com.oat.domains.cells.spatial.SpatialCell;
import com.oat.domains.cells.spatial.SpatialUtils;
import com.oat.domains.cells.spatial.algorithms.SpatialRepertoire;
import com.oat.domains.cells.spatial.problems.SpatialPatternRecognition;
import com.oat.utils.ArrayUtils;
import com.oat.utils.BinaryDecodeMode;
import com.oat.utils.BitStringUtils;
import com.oat.utils.EvolutionUtils;
import com.oat.utils.RandomUtils;

/**
 * Description: Bottom-up spatial organisation of components 
 *  
 * Date: 02/11/2007<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class SpatialComponentsBottomUp extends EpochAlgorithm<CellSet>
	implements SpatialRepertoire
{
	// config
	protected long seed = 3;
	protected int repertoireSize = 15;
	protected int selectionSize = 1;
	protected int cloningSize = 5;	
	protected double mutationRate = 1.0/64.0;
	
	// data
	protected Random rand;
	
	protected SpatialCell [][] red;
	protected SpatialCell [][] blue;
	protected SpatialCell [][] green;
	
	@Override
	protected LinkedList<CellSet> internalInitialiseBeforeRun(Problem problem)
	{
		rand = new Random(seed);		
		
		red = newRepertoire(0);
		blue = newRepertoire(1);
		green = newRepertoire(2);
		
		// no initial population
		return null;
	}	
	
	protected SpatialCell [][] newRepertoire(int gene)
	{
		SpatialCell [][] r = new SpatialCell[repertoireSize][repertoireSize];
		for (int i = 0; i < r.length; i++)
		{
			for (int j = 0; j < r[i].length; j++)
			{
				boolean [] data = RandomUtils.randomBitString(rand, 64);
				r[i][j] = new SpatialCell(data, gene);
				r[i][j].setCoord(new int[]{i, j});
			}
		}	
		return r;
	}
	
	
	protected LinkedList<SpatialCell> cloningAndMutation(SpatialCell current)
	{
		LinkedList<SpatialCell> newPop = new LinkedList<SpatialCell>();		
					
		for (int j = 0; j < cloningSize; j++)
		{
			// copy
			boolean [] cloneData = ArrayUtils.copyArray(current.getData());
			// mutate
			EvolutionUtils.binaryMutate(cloneData, rand, mutationRate);
			// store
			SpatialCell clone = new SpatialCell(cloneData, current.getGene());
			newPop.add(clone);
		}	
		
		return newPop;
	}
	
	protected void runCompetitiveReplacement(
			SpatialPatternRecognition p, 
			int subProblemNo,
			SpatialCell falseBmu,
			LinkedList<SpatialCell> clones,
			SpatialCell [][] repertoire)
	{		
		// get neighbours of the false bmu
		LinkedList<SpatialCell> neigh = SpatialUtils.getNeighbours(falseBmu, repertoire);			
		// evaluate the components in the unrelated neighbourhood
		evaluateComponents(p, subProblemNo, neigh);
		
		// do replacement
		for(SpatialCell c : clones)
		{
			int s = rand.nextInt(neigh.size());
			SpatialCell n = neigh.get(s);
			if(c.getScore() < n.getScore())
			{
				int [] o = n.getCoord();
				repertoire[o[0]][o[1]] = c;
				c.setCoord(o);
				neigh.remove(s);
			}
		}		
	}
	
	
	protected SpatialCell singleExposure(SpatialPatternRecognition p, int subProblemNo)
	{
		// get sub-bmu's
		SpatialCell [] subBMUs = new SpatialCell[3];		
		subBMUs[0] = evaluateComponentsAndGetBmu(p, subProblemNo, red);
		subBMUs[1] = evaluateComponentsAndGetBmu(p, subProblemNo, blue);
		subBMUs[2] = evaluateComponentsAndGetBmu(p, subProblemNo, green);
		// create the real bmu
		SpatialCell realBmu = createMasterCellFromDegenerateCells(subBMUs[0], subBMUs[1], subBMUs[2]);
		
		// match the aggregated BMU onto the to false repertoire
		SpatialCell[][] falseRep = getRepertoire();
		SpatialCell falseBmu = getFalseBmu(falseRep, realBmu);
		
		// do per-component cloning and mutation at this location
		cloningAndReplacement(p, subProblemNo, falseBmu, subBMUs[0], red);
		cloningAndReplacement(p, subProblemNo, falseBmu, subBMUs[1], blue);
		cloningAndReplacement(p, subProblemNo, falseBmu, subBMUs[2], green);
		
		return realBmu;
	}
	
	protected void cloningAndReplacement(
			SpatialPatternRecognition p, 
			int subProblemNo, 
			SpatialCell falseBmu,
			SpatialCell realBmu, 
			SpatialCell [][] repertoire)
	{		
		// do cloning and mutation
		LinkedList<SpatialCell> clones = cloningAndMutation(realBmu);
		// evaluate clones
		evaluateComponents(p, subProblemNo, clones);
		// do competative replacement
		runCompetitiveReplacement(p, subProblemNo, falseBmu, clones, repertoire);
	}
	
	
	protected void evaluateComponents(SpatialPatternRecognition p, int subProblemNo, LinkedList<SpatialCell> set)
	{
		for(SpatialCell c : set)
		{
			p.costSingleFeature(c, subProblemNo);
		}
	}
	
	protected SpatialCell getFalseBmu(SpatialCell[][] repertoire, SpatialCell realBmu)
	{
		LinkedList<SpatialCell> best = new LinkedList<SpatialCell>();
		
		for (int i = 0; i < repertoire.length; i++)
		{
			for (int j = 0; j < repertoire[i].length; j++)
			{
				double score = BitStringUtils.hammingDistance(realBmu.getData(), repertoire[i][j].getData());
				repertoire[i][j].evaluated(score);
				
				
				// check for empty case
				if(best.isEmpty())
				{
					best.add( repertoire[i][j]);
				}
				// check for the same
				else if(repertoire[i][j].getScore() == best.getFirst().getScore())
				{
					best.add(repertoire[i][j]);
				}
				// check for better				
				else if(repertoire[i][j].getScore() < best.getFirst().getScore())
				{
					best.clear();
					best.add(repertoire[i][j]);
				}
			}
		}
		
		if(best.size() == 1)
		{
			return best.getFirst();
		}
		
		// tie handling
		
		// randomise the set
		return best.get(rand.nextInt(best.size()));
	}
	
	
	protected SpatialCell evaluateComponentsAndGetBmu(SpatialPatternRecognition p, int subProblemNo, SpatialCell [][] repertoire)
	{
		LinkedList<SpatialCell> best = new LinkedList<SpatialCell>();
		
		for (int i = 0; i < repertoire.length; i++)
		{
			for (int j = 0; j < repertoire[i].length; j++)
			{
				// component
				p.costSingleFeature(repertoire[i][j], subProblemNo);
				
				// check for empty case
				if(best.isEmpty())
				{
					best.add( repertoire[i][j]);
				}
				// check for the same
				else if(repertoire[i][j].getScore() == best.getFirst().getScore())
				{
					best.add(repertoire[i][j]);
				}
				// check for better				
				else if(repertoire[i][j].getScore() < best.getFirst().getScore())
				{
					best.clear();
					best.add(repertoire[i][j]);
				}
			}
		}
		
		if(best.size() == 1)
		{
			return best.getFirst();
		}
		
		// random tie handling
		return best.get(rand.nextInt(best.size()));
	}
	

	@Override
	protected LinkedList<CellSet> internalExecuteEpoch(Problem problem, LinkedList<CellSet> cp)
	{
		SpatialPatternRecognition p = (SpatialPatternRecognition) problem;			
		int numSubProblems = p.getNumInfections();
		
		Cell [] bmus = new Cell[numSubProblems];				
		
		// process each sub problem
		for (int i = 0; i < numSubProblems; i++)
		{	
			bmus[i] = singleExposure(p, i);
		}	
		
		// create a cell set
		LinkedList<CellSet> nextgen = new LinkedList<CellSet>();
		nextgen.add(new CellSet(bmus));
		return nextgen;
	}

	@Override
	protected void internalPostEvaluation(Problem problem, LinkedList<CellSet> oldPopulation, LinkedList<CellSet> newPopulation)
	{}

	@Override
	public void validateConfiguration() throws InvalidConfigurationException
	{
		if(repertoireSize<0)
		{
			throw new InvalidConfigurationException("Invalid repertoireSize " + repertoireSize);
		}
	}
	
	protected SpatialCell createMasterCellFromDegenerateCells(Cell g1, Cell g2, Cell g3)
	{
		boolean [] b = new boolean[3*64];
		
		// 1
		int off = 0;
		System.arraycopy(g1.getData(), 0, b, 0, g1.getData().length);
		off += g1.getData().length;
		// 2
		System.arraycopy(g2.getData(), 0, b, off, g2.getData().length);
		off += g2.getData().length;
		// 3
		System.arraycopy(g3.getData(), 0, b, off, g3.getData().length);		
		off += g3.getData().length;
		
		if(off != b.length)
		{
			throw new RuntimeException("Error in master cell creation");
		}
		SpatialCell s = new SpatialCell(b);
		
		// check if all the components have been decoded
		if(g1.getDecodedData()!=null && g2.getDecodedData() != null && g3.getDecodedData() != null)
		{
			double [] decoded = new double[3];
			decoded[0] = g1.getDecodedData()[0];
			decoded[1] = g2.getDecodedData()[0];
			decoded[2] = g3.getDecodedData()[0];
			// store
			s.setDecodedData(decoded);
		}
		
		return s;
	}	

	@Override
	public String getName()
	{
		return "Degenerate Component (bottom-up)";
	}

	public long getSeed()
	{
		return seed;
	}

	public void setSeed(long seed)
	{
		this.seed = seed;
	}

	public SpatialCell[][] getRepertoire()
	{
		SpatialCell [][] r = new SpatialCell[repertoireSize][repertoireSize];
		
		for (int i = 0; i < repertoireSize; i++)
		{
			for (int j = 0; j < repertoireSize; j++)
			{
				r[i][j] = createMasterCellFromDegenerateCells(red[i][j], blue[i][j], green[i][j]);
				r[i][j].setCoord(new int[]{i,j});
				// decode if needed
				if(r[i][j].getDecodedData() == null)
				{
					double [] data = BitStringUtils.decode(BinaryDecodeMode.GrayCode, r[i][j].getData(), Optimisation.minmax);
					r[i][j].setDecodedData(data);
				}
			}
		}
		
		return r;
	}
}

