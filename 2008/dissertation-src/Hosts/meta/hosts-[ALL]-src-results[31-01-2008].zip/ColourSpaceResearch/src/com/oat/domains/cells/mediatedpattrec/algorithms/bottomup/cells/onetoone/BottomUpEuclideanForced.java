/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006, 2007  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.cells.mediatedpattrec.algorithms.bottomup.cells.onetoone;

import java.util.Collections;
import java.util.LinkedList;
import java.util.Random;

import com.oat.EpochAlgorithm;
import com.oat.InvalidConfigurationException;
import com.oat.Problem;
import com.oat.domains.cells.mediatedpattrec.CellUtils;
import com.oat.domains.cells.mediatedpattrec.algorithms.MediatedClonalSelection;
import com.oat.domains.cells.mediatedpattrec.problems.MediatedPatternRecognition;
import com.oat.domains.cells.opt.Cell;
import com.oat.domains.cells.patrec.CellSet;
import com.oat.utils.AlgorithmUtils;

/**
 * Description: 
 *  
 * Date: 12/11/2007<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class BottomUpEuclideanForced extends EpochAlgorithm<CellSet>	
	implements MediatedClonalSelection
{
	// config
	protected long seed = 1;
	
	protected int numBCells = 50;
	protected int numTCells = 50;
	
	protected int numBCellClones = 5;
	protected int numTCellClones = 5;
	
	// data
	protected Random rand;
	protected LinkedList<Cell> bcells;
	protected LinkedList<Cell> tcells;	
	
	
	@Override
	protected LinkedList<CellSet> internalInitialiseBeforeRun(Problem problem)
	{	
		rand = new Random(seed);			
		// bcells
		bcells = CellUtils.getRandomRepertoire(rand, numBCells);			
		// tcells
		tcells = CellUtils.getRandomRepertoire(rand, numTCells);
		
		// no initial population
		return null;
	}
	
	@Override
	public LinkedList<Cell> getBCells()
	{
		return bcells;
	}

	@Override
	public LinkedList<Cell> getTCells()
	{
		return tcells;
	}	

	
	protected void evaluateRepertoireAgainstCellEuclidean(Cell cell, LinkedList<Cell> repertoire)
	{		
		CellUtils.forceDecode(cell);
		double [] base = cell.getDecodedData();
		
		for(Cell c : repertoire)
		{			
			CellUtils.forceDecode(c);
			double dist = AlgorithmUtils.euclideanDistance(base, c.getDecodedData());
			c.evaluated(dist);
		}
	}	
	protected void evaluateRepertoireAgainstAntigenEuclidean(MediatedPatternRecognition p, int pNum, LinkedList<Cell> repertoire)
	{
		for(Cell c : repertoire)
		{
			p.costCell(c, pNum);
		}
	}
	
	
	protected Cell selectBCell(MediatedPatternRecognition p, int pNum, LinkedList<Cell> bCells)
	{
		// assess first
		evaluateRepertoireAgainstAntigenEuclidean(p, pNum, bCells);		
		// order by utility
		Collections.shuffle(bCells, rand);
		Collections.sort(bCells);	
		// tie handling
		return bCells.getFirst();
	}
	
	protected Cell selectTCell(Cell bcell, LinkedList<Cell> tCells)
	{		
		// assess first
		evaluateRepertoireAgainstCellEuclidean(bcell, tCells);		
		// order by utility
		Collections.shuffle(tCells, rand);
		Collections.sort(tCells);
		return tCells.getFirst();
	}
	

	protected Cell exposure(MediatedPatternRecognition p, int patternNo)
	{		
		// activate b cell
		Cell activatedBCell = selectBCell(p, patternNo, bcells);
		// activate t cell
		Cell activatedTCell = selectTCell(activatedBCell, tcells);
		
		return activatedTCell;		
	}	
	
	protected void backPropagationForced(MediatedPatternRecognition p, int patternNo)
	{
		// select the optimal T-cell
		Cell activatedTCell = selectBCell(p, patternNo, tcells);
		// back-propagate the optimal t cell
		backPropagateTCells(p, patternNo, activatedTCell);
		
		// select an optimal b cell (same as the foward pass)
		Cell activatedBCell = selectBCell(p, patternNo, bcells);
		// back propagate b cells based on optimal t cell
		backPropagateBCells(activatedBCell, activatedTCell);		
	}
	
	
	protected void backPropagateBCells(Cell bcell, Cell tcell)
	{			
		// clone b cell
		LinkedList<Cell> bCellClones = CellUtils.cloningAndMutation(bcell, numBCellClones, rand);
		
		// evaluate clones against t-cell
		evaluateRepertoireAgainstCellEuclidean(tcell, bCellClones); 
		// evaluate repertoire against t-cell
		evaluateRepertoireAgainstCellEuclidean(tcell, bcells);
		
		// similarity-affinity replacement (exclude clones)
		LinkedList<Cell> bCellExclude = new LinkedList<Cell>();
		for(Cell c : bCellClones)
		{
			Cell mostSimilar = CellUtils.getMostSimilarEuclideanWithExclusion(c, bcells, bCellExclude);				
			if(c.getScore() < mostSimilar.getScore())
			{
				bcells.remove(mostSimilar);
				bcells.add(c);
				bCellExclude.add(c);
			}
		}
	}
	
	protected void backPropagateTCells(MediatedPatternRecognition p, int patternNo, Cell tcell)
	{		
		// clone t cell
		LinkedList<Cell> tCellClones = CellUtils.cloningAndMutation(tcell, numTCellClones, rand);
		
		// evaluate clones against antigen
		evaluateRepertoireAgainstAntigenEuclidean(p, patternNo, tCellClones); 
		// evaluate repertoire
		evaluateRepertoireAgainstAntigenEuclidean(p, patternNo, tcells);
		
		// similarity-affinity replacement (exclude clones)
		LinkedList<Cell> tCellExclude = new LinkedList<Cell>();
		for(Cell c : tCellClones)
		{
			Cell mostSimilar = CellUtils.getMostSimilarEuclideanWithExclusion(c, tcells, tCellExclude);
			if(c.getScore() < mostSimilar.getScore())
			{
				tcells.remove(mostSimilar);
				tcells.add(c);
				tCellExclude.add(c);
			}
		}
	}


	@Override
	protected LinkedList<CellSet> internalExecuteEpoch(Problem problem, LinkedList<CellSet> cp)
	{
		MediatedPatternRecognition p = (MediatedPatternRecognition) problem;			
		int numSubProblems = p.getNumInfections();		
		Cell [] bmus = new Cell[numSubProblems];		
		
		// process each sub problem
		for (int i = 0; i < numSubProblems; i++)
		{
			// expose
			bmus[i] = exposure(p, i);
			// forced feedback
			backPropagationForced(p, i);
		}		
		
		// create a cell set
		LinkedList<CellSet> nextgen = new LinkedList<CellSet>();
		nextgen.add(new CellSet(bmus));
		return nextgen;
	}

	@Override
	protected void internalPostEvaluation(Problem problem, LinkedList<CellSet> oldPopulation, LinkedList<CellSet> newPopulation)
	{}

	@Override
	public void validateConfiguration() throws InvalidConfigurationException
	{}

	@Override
	public String getName()
	{
		return "BottomUp One-to-One Euclidean (Forced)";
	}

	public long getSeed()
	{
		return seed;
	}

	public void setSeed(long seed)
	{
		this.seed = seed;
	}
}
