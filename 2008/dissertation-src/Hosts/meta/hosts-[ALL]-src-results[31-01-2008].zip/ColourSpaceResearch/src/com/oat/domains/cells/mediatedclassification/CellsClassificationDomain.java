/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006, 2007  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.cells.mediatedclassification;

import java.util.Collections;
import java.util.LinkedList;

import com.oat.Algorithm;
import com.oat.Domain;
import com.oat.Problem;
import com.oat.RunProbe;
import com.oat.StopCondition;
import com.oat.domains.cells.mediatedclassification.algorithms.degenerate.DegenerateComponent;
import com.oat.domains.cells.mediatedclassification.algorithms.feedback.FeedbackPerPattern;
import com.oat.domains.cells.mediatedclassification.gui.CellularClassificationMasterPanel;
import com.oat.domains.cells.mediatedclassification.problems.PatternClassification;
import com.oat.explorer.gui.panels.MasterPanel;
import com.oat.explorer.gui.plot.GenericProblemPlot;
import com.oat.stopcondition.FoundOptimaOrMaxEpochs;
import com.oat.stopcondition.FoundOptima;

/**
 * Description: 
 *  
 * Date: 05/11/2007<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class CellsClassificationDomain extends Domain
{
	@Override
	public MasterPanel getExplorerPanel()
	{
		return new CellularClassificationMasterPanel(this);
	}

	@Override
	public String getHumanReadableName()
	{
		return "Cellular Classification";
	}

	@Override
	public String getShortName()
	{
		return "cellpatrec";
	}

	@Override
	public Algorithm[] loadAlgorithmList() throws Exception
	{
		return new Algorithm[]
		                     {
				new FeedbackPerPattern(),
				new DegenerateComponent()
		                     };
	}

	@Override
	public Problem[] loadProblemList() throws Exception
	{
		return new Problem[]
		                   {
				new PatternClassification()
		                   };
	}

	@Override
	public GenericProblemPlot prepareProblemPlot()
	{
		return null;
	}
	
	@Override
	public LinkedList<StopCondition> loadDomainStopConditions()
	{
		LinkedList<StopCondition> list = super.loadDomainStopConditions();
		list.add(new FoundOptima());		
		list.add(new FoundOptimaOrMaxEpochs());
		Collections.sort(list);		
		return list;
	}
	
	@Override
	public LinkedList<RunProbe> loadDomainRunProbes()
	{
		LinkedList<RunProbe> list = super.loadDomainRunProbes();		

		
		Collections.sort(list);		
		return list;
	}
}
