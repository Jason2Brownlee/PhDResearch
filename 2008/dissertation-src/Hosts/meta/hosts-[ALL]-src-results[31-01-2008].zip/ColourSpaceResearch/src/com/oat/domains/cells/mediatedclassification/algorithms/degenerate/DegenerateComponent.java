/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006, 2007  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.cells.mediatedclassification.algorithms.degenerate;

import java.util.Collections;
import java.util.LinkedList;
import java.util.Random;

import com.oat.EpochAlgorithm;
import com.oat.InvalidConfigurationException;
import com.oat.Problem;
import com.oat.domains.cells.mediatedclassification.ClassificationCell;
import com.oat.domains.cells.mediatedclassification.ClassificationSolution;
import com.oat.domains.cells.mediatedclassification.MaskMappingCell;
import com.oat.domains.cells.mediatedclassification.problems.PatternClassification;
import com.oat.domains.cells.opt.Cell;
import com.oat.domains.cells.opt.problems.Optimisation;
import com.oat.utils.AlgorithmUtils;
import com.oat.utils.ArrayUtils;
import com.oat.utils.BinaryDecodeMode;
import com.oat.utils.BitStringUtils;
import com.oat.utils.EvolutionUtils;
import com.oat.utils.RandomUtils;

/**
 * Description: Degenerate component 
 *  
 * Date: 06/11/2007<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class DegenerateComponent extends EpochAlgorithm<ClassificationSolution>
{
	// config
	protected long seed = 1;
	protected int repertoireSize = 40;
	protected int bCellSelectionSize = 5; // all for a given exemplar 
	protected int cloningSize = 2;
	
	
	// data
	protected Random rand;	
	protected LinkedList<Cell>[] bcells;
	protected LinkedList<ClassificationCell> tcells;
	
	
	@Override
	protected LinkedList<ClassificationSolution> internalInitialiseBeforeRun(Problem problem)
	{
		PatternClassification p = (PatternClassification) problem;
		rand = new Random(seed);	
		
		// bcells 
		bcells = new LinkedList[3];
		for (int i = 0; i < bcells.length; i++)
		{
			bcells[i] = new LinkedList<Cell>();
			
			for (int j = 0; j < repertoireSize; j++)
			{
				boolean [] data = RandomUtils.randomBitString(rand, 64);
				bcells[i].add(new Cell(data, i));
			}
		}
		
		// t cells
		tcells = new LinkedList<ClassificationCell>();		
		for (int i = 0; i < repertoireSize; i++)
		{			
			// t cell
			boolean [] tdata = RandomUtils.randomBitString(rand, 3, 64);			
			double [] d = BitStringUtils.decode(BinaryDecodeMode.GrayCode, tdata, Optimisation.minmax);
			int tclass = p.classify(d);			
			ClassificationCell cc = new ClassificationCell(tclass, tdata);
			cc.setDecodedData(d);
			tcells.add(cc);
		}
		
		// no initial population
		return null;
	}	
	
	
	protected LinkedList<Cell> cloningAndMutateBCell(Cell bmu)
	{
		LinkedList<Cell> newPop = new LinkedList<Cell>();
					
		for (int j = 0; j < cloningSize; j++)
		{
			// copy
			boolean [] cloneData = ArrayUtils.copyArray(bmu.getData());
			// mutate
			EvolutionUtils.binaryMutate(cloneData, rand, 1.0/cloneData.length);
			// store
			Cell clone = new Cell(cloneData, bmu.getGene());
			newPop.add(clone);
		}
		
		
		return newPop;
	}
	
//	protected LinkedList<ClassificationCell> cloningAndMutateTCell(ClassificationCell bmu)
//	{
//		LinkedList<ClassificationCell> newPop = new LinkedList<ClassificationCell>();
//					
//		for (int j = 0; j < cloningSize; j++)
//		{
//			// copy
//			boolean [] cloneData = ArrayUtils.copyArray(bmu.getData());			
//			// mutate
//			EvolutionUtils.binaryMutate(cloneData, rand, mutationRate);
//			// store
//			ClassificationCell clone = new ClassificationCell(bmu.getClassification(), cloneData);
//			newPop.add(clone);
//		}		
//		
//		return newPop;
//	}
	
	
	protected ClassificationCell evaluateAndSelectTCell(Cell bcell, LinkedList<ClassificationCell> pop)
	{		
		ClassificationCell best = null;
		int bestScore = Integer.MAX_VALUE; 
		
		boolean [] data = bcell.getData();
		
		// assess first
		for(ClassificationCell c : pop)
		{
			boolean [] d = c.getData();
			int count = 0;			
			for (int i = 0; i < data.length; i++)
			{
				count += (data[i] != d[i]) ? 1 : 0;
			}
			
			if(count < bestScore)
			{
				bestScore = count;
				best = c;
			}
		}
		
		return best;
	}
	
	
	protected LinkedList<Cell> evaluateAndSelectBCell(
			PatternClassification p, 
			LinkedList<Cell> pop, 
			int subProblemNumber)
	{
		// assess first
		for(Cell c : pop)
		{
			p.costSingleFeature(c, subProblemNumber);
		}		
		// order by utility
		Collections.sort(pop);	
		
		LinkedList<Cell> selected = new LinkedList<Cell>();
		for (int i = 0; i < bCellSelectionSize; i++)
		{
			selected.add(pop.get(i));
		}
		
		return selected;
	}	
	
	protected LinkedList<ClassificationCell> getMostActivatedTcell(LinkedList<ClassificationCell> pop)
	{
		LinkedList<ClassificationCell> best = new LinkedList<ClassificationCell>();
		
		for (int i = 0; i < pop.size(); i++)
		{			
			// check for empty case
			if(best.isEmpty())
			{
				best.add(pop.get(i));
			}			
			// check for better
			else if(pop.get(i).getScore() < best.getFirst().getScore())
			{
				best.clear();
				best.add(pop.get(i));
			}			
			// check for the same
			else if(pop.get(i).getScore() == best.getFirst().getScore())
			{
				best.add(pop.get(i));
			}
		}
		
		return best;
		
//		if(best.size() == 1)
//		{
//			return best.getFirst();
//		}
		
		// tie handling
		//return best.get(rand.nextInt(best.size()));
	}
	
	protected int exposure(PatternClassification p, int patternNo)
	{
		// zero score for all t cells
		for(ClassificationCell c : tcells)
		{
			c.evaluated(0);			
		}
		
		// activate subcomponents
		LinkedList<Cell> [] activatedSubComponents = new LinkedList[3];		
		LinkedList<ClassificationCell> [] activatedTCells = new LinkedList[3];
		
		for (int i = 0; i < activatedSubComponents.length; i++)
		{
			// activate subcomponents
			activatedSubComponents[i] = evaluateAndSelectBCell(p, bcells[i], patternNo);
			activatedTCells[i] = new LinkedList<ClassificationCell>();
			// map subcomponents onto t cells
			for(Cell c: activatedSubComponents[i])
			{
				ClassificationCell activated = evaluateAndSelectTCell(c, tcells);
				activated.evaluated(activated.getScore()+1);
				activatedTCells[i].add(activated);
			}
		}
		 
		// get the most activated t cell
		LinkedList<ClassificationCell> mostAcitvatedTCellSet = getMostActivatedTcell(tcells);
		
		// find consensus
		int [] vote = new int[8];
		for(ClassificationCell c : mostAcitvatedTCellSet)
		{
			vote[c.getClassification()]++;
		}
		
		int best = 0;
		for (int i = 1; i < vote.length; i++)
		{
			if(vote[i] > vote[best])
			{
				best = i;
			}
		}	
		
		//System.out.println("size="+mostAcitvatedTCellSet.size() + ", " +((vote[best] == p.getClassIdForProblem(patternNo))? "correct" : "incorrect"));
		
		//if(vote[best] == p.getClassIdForProblem(patternNo))
		{ 
			LinkedList<ClassificationCell> bestset = new LinkedList<ClassificationCell>();
			for(ClassificationCell c : mostAcitvatedTCellSet)
			{
				if(c.getClassification() == vote[best])
				{
					bestset.add(c);
				}
			}			
			
			System.out.println("size="+bestset.size());
			
			// NOTE: i could find all activated cells that match onto this and proliferate them		
			// clone and proliferate all components that matched onto this cell		
			for (int i = 0; i < activatedSubComponents.length; i++)
			{
				LinkedList<Cell> componentClones = new LinkedList<Cell>();
				int count = 0;
				
				for (int j = 0; j < activatedTCells[i].size(); j++)
				{
					//if(activatedTCells[i].get(j) == mostAcitvatedTCell)
					if(bestset.contains((activatedTCells[i].get(j))))
					{
						count++; // number of activated clones that made it
						LinkedList<Cell> clones = cloningAndMutateBCell(activatedSubComponents[i].get(j));
						componentClones.addAll(clones);
					}
				}
				
				// ad together and select those from the mix that are a better fit for the t cell
				
				if(!componentClones.isEmpty())
				{
					bcells[i].removeAll(activatedSubComponents[i]);
					
					// mix all together
					componentClones.addAll(activatedSubComponents[i]);
					// evaluate all with regard to the match to the t cell, select the n-best to integrate
					for(Cell c : componentClones)
					{
						// decode the single value
						if(c.getDecodedData() == null)
						{
							// decode will make sure the cell has enough bits!
							double [] data = BitStringUtils.decode(BinaryDecodeMode.GrayCode, c.getData(), new double[][]{Optimisation.minmax[c.getGene()]});
							c.setDecodedData(data);
						}
						
						double score = AlgorithmUtils.euclideanDistance(c.getDecodedData(), new double[]{p.getSubproblems()[patternNo].getGlobalOptima()[0].getCoordinate()[c.getGene()]});
						c.evaluated(score);
					}
					
					Collections.sort(componentClones);
					for (int j = 0; j < bCellSelectionSize; j++)
					{
						bcells[i].add(componentClones.get(j));
					}
				}			
			}
		}
		
		
		//return mostAcitvatedTCell.getClassification();
		return vote[best];
	}
	
	protected void replacementBCells(LinkedList<MaskMappingCell> pop, LinkedList<MaskMappingCell> clones)
	{		
		// clones can never replace each other, replace the 5 most similar with the clones
		
		for(MaskMappingCell c : clones)
		{
			MaskMappingCell s = getMostSimilarWithExclusion(c, pop, clones);
			pop.remove(s);
			pop.add(c);
		}
	}
	
	protected void replacementTCells(LinkedList<ClassificationCell> pop, LinkedList<ClassificationCell> clones)
	{		
		// clones can never replace each other, replace the 5 most similar with the clones
		
		for(ClassificationCell c : clones)
		{
			ClassificationCell s = getMostSimilarWithExclusion(c, pop, clones);
			pop.remove(s);
			pop.add(c);
		}
	}
	
	
	public static <C extends Cell> C getMostSimilarWithExclusion(C cell, LinkedList<C> set, LinkedList<C> exclude)
	{
		double  min = Double.POSITIVE_INFINITY;
		C best = null;
		
		for(C c : set)
		{
			if(exclude.contains(c))
			{
				continue;
			}
			
			double d = BitStringUtils.hammingDistance(cell.getData(), c.getData());
			if(d < min)
			{
				min = d;
				best = c;
			}
		}
		
		return best;		
	}

	@Override
	protected LinkedList<ClassificationSolution> internalExecuteEpoch(Problem problem, LinkedList<ClassificationSolution> cp)
	{
		PatternClassification p = (PatternClassification) problem;			
		int numSubProblems = p.getNumPatterns();
		
		int [] classifications = new int[numSubProblems];	
		
		// process each sub problem
		for (int i = 0; i < numSubProblems; i++)
		{
			classifications[i] = exposure(p, i);
		}		
		
		// create a cell set
		LinkedList<ClassificationSolution> nextgen = new LinkedList<ClassificationSolution>();
		nextgen.add(new ClassificationSolution(classifications));
		return nextgen;
	}

	@Override
	protected void internalPostEvaluation(Problem problem, LinkedList<ClassificationSolution> oldPopulation, LinkedList<ClassificationSolution> newPopulation)
	{}

	@Override
	public void validateConfiguration() throws InvalidConfigurationException
	{
		if(repertoireSize<0)
		{
			throw new InvalidConfigurationException("Invalid repertoireSize " + repertoireSize);
		}
	}

	@Override
	public String getName()
	{
		return "Degenerate Components (Many-to-One)";
	}

	public long getSeed()
	{
		return seed;
	}

	public void setSeed(long seed)
	{
		this.seed = seed;
	}
}
