/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006, 2007  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.cells.network.algorithms.recurrent;

import java.util.LinkedList;
import java.util.Random;

import com.oat.EpochAlgorithm;
import com.oat.InvalidConfigurationException;
import com.oat.Problem;
import com.oat.domains.cells.mediatedpattrec.CellUtils;
import com.oat.domains.cells.mediatedpattrec.MappedCell;
import com.oat.domains.cells.network.algorithms.Tissue;
import com.oat.domains.cells.network.algorithms.ClonalSelectionMapping;
import com.oat.domains.cells.network.algorithms.OneReceptorQueueModel;
import com.oat.domains.cells.network.problems.PRProblem;
import com.oat.domains.cells.opt.Cell;
import com.oat.domains.cells.patrec.CellSet;
import com.oat.utils.AlgorithmUtils;

/**
 * Description: 
 *  
 * Date: 13/11/2007<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class RecurrentMapping extends EpochAlgorithm<CellSet>
	implements Tissue<MappedCell>, ClonalSelectionMapping<MappedCell>, OneReceptorQueueModel
{
	// config
	protected long seed = 1;
	protected int repertoireSize = -1;
	protected int selectionSize = 1;
	protected int cloningSize = 5;
	
	// data
	protected Random rand;
	protected LinkedList<MappedCell> cells;
	protected MappedCell lastExposure;
	protected LinkedList<MappedCell[]> epochPairs; 
	
	
	@Override
	protected LinkedList<CellSet> internalInitialiseBeforeRun(Problem problem)
	{		
		rand = new Random(seed);
		repertoireSize = ((PRProblem)problem).getNumInfections() * 10;
		lastExposure = null;
		epochPairs = new LinkedList<MappedCell[]>();
		cells = CellUtils.getRandomMappedRepertoire(rand, repertoireSize);		
		// no initial population
		return null;
	}	
	
	@Override
	public LinkedList<MappedCell[]> getEpochPairs()
	{
		return epochPairs;
	}
	
	@Override
	public LinkedList<MappedCell> getRepertoire()
	{
		return cells;
	}	
	

	protected void assessRepertoireAgainstAntigen(PRProblem p, int pattNo, LinkedList<MappedCell> repertoire)
	{
		for(Cell c : repertoire)
		{
			p.costCell(c, pattNo);
		}
	}	
	
	protected void assessRepertoireAgainstCell(MappedCell bmu, LinkedList<MappedCell> repertoire)
	{
		// decode the second representation
		CellUtils.forceDecodeSecondaryMapping(bmu);
		// assess repertoire against the second representation
		for(Cell c : repertoire)
		{
			CellUtils.forceDecode(c);
			double cost = AlgorithmUtils.euclideanDistance(bmu.getDecoded2(), c.getDecodedData());
			c.evaluated(cost);
		}
	}
	
	
	protected void replaceIntoRepertoire(LinkedList<MappedCell> progeny, LinkedList<MappedCell> repertoire)
	{
		for(MappedCell c : progeny)
		{
			// Euclidean similarity tournament for competition
			MappedCell similar = CellUtils.getMostSimilarEuclideanWithExclusion(c, repertoire, progeny);
			// fitness tournament for resources
			if(c.getScore() < similar.getScore())
			{
				repertoire.remove(similar);
				repertoire.add(c);
			}
		}
	}	
	
	protected MappedCell exposure(MappedCell bmu)
	{
		// assess repertoire against the bmu
		assessRepertoireAgainstCell(bmu, cells);
		// select the activated set
		LinkedList<MappedCell> selected = CellUtils.selectActivatedSet(cells, rand, selectionSize);
		// cloning and mutation
		LinkedList<MappedCell> clones = CellUtils.cloningAndMutationMapping(selected, cloningSize, rand);
		// assess the clones against the antigen
		assessRepertoireAgainstCell(bmu, clones);	
		// compete for position within the repertoire
		replaceIntoRepertoire(clones, cells);
		// store epoch pairs
		epochPairs.add(new MappedCell[]{bmu, selected.getFirst()});
		// return the bmu
		return selected.getFirst();
	}
	
	protected MappedCell exposure(PRProblem p, int pattNo)
	{			
		// assess repertoire
		assessRepertoireAgainstAntigen(p, pattNo, cells);
		// select the activated set
		LinkedList<MappedCell> selected = CellUtils.selectActivatedSet(cells, rand, selectionSize);
		// cloning and mutation
		LinkedList<MappedCell> clones = CellUtils.cloningAndMutationMapping(selected, cloningSize, rand);
		// assess the clones against the antigen
		assessRepertoireAgainstAntigen(p, pattNo, clones);		
		// compete for position within the repertoire
		replaceIntoRepertoire(clones, cells);
		// return the bmu
		return selected.getFirst();
	}
	
	protected Cell exposureManager(PRProblem p, int pattNo)
	{
		// normal exposure
		MappedCell bmuT0 = exposure(p, pattNo);
		MappedCell bmuT_1 = null;
		
		// t-1 exposure, it will be null on the first exposure of the first epoch
		if(lastExposure != null)
		{
			bmuT_1 = exposure(lastExposure);
		}
		
		// update last exposure information 
		lastExposure = bmuT0;		
		// return the normal exposure bmu
		return bmuT0;
	}
	

	@Override
	protected LinkedList<CellSet> internalExecuteEpoch(Problem problem, LinkedList<CellSet> cp)
	{
		PRProblem p = (PRProblem) problem;		
		Cell [] bmus = new Cell[p.getNumInfections()];		
		epochPairs.clear();
		// process each sub problem
		for (int i = 0; i < bmus.length; i++)
		{			
			// exposure
			bmus[i] = exposureManager(p, i);			
		}		
		// create a cell set
		LinkedList<CellSet> nextgen = new LinkedList<CellSet>();
		nextgen.add(new CellSet(bmus));
		return nextgen;
	}

	@Override
	protected void internalPostEvaluation(Problem problem, LinkedList<CellSet> oldPopulation, LinkedList<CellSet> newPopulation)
	{}

	@Override
	public void validateConfiguration() throws InvalidConfigurationException
	{}

	@Override
	public String getName()
	{
		return "Recurrent Remapped";
	}

	public long getSeed()
	{
		return seed;
	}

	public void setSeed(long seed)
	{
		this.seed = seed;
	}
}
