/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006, 2007  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.cells.mediatedpattrec.algorithms.bottomup.cells.onetoone;

import java.util.Collections;
import java.util.LinkedList;
import java.util.Random;

import com.oat.EpochAlgorithm;
import com.oat.InvalidConfigurationException;
import com.oat.Problem;
import com.oat.domains.cells.mediatedpattrec.CellUtils;
import com.oat.domains.cells.mediatedpattrec.MappedCell;
import com.oat.domains.cells.mediatedpattrec.algorithms.MediatedClonalSelection;
import com.oat.domains.cells.mediatedpattrec.problems.MediatedPatternRecognition;
import com.oat.domains.cells.opt.Cell;
import com.oat.domains.cells.patrec.CellSet;
import com.oat.utils.AlgorithmUtils;

/**
 * Description: 
 *  
 * Date: 12/11/2007<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class BottomUpMappingEuclideanForced extends EpochAlgorithm<CellSet>	
	implements MediatedClonalSelection
{
	// config
	protected long seed = 1;
	
	protected int numBCells = 50;
	protected int numTCells = 50;
	
	protected int numBCellClones = 5;
	protected int numTCellClones = 5;		
	
	// data
	protected Random rand;
	protected LinkedList<MappedCell> bcells;
	protected LinkedList<MappedCell> tcells;	
	
	
	@Override
	protected LinkedList<CellSet> internalInitialiseBeforeRun(Problem problem)
	{	
		rand = new Random(seed);			
		// bcells
		bcells = CellUtils.getRandomMappedRepertoire(rand, numBCells);			
		// tcells
		tcells = CellUtils.getRandomMappedRepertoire(rand, numTCells);
		
		// no initial population
		return null;
	}
	
	@Override
	public LinkedList<MappedCell> getBCells()
	{
		return bcells;
	}

	@Override
	public LinkedList<MappedCell> getTCells()
	{
		return tcells;
	}	

	
	protected void evaluateRepertoireAgainstSecondaryRepresentation(MappedCell cell, LinkedList<MappedCell> repertoire)
	{				
		// decode secondary representation
		CellUtils.forceDecodeSecondaryMapping(cell);
		double [] mapping = cell.getDecoded2();
		
		for(MappedCell c : repertoire)
		{			
			CellUtils.forceDecodeSecondaryMapping(c);
			// secondary representation
			double dist = AlgorithmUtils.euclideanDistance(mapping, c.getDecoded2());
			c.evaluated(dist);
		}
	}	
	protected void evaluateRepertoireAgainstAntigenEuclidean(MediatedPatternRecognition p, int pNum, LinkedList<MappedCell> repertoire)
	{
		for(MappedCell c : repertoire)
		{
			p.costCell(c, pNum);
		}
	}
	
	
	protected MappedCell selectBCell(MediatedPatternRecognition p, int pNum, LinkedList<MappedCell> bCells)
	{
		// assess first
		evaluateRepertoireAgainstAntigenEuclidean(p, pNum, bCells);		
		// order by utility
		Collections.shuffle(bCells, rand);
		Collections.sort(bCells);	
		// tie handling
		return bCells.getFirst();
	}
	
	protected MappedCell selectTCell(MappedCell bcell, LinkedList<MappedCell> tCells)
	{		
		// assess first
		evaluateRepertoireAgainstSecondaryRepresentation(bcell, tCells);		
		// order by utility
		Collections.shuffle(tCells, rand);
		Collections.sort(tCells);
		return tCells.getFirst();
	}
	

	protected MappedCell exposure(MediatedPatternRecognition p, int patternNo)
	{			
		// activate b cell against antigen
		MappedCell activatedBCell = selectBCell(p, patternNo, bcells);
		// activate t cell against activated b-cell
		MappedCell activatedTCell = selectTCell(activatedBCell, tcells);
		// back propagate bcells
		//backPropagateBCells(activatedBCell, activatedTCell);
		// back propagate tcells
		//backPropagateTCells(p, patternNo, activatedTCell);
		
		return activatedTCell;		
	}	
	
	protected void backPropagate(MediatedPatternRecognition p, int patternNo)
	{
		// select the best b-cell and tcell
		MappedCell activatedBCell = selectBCell(p, patternNo, bcells);
		MappedCell activatedTCell = selectBCell(p, patternNo, tcells);
	
		// back propagate the best-bcell against the best t cell
		backPropagateBCells(activatedBCell, activatedTCell);
		// back propagate the best t-cell against antigen
		backPropagateTCells(p, patternNo, activatedTCell);
	}
	
	
	protected void backPropagateBCells(MappedCell bcell, MappedCell tcell)
	{			
		// clone b cell
		LinkedList<MappedCell> bCellClones = CellUtils.cloningAndMutation(bcell, numBCellClones, rand);		
		// force decode the upfront selection for the clones
		for(MappedCell c : bCellClones)
		{
			CellUtils.forceDecode(c);
		}
		// assess clones with regard to their mapping to the activated t-cell
		evaluateRepertoireAgainstSecondaryRepresentation(tcell, bCellClones); 
		// assess the repertoire with regard to their mapping to the activated t-cell
		evaluateRepertoireAgainstSecondaryRepresentation(tcell, bcells);		
		// similarity-affinity replacement (exclude clones)
		LinkedList<MappedCell> bCellExclude = new LinkedList<MappedCell>();
		for(MappedCell c : bCellClones)
		{
			// most similar based on upfront selection (similarity in the face of antigen)
			//MappedCell mostSimilar = CellUtils.getMostSimilarEuclideanWithExclusion(c, bcells, bCellExclude);
			MappedCell mostSimilar = CellUtils.getMostSimilarEuclideanMappingWithExclusion(c, bcells, bCellExclude);
			
			// based on back-end selection (similarity to t cell)
			if(c.getScore() < mostSimilar.getScore())
			{
				bcells.remove(mostSimilar);
				bcells.add(c);
				bCellExclude.add(c);
			}
		}
	}
	
	protected void backPropagateTCells(MediatedPatternRecognition p, int patternNo, MappedCell tcell)
	{		
		// clone t cell
		LinkedList<MappedCell> tCellClones = CellUtils.cloningAndMutation(tcell, numTCellClones, rand);		
		// decode the mapping for clones
		for(MappedCell c : tCellClones)
		{
			CellUtils.forceDecodeSecondaryMapping(c);
		}		
		// assess clones based on match to antigen
		evaluateRepertoireAgainstAntigenEuclidean(p, patternNo, tCellClones); 
		// asses repertoire based on match to antigen
		evaluateRepertoireAgainstAntigenEuclidean(p, patternNo, tcells);		
		// similarity-affinity replacement (exclude clones)
		LinkedList<MappedCell> tCellExclude = new LinkedList<MappedCell>();
		for(MappedCell c : tCellClones)
		{
			// most similar based on upfront selection (selection by the b-cell mapping)
			//MappedCell mostSimilar = CellUtils.getMostSimilarEuclideanMappingWithExclusion(c, tcells, tCellExclude);
			MappedCell mostSimilar = CellUtils.getMostSimilarEuclideanWithExclusion(c, tcells, tCellExclude);
			
			// based on back-end selection (cost to antigen)
			if(c.getScore() < mostSimilar.getScore())
			{
				tcells.remove(mostSimilar);
				tcells.add(c);
				tCellExclude.add(c);
			}
		}
	}

	@Override
	protected LinkedList<CellSet> internalExecuteEpoch(Problem problem, LinkedList<CellSet> cp)
	{
		MediatedPatternRecognition p = (MediatedPatternRecognition) problem;			
		int numSubProblems = p.getNumInfections();		
		Cell [] bmus = new Cell[numSubProblems];		
		
		// process each sub problem
		for (int i = 0; i < numSubProblems; i++)
		{
			// exposure
			bmus[i] = exposure(p, i);
			// back propagation
			backPropagate(p, i);
		}		
		
		// create a cell set
		LinkedList<CellSet> nextgen = new LinkedList<CellSet>();
		nextgen.add(new CellSet(bmus));
		return nextgen;
	}

	@Override
	protected void internalPostEvaluation(Problem problem, LinkedList<CellSet> oldPopulation, LinkedList<CellSet> newPopulation)
	{}

	@Override
	public void validateConfiguration() throws InvalidConfigurationException
	{}

	@Override
	public String getName()
	{
		return "BottomUp One-to-One Mapping (Euclidean) Forced";
	}

	public long getSeed()
	{
		return seed;
	}

	public void setSeed(long seed)
	{
		this.seed = seed;
	}
}
