/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006, 2007  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.cells.mediatedclassification.problems;

import java.awt.Color;
import java.util.Random;

import com.oat.InitialisationException;
import com.oat.InvalidConfigurationException;
import com.oat.Problem;
import com.oat.Solution;
import com.oat.SolutionEvaluationException;
import com.oat.domains.cells.mediatedclassification.ClassificationCell;
import com.oat.domains.cells.mediatedclassification.ClassificationSolution;
import com.oat.domains.cells.opt.Cell;
import com.oat.domains.cells.opt.problems.Optimisation;
import com.oat.utils.AlgorithmUtils;
import com.oat.utils.RandomUtils;

/**
 * Description: Classification Problem
 *  
 * Date: 05/11/2007<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class PatternClassification extends Problem
{
	public final static Color [] KNOWN_COLOURS = new Color[]
	{		
		Color.BLUE,
		Color.CYAN,
		Color.GREEN,
		Color.MAGENTA,
		Color.ORANGE,
		Color.PINK,
		Color.RED,
		Color.YELLOW
    };
	
	// config
	protected long seed = 3;
	protected int numPatterns = 8*10; // about 10 examples of each of the 8 classes		
	// data
	protected Optimisation [] subproblems;
	protected int [] classes;
	
	
	public int classify(double [] cf)
	{
		double dist = Double.POSITIVE_INFINITY;
		int index = -1;
		
		for (int i = 0; i < KNOWN_COLOURS.length; i++)
		{	
			float [] tmp = KNOWN_COLOURS[i].getComponents(null);
			
			double d = AlgorithmUtils.euclideanDistance(cf, tmp);			
			if(d < dist)
			{
				dist = d;
				index = i;
			}
		}
		
		return index;
	}	
	
	public boolean isClassificationCorrect(ClassificationCell cell, int problemNo)
	{
		return cell.getClassification() == classes[problemNo];
	}
		
	
	public Color getClassificationColourForPattern(int problemNo)
	{
		return KNOWN_COLOURS[classes[problemNo]];
	}
	
	public Color getClassificationColourForClassId(int classId)
	{
		return KNOWN_COLOURS[classId]; 
	}
	
	public int getClassIdForProblem(int problemNo)
	{
		return classes[problemNo];
	}
	
	public int getNumClasses()
	{
		return KNOWN_COLOURS.length;
	}

	@Override
	public void checkSolutionForSafety(Solution solution)
			throws SolutionEvaluationException
	{
		if(solution instanceof ClassificationSolution)
		{
			ClassificationSolution c = (ClassificationSolution) solution;
			if(c.getClassifications().length != numPatterns)
			{
				throw new SolutionEvaluationException("Number of classifications "+c.getClassifications().length+" does not match the expected number of patterns "+numPatterns+".");
			}
		}
		else
		{
			throw new SolutionEvaluationException("Unknown type: " + solution.getClass().getName());
		}		
	}

	@Override
	public void cleanupAfterRun() throws InitialisationException
	{
		// cleanup if required
		for (int i = 0; i < numPatterns; i++)
		{
			subproblems[i].cleanupAfterRun();
		}
	}

	@Override
	public void initialiseBeforeRun() throws InitialisationException
	{
		Random rand = new Random(seed);	
		
		// create the random set
		boolean [][] set = RandomUtils.randomBitStringSet(rand, 64*3, numPatterns, 64);
		
		// create the problems
		subproblems = new Optimisation[numPatterns];
		classes = new int[numPatterns];
		
		for (int i = 0; i < numPatterns; i++)
		{
			// create
			subproblems[i] = new Optimisation();
			// initialise
			subproblems[i].initialiseBeforeRunManually(set[i]);
			// class
			classes[i] = classify(subproblems[i].getGlobalOptima()[0].getCoordinate());
		}
	}

	@Override
	public boolean isMinimization()
	{
		return true; // minimise error
	}
	
	
	@Override
	protected double problemSpecificCost(Solution solution)
			throws SolutionEvaluationException
	{
		if(solution instanceof ClassificationSolution)
		{			
			ClassificationSolution c = (ClassificationSolution) solution;	
			int [] classifications = c.getClassifications();
			int errorCount = 0;
			
			// process all patterns, expect cells are provided in order of the patterns
			for (int i = 0; i < numPatterns; i++)
			{
				errorCount += ((classes[i] == classifications[i]) ? 0 : 1);
			}
			
			return errorCount;
		}
		
		throw new SolutionEvaluationException("Unsupported type: " + solution.getClass().getName());
	}
	
	/**
	 * 
	 * @param solution
	 * @param subProblemNumber
	 * @throws SolutionEvaluationException
	 */
	public void costCell(Cell solution, int subProblemNumber)
			throws SolutionEvaluationException
	{
		// NOTE: i do not use cost(), because cost() on the subproblem will not re-evaluate solutions
		// that have already been evaluated. i want this behaviour
		double s = subproblems[subProblemNumber].costCell(solution);
		solution.evaluated(s);
	}
	
	/**
	 * 
	 * @param partialSolution
	 * @param subProblemNumber
	 * @throws SolutionEvaluationException
	 */
//	public void costSubStructure(DegenerateCell partialSolution, int subProblemNumber)
//		throws SolutionEvaluationException
//	{
//		subproblems[subProblemNumber].costSubStructure(partialSolution);
//	}
	
	/**
	 * 
	 * @param partialSolution
	 * @param subProblemNumber
	 * @throws SolutionEvaluationException
	 */
	public void costSingleFeature(Cell partialSolution, int subProblemNumber)
		throws SolutionEvaluationException
	{
		subproblems[subProblemNumber].costSingleFeature(partialSolution);
	}	

	@Override
	protected void validateConfigurationInternal()
			throws InvalidConfigurationException
	{
		
	}

	@Override
	public String getName()
	{
		return "Pattern Classification";
	}	

	public long getSeed()
	{
		return seed;
	}

	public void setSeed(long seed)
	{
		this.seed = seed;
	}
	
	@Override
    public boolean isUserConfigurable()
    {
    	return true;
    }

	public int getNumPatterns()
	{
		return numPatterns;
	}

	public void setNumPatterns(int numPatterns)
	{
		this.numPatterns = numPatterns;
	}

	public Optimisation[] getSubproblems()
	{
		return subproblems;
	}
	
	
}
