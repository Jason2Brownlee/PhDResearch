/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006, 2007  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.cells.patrec.algorithms;

import java.util.Collections;
import java.util.LinkedList;
import java.util.Random;

import com.oat.EpochAlgorithm;
import com.oat.InvalidConfigurationException;
import com.oat.Problem;
import com.oat.domains.cells.opt.Cell;
import com.oat.domains.cells.patrec.CellSet;
import com.oat.domains.cells.patrec.problems.PatternRecognition;
import com.oat.utils.ArrayUtils;
import com.oat.utils.EvolutionUtils;
import com.oat.utils.RandomUtils;

/**
 * Description: Degenerate patterns
 *  
 * Date: 31/10/2007<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class DegeneratePattern extends EpochAlgorithm<CellSet>
{
	// config
	protected long seed = 1;
	protected int repertoireSize = 1; // (10*1)
	protected int selectionSize = 1;
	protected int cloningSize = 10;
	protected double mutationRate = 1.0/(3.0*64.0);
	
	// data
	protected Random rand;
	protected LinkedList<Cell>[] cells;
	
	
	@Override
	protected LinkedList<CellSet> internalInitialiseBeforeRun(Problem problem)
	{
		PatternRecognition p = (PatternRecognition) problem;
		
		rand = new Random(seed);		
		cells = new LinkedList[p.getNumInfections()];
		
		for (int i = 0; i < cells.length; i++)
		{
			cells[i] = new LinkedList<Cell>();
			
			for (int j = 0; j < repertoireSize; j++)
			{
				boolean [] data = RandomUtils.randomBitString(rand, 3, 64);
				Cell c = new Cell(data);
				cells[i].add(c);
			}
		}
		
		return null;
	}	
	
	
	protected LinkedList<Cell> cloningAndMutation(LinkedList<Cell> selectedSet)
	{
		LinkedList<Cell> newPop = new LinkedList<Cell>();
		
		for(Cell current : selectedSet)
		{			
			for (int j = 0; j < cloningSize; j++)
			{
				// copy
				boolean [] cloneData = ArrayUtils.copyArray(current.getData());
				// mutate
				EvolutionUtils.binaryMutate(cloneData, rand, mutationRate);
				// store
				Cell clone = new Cell(cloneData);
				newPop.add(clone);
			}
		}
		
		return newPop;
	}
	
	protected LinkedList<Cell> evaluateAndSelect(PatternRecognition p, LinkedList<Cell> pop, int subProblemNumber)
	{
		// assess first
		for(Cell c : pop)
		{
			p.costCell(c, subProblemNumber);
		}
		
		// order by utility
		Collections.sort(pop);	
		
		LinkedList<Cell> selectedSet = new LinkedList<Cell>();		
		for (int i = 0; i < selectionSize; i++)
		{			
			// i know it is minimisation
			Cell current = pop.get(i);
			selectedSet.add(current);
		}
		
		return selectedSet;
	}	

	@Override
	protected LinkedList<CellSet> internalExecuteEpoch(Problem problem, LinkedList<CellSet> currentPop)
	{
		PatternRecognition p = (PatternRecognition) problem;			
		int numSubProblems = p.getNumInfections();
		
		Cell [] bmus = new Cell[numSubProblems];		
		LinkedList<Cell>[] newCells = new LinkedList[cells.length];
		
		// process each sub problem
		for (int i = 0; i < numSubProblems; i++)
		{
			// select the activated set
			LinkedList<Cell> selected = evaluateAndSelect(p, cells[i], i);
			// store the best matching unit
			bmus[i] = selected.getFirst();
			// cloning and mutation
			newCells[i] = cloningAndMutation(selected);
			// reduce to appropriate size
			newCells[i] = evaluateAndSelect(p, newCells[i], i);
		}		
		// replace the current repertoire
		cells = newCells;
		
		// create a cell set
		LinkedList<CellSet> nextgen = new LinkedList<CellSet>();
		nextgen.add(new CellSet(bmus));
		return nextgen;
	}

	@Override
	protected void internalPostEvaluation(Problem problem, LinkedList<CellSet> oldPopulation, LinkedList<CellSet> newPopulation)
	{}

	@Override
	public void validateConfiguration() throws InvalidConfigurationException
	{
		
	}

	@Override
	public String getName()
	{
		return "Degenerate Patterns";
	}

	public long getSeed()
	{
		return seed;
	}

	public void setSeed(long seed)
	{
		this.seed = seed;
	}
}
