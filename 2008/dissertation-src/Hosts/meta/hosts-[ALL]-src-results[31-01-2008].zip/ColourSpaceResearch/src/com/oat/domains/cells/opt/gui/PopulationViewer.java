/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006, 2007  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.cells.opt.gui;

import java.awt.Color;
import java.awt.Graphics;
import java.util.Collections;
import java.util.LinkedList;

import com.oat.Algorithm;
import com.oat.AlgorithmEpochCompleteListener;
import com.oat.Problem;
import com.oat.Solution;
import com.oat.domains.cells.opt.Cell;
import com.oat.domains.cells.opt.problems.Optimisation;
import com.oat.explorer.gui.AlgorithmChangedListener;
import com.oat.explorer.gui.ClearEventListener;
import com.oat.explorer.gui.plot.GenericProblemPlot;

/**
 * Description: 
 *  
 * Date: 30/10/2007<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class PopulationViewer extends GenericProblemPlot
	implements AlgorithmEpochCompleteListener, ClearEventListener, AlgorithmChangedListener
{
	protected Optimisation problem;
	
	protected Color [] problemColor;
	protected LinkedList<Color> pop;
	
	
	public PopulationViewer()
	{
		setName("Population View");
		pop = new LinkedList<Color>();
	}
	
	

	@Override
	public void algorithmChangedEvent(Algorithm a)
	{
		
	}


	@Override
	public void problemChangedEvent(Problem p)
	{
		synchronized(this)
		{			
			clear();
		
			if(p instanceof Optimisation)
			{
				problem = (Optimisation) p;
			}
		}
		
		repaint();
	}

	@Override
	public void clear()
	{
		synchronized(this)
		{
			problemColor = null;
			pop.clear();
		}
	}

	@Override
	public <T extends Solution> void epochCompleteEvent(Problem p, LinkedList<T> currentPop)
	{		
		synchronized(this)
		{
			if(problem == null)
			{
				return;
			}			
			if(problemColor == null)
			{
				problemColor = new Color[4];
				double [] optima = problem.getGlobalOptima()[0].getCoordinate();
				
				// problem now has a generated colour
				problemColor[0] = vectorToColor(optima);
				
				// each component
				problemColor[1] = vectorToColor(new double[]{optima[0], 0, 0});
				problemColor[2] = vectorToColor(new double[]{0, optima[1], 0});
				problemColor[3] = vectorToColor(new double[]{0, 0, optima[2]});
			}
			
			pop.clear();
			Collections.sort(currentPop);
			for (Solution s : currentPop)
			{
				if(s.isEvaluated())
				{
					Color c = vectorToColor(((Cell)s).getDecodedData());
					pop.add(c);
				}
			}			
		}		
		
		repaint();
	}
	
	
	protected Color vectorToColor(double [] v)
	{		
		return new Color((float)v[0], (float)v[1], (float)v[2]);
	}

	@Override
	protected void paintComponent(Graphics g)
	{
		synchronized(this)
		{
			if(problem == null)
			{
				super.plotUnavailable(g);
				return;
			}
			
			// draw pop
			int height = (int) Math.floor((double)getHeight() / pop.size());
			int width = (int) Math.floor((double)getWidth() / 2.0);
			int subwidth = width;			
			
			for (int i = 0; i < pop.size(); i++)
			{						
				g.setColor(pop.get(i));					
				g.fillRect(0, i*height, subwidth, height);				
				g.setColor(Color.BLACK);
				g.drawRect(0, i*height, subwidth, height);
			}	
			
			if(problemColor != null)
			{
				// draw the objective colour
				g.setColor(problemColor[0]);				
				g.fillRect(width, 0, width, getHeight());
				
				// draw components
				int osubwidth = width/3;
				int subHeight = getHeight() / 10;
				for (int i = 0; i < 3; i++)
				{
					g.setColor(problemColor[i+1]);	
					g.fillRect(width+(i*osubwidth), 0, osubwidth, subHeight);
				}
				
			}
			g.setColor(Color.BLACK);
			g.drawRect(width, 0, width, getHeight());
		}
	}
}
