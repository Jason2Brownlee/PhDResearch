/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006, 2007  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.cells.network.algorithms.recurrent;

import java.util.LinkedList;
import java.util.Random;

import com.oat.EpochAlgorithm;
import com.oat.InvalidConfigurationException;
import com.oat.Problem;
import com.oat.domains.cells.mediatedpattrec.CellUtils;
import com.oat.domains.cells.network.algorithms.Tissue;
import com.oat.domains.cells.network.algorithms.OneReceptorQueueModel;
import com.oat.domains.cells.network.problems.PRProblem;
import com.oat.domains.cells.opt.Cell;
import com.oat.domains.cells.patrec.CellSet;
import com.oat.utils.AlgorithmUtils;

/**
 * Description: 
 *  
 * Date: 13/11/2007<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class RecurrentNatural extends EpochAlgorithm<CellSet>
	implements Tissue<Cell>, OneReceptorQueueModel
{
	// config
	protected long seed = 1;
	protected int repertoireSize = -1;
	protected int selectionSize = 1;
	protected int cloningSize = 5;
	
	// data
	protected Random rand;
	protected LinkedList<Cell> cells;	
	protected Cell lastExposure;
	
	protected LinkedList<Cell[]> epochPairs; 
	
	
	
	@Override
	protected LinkedList<CellSet> internalInitialiseBeforeRun(Problem problem)
	{		
		rand = new Random(seed);
		repertoireSize = ((PRProblem)problem).getNumInfections() * 10;
		lastExposure = null;
		epochPairs = new LinkedList<Cell[]>();
		cells = CellUtils.getRandomRepertoire(rand, repertoireSize);		
		// no initial population
		return null;
	}
	
	
	
	@Override
	public LinkedList<Cell[]> getEpochPairs()
	{
		return epochPairs;
	}
	@Override
	public LinkedList<Cell> getRepertoire()
	{
		return cells;
	}	

	protected void assessRepertoireAgainstAntigen(PRProblem p, int pattNo, LinkedList<Cell> repertoire)
	{
		for(Cell c : repertoire)
		{
			p.costCell(c, pattNo);
		}
	}	
	
	protected void assessRepertoireAgainstCell(Cell bmu, LinkedList<Cell> repertoire)
	{
		for(Cell c : repertoire)
		{
			CellUtils.forceDecode(c);
			double cost = AlgorithmUtils.euclideanDistance(bmu.getDecodedData(), c.getDecodedData());
			c.evaluated(cost);
		}
	}	
	
	protected void replaceIntoRepertoire(LinkedList<Cell> progeny, LinkedList<Cell> repertoire)
	{
		for(Cell c : progeny)
		{
			// Euclidean similarity tournament for competition
			Cell similar = CellUtils.getMostSimilarEuclideanWithExclusion(c, repertoire, progeny);
			// fitness tournament for resources
			if(c.getScore() < similar.getScore())
			{
				repertoire.remove(similar);
				repertoire.add(c);
			}
		}
	}
	
	
	protected Cell exposure(Cell bmu)
	{
		// exclude self
		LinkedList<Cell> exclude = new LinkedList<Cell>();
		exclude.add(bmu);
		
		// assess repertoire against the bmu
		assessRepertoireAgainstCell(bmu, cells);
		// select the activated set
		LinkedList<Cell> selected = CellUtils.selectActivatedSet(cells, exclude, rand, selectionSize);
		// cloning and mutation
		LinkedList<Cell> clones = CellUtils.cloningAndMutation(selected, cloningSize, rand);
		// assess the clones against the antigen
		assessRepertoireAgainstCell(bmu, clones);
		// compete for position within the repertoire
		replaceIntoRepertoire(clones, cells);
		// store epoch pairs
		epochPairs.add(new Cell[]{bmu, selected.getFirst()});
		// return the BMU
		return selected.getFirst();
	}
	
	protected Cell exposure(PRProblem p, int pattNo)
	{			
		// assess repertoire
		assessRepertoireAgainstAntigen(p, pattNo, cells);
		// select the activated set
		LinkedList<Cell> selected = CellUtils.selectActivatedSet(cells, rand, selectionSize);
		// cloning and mutation
		LinkedList<Cell> clones = CellUtils.cloningAndMutation(selected, cloningSize, rand);
		// assess the clones against the antigen
		assessRepertoireAgainstAntigen(p, pattNo, clones);		
		// compete for position within the repertoire
		replaceIntoRepertoire(clones, cells);
		// return the BMU
		return selected.getFirst();	
	}
	
	protected Cell exposureManager(PRProblem p, int pattNo)
	{
		// normal exposure
		Cell bmuT0 = exposure(p, pattNo);
		Cell bmuT_1 = null;
		
		// t-1 exposure, it will be null on the first exposure of the first epoch
		if(lastExposure != null)
		{
			bmuT_1 = exposure(lastExposure);
		}
		
		// update last exposure information 
		lastExposure = bmuT0;		
		// return the normal exposure bmu
		return bmuT0;
	}

	@Override
	protected LinkedList<CellSet> internalExecuteEpoch(Problem problem, LinkedList<CellSet> cp)
	{
		PRProblem p = (PRProblem) problem;			
		Cell [] bmus = new Cell[p.getNumInfections()];	
		epochPairs.clear();
		// process each sub problem
		for (int i = 0; i < bmus.length; i++)
		{			
			// exposure
			bmus[i] = exposureManager(p, i);
		}		
		// create a cell set
		LinkedList<CellSet> nextgen = new LinkedList<CellSet>();
		nextgen.add(new CellSet(bmus));
		return nextgen;
	}

	@Override
	protected void internalPostEvaluation(Problem problem, LinkedList<CellSet> oldPopulation, LinkedList<CellSet> newPopulation)
	{}

	@Override
	public void validateConfiguration() throws InvalidConfigurationException
	{}

	@Override
	public String getName()
	{
		return "Recurrent Natural";
	}

	public long getSeed()
	{
		return seed;
	}

	public void setSeed(long seed)
	{
		this.seed = seed;
	}
}
