/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006, 2007  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.cells.network;

import java.util.Collections;
import java.util.LinkedList;

import com.oat.Algorithm;
import com.oat.Domain;
import com.oat.Problem;
import com.oat.RunProbe;
import com.oat.StopCondition;
import com.oat.domains.cells.mediatedpattrec.probes.AEEuclidean;
import com.oat.domains.cells.mediatedpattrec.probes.AEHamming;
import com.oat.domains.cells.mediatedpattrec.probes.OptimaDiversity;
import com.oat.domains.cells.mediatedpattrec.probes.RMSEEuclidean;
import com.oat.domains.cells.mediatedpattrec.probes.RMSEHamming;
import com.oat.domains.cells.mediatedpattrec.probes.SolutionDiversity;
import com.oat.domains.cells.network.algorithms.classic.Classical;
import com.oat.domains.cells.network.algorithms.classic.ClassicalReplacement;
import com.oat.domains.cells.network.algorithms.dualexposure.DualExposureCoupled;
import com.oat.domains.cells.network.algorithms.dualexposure.DualExposureDecoupled;
import com.oat.domains.cells.network.algorithms.proxy.ProxyResponseAggregate;
import com.oat.domains.cells.network.algorithms.proxy.ProxyResponseAntigen;
import com.oat.domains.cells.network.algorithms.proxy.ProxyResponseBottomUp;
import com.oat.domains.cells.network.algorithms.proxy.ProxyResponseTopDown;
import com.oat.domains.cells.network.algorithms.proxy.mapped.ProxyMappedBottomUp;
import com.oat.domains.cells.network.algorithms.proxy.mapped.ProxyMappedBottomUpIdeal;
import com.oat.domains.cells.network.algorithms.proxy.mapped.ProxyMappedIdeal;
import com.oat.domains.cells.network.algorithms.proxy.mapped.ProxyMappedTopDown;
import com.oat.domains.cells.network.algorithms.recurrent.RecurrentMapping;
import com.oat.domains.cells.network.algorithms.recurrent.RecurrentMappingPromotion;
import com.oat.domains.cells.network.algorithms.recurrent.RecurrentNatural;
import com.oat.domains.cells.network.gui.NetworkMasterPanel;
import com.oat.domains.cells.network.probes.AvgErrorReceptorBMUEuclidean;
import com.oat.domains.cells.network.probes.AvgErrorReceptorBMUHamming;
import com.oat.domains.cells.network.probes.MappingDiversity;
import com.oat.domains.cells.network.probes.MappingDiversityBetweenStrings;
import com.oat.domains.cells.network.probes.PairDiversity;
import com.oat.domains.cells.network.probes.RepertoireDiversity;
import com.oat.domains.cells.network.problems.PRProblem;
import com.oat.domains.cells.network.problems.PRProblem10;
import com.oat.domains.cells.network.problems.PRProblem2;
import com.oat.explorer.gui.panels.MasterPanel;
import com.oat.explorer.gui.plot.GenericProblemPlot;
import com.oat.stopcondition.FoundOptimaOrMaxEpochs;
import com.oat.stopcondition.FoundOptima;

/**
 * Description: 
 *  
 * Date: 13/11/2007<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class NetworkDomain extends Domain
{
	@Override
	public MasterPanel getExplorerPanel()
	{
		return new NetworkMasterPanel(this);
	}

	@Override
	public String getHumanReadableName()
	{
		return "Network Cellular";
	}

	@Override
	public String getShortName()
	{
		return "net";
	}

	@Override
	public Algorithm[] loadAlgorithmList() throws Exception
	{
		Algorithm [] a = new Algorithm[]
		                     {	
				// classic
				new Classical(),
				new ClassicalReplacement(),
				
				// recurrent model 
				new RecurrentNatural(),
				new RecurrentMapping(), 
				new RecurrentMappingPromotion(),
				
				// dual exposure
				new DualExposureDecoupled(),
				new DualExposureCoupled(),
								
				// proxy response
				new ProxyResponseAntigen(),
				new ProxyResponseTopDown(),
				new ProxyResponseBottomUp(),
				new ProxyResponseAggregate(),
				
				// proxy response mapped
				new ProxyMappedBottomUpIdeal(),
				new ProxyMappedBottomUp(),
				new ProxyMappedIdeal(),
				new ProxyMappedTopDown(),
				
		                     };
		return a;
	}

	@Override
	public Problem[] loadProblemList() throws Exception
	{
		return new Problem[]
		                   {
//				new PRProblem(),
				new PRProblem10(),
				new PRProblem2()
		                   };
	}

	@Override
	public GenericProblemPlot prepareProblemPlot()
	{
		return null;
	}
	
	@Override
	public LinkedList<StopCondition> loadDomainStopConditions()
	{
		LinkedList<StopCondition> list = super.loadDomainStopConditions();
		list.add(new FoundOptima());		
		list.add(new FoundOptimaOrMaxEpochs());
		Collections.sort(list);		
		return list;
	}
	
	@Override
	public LinkedList<RunProbe> loadDomainRunProbes()
	{
		LinkedList<RunProbe> list = super.loadDomainRunProbes();		
		
		list.add(new SolutionDiversity());
		list.add(new OptimaDiversity());
		list.add(new RMSEEuclidean());
		list.add(new RMSEHamming());
		list.add(new AEHamming());
		list.add(new AEEuclidean());
		
		// diversity probes
		list.add(new RepertoireDiversity());
		list.add(new MappingDiversity());
		list.add(new MappingDiversityBetweenStrings());
		list.add(new PairDiversity());
		
		// cost probes
		list.add(new AvgErrorReceptorBMUEuclidean());
		list.add(new AvgErrorReceptorBMUHamming());
		
		Collections.sort(list);		
		return list;
	}
}
