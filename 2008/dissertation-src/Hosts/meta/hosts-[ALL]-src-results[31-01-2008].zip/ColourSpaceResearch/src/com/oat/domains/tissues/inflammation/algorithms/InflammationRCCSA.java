/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006-2008  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.tissues.inflammation.algorithms;

import java.util.LinkedList;

import com.oat.Problem;
import com.oat.domains.cells.mediatedpattrec.CellUtils;
import com.oat.domains.cells.opt.Cell;
import com.oat.domains.cells.patrec.CellSet;
import com.oat.domains.tissues.recirulation.algorithms.ReplacementCellularClonalSelectionAlgorithm;

/**
 * Description: 
 *  
 * Date: 21/01/2008<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class InflammationRCCSA extends
		ReplacementCellularClonalSelectionAlgorithm
{
	
	@Override
	public void replaceIntoRepertoire(LinkedList<Cell> progeny, LinkedList<Cell> repertoire)
	{
		for(Cell c : progeny)
		{
			if(repertoire.size() < numCells)
			{
				// simply add
				repertoire.add(c);
			}
			// make room
			else			
			{	
				// Euclidean similarity tournament for competition
				Cell similar = CellUtils.getMostSimilarEuclideanWithExclusion(c, repertoire, progeny);
				// fitness tournament for resources
				if(c.getScore() < similar.getScore())
				{
					repertoire.remove(similar);
					repertoire.add(c);
				}
			}
		}
	}
	
	@Override
	public String getName()
	{
		return "Inflammation RCCSA";
	}
}
