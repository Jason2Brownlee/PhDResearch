/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006, 2007  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.cells.mediatedpattrec.algorithms.topdown.cells.onetoone;

import java.util.Collections;
import java.util.LinkedList;
import java.util.Random;

import com.oat.EpochAlgorithm;
import com.oat.InvalidConfigurationException;
import com.oat.Problem;
import com.oat.domains.cells.mediatedpattrec.CellUtils;
import com.oat.domains.cells.mediatedpattrec.algorithms.MediatedClonalSelection;
import com.oat.domains.cells.mediatedpattrec.problems.MediatedPatternRecognition;
import com.oat.domains.cells.opt.Cell;
import com.oat.domains.cells.patrec.CellSet;
import com.oat.utils.BitStringUtils;
import com.oat.utils.RandomUtils;

/**
 * Description: 
 *  
 * Date: 08/11/2007<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class TopDownHammingWithEuclideanCost extends EpochAlgorithm<CellSet>
	implements MediatedClonalSelection
{
	// config
	protected long seed = 1;
	
	protected int numBCells = 50;
	protected int numTCells = 50;
	
	protected int numBCellClones = 5;
	protected int numTCellClones = 5;
	
	// data
	protected Random rand;
	protected LinkedList<Cell> bcells;
	protected LinkedList<Cell> tcells;
	
	
	@Override
	protected LinkedList<CellSet> internalInitialiseBeforeRun(Problem problem)
	{	
		rand = new Random(seed);			
		// bcells
		bcells = CellUtils.getRandomRepertoire(rand, numBCells);			
		// tcells
		tcells = CellUtils.getRandomRepertoire(rand, numTCells);
		
		// no initial population
		return null;
	}	
	
	@Override
	public LinkedList<Cell> getBCells()
	{
		return bcells;
	}

	@Override
	public LinkedList<Cell> getTCells()
	{
		return tcells;
	}
	
	
	
	protected Cell evaluateAndSelectTCell(Cell bcell, LinkedList<Cell> tCells)
	{		
		// assess first
		evaluateTCells(bcell, tCells);		
		// random tie handling
		Collections.shuffle(tCells, rand);
		// order by utility
		Collections.sort(tCells);	
		return tCells.getFirst();
	}
	
	protected void evaluateTCells(Cell bcell, LinkedList<Cell> tCells)
	{		
		for(Cell c : tCells)
		{	
			double dist = BitStringUtils.hammingDistance(bcell.getData(), c.getData()); 
			c.evaluated(dist);
		}
	}	
	
	
	protected Cell evaluateAndSelectBCell(
			MediatedPatternRecognition p, 
			LinkedList<Cell> pop, 
			int subProblemNumber)
	{
		// assess first
		evaluateBCells(p, pop, subProblemNumber);		
		// random tie handling
		Collections.shuffle(pop, rand);
		// order by utility
		Collections.sort(pop);	
		return pop.getFirst();
	}
	
	
	protected void evaluateBCells(MediatedPatternRecognition p, LinkedList<Cell> bcells, int subProblemNumber)
	{
		for(Cell c : bcells)
		{
			// HERE
			//p.costCellHamming(c, subProblemNumber);
			p.costCell(c, subProblemNumber);
		}
	}
	
	
	protected Cell exposure(MediatedPatternRecognition p, int patternNo)
	{		
		// activate b cell
		Cell activatedBCell = evaluateAndSelectBCell(p, bcells, patternNo);
		// activate t cell
		Cell bmu = evaluateAndSelectTCell(activatedBCell, tcells);		
		// back propagate bcells
		backPropagateBCells(p, patternNo, activatedBCell);		
		// back propagate tcells
		backPropagateTCells(activatedBCell, bmu);
		return bmu;		
	}
	
	protected void backPropagateBCells(MediatedPatternRecognition p, int patternNo, Cell bcell)
	{
		// clone b cell
		LinkedList<Cell> bCellClones = CellUtils.cloningAndMutation(bcell, numBCellClones, rand);
		// evaluate
		evaluateBCells(p, bCellClones, patternNo);
		// similarity-affinity replacement (exclude clones)
		LinkedList<Cell> bCellExclude = new LinkedList<Cell>();
		for(Cell c : bCellClones)
		{
			Cell mostSimilar = CellUtils.getMostSimilarHammingWithExclusion(c, bcells, bCellExclude);				
			if(c.getScore() < mostSimilar.getScore())
			{
				bcells.remove(mostSimilar);
				bcells.add(c);
				bCellExclude.add(c);
			}
		}
	}
	
	protected void backPropagateTCells(Cell bcell, Cell tcell)
	{	
		for (Cell c : tcells)
		{
			CellUtils.forceDecode(c);
		}
		
		// clone t cell
		LinkedList<Cell> tCellClones = CellUtils.cloningAndMutation(tcell, numTCellClones, rand);
		// evaluate t cell clones against b cell
		evaluateTCells(bcell, tCellClones);
		// similarity-affinity replacement (exclude clones)
		LinkedList<Cell> tCellExclude = new LinkedList<Cell>();
		for(Cell c : tCellClones)
		{	
			CellUtils.forceDecode(c);
			Cell mostSimilar = CellUtils.getMostSimilarHammingWithExclusion(c, tcells, tCellExclude);
			if(c.getScore() < mostSimilar.getScore())
			{
				tcells.remove(mostSimilar);
				tcells.add(c);
				tCellExclude.add(c);
			}
		}
	}

	@Override
	protected LinkedList<CellSet> internalExecuteEpoch(Problem problem, LinkedList<CellSet> cp)
	{
		MediatedPatternRecognition p = (MediatedPatternRecognition) problem;			
		int numSubProblems = p.getNumInfections();		
		Cell [] bmus = new Cell[numSubProblems];		
		
		// process each sub problem
		for (int i = 0; i < numSubProblems; i++)
		{
			bmus[i] = exposure(p, i);
		}		
		
		// create a cell set
		LinkedList<CellSet> nextgen = new LinkedList<CellSet>();
		nextgen.add(new CellSet(bmus));
		return nextgen;
	}

	@Override
	protected void internalPostEvaluation(Problem problem, LinkedList<CellSet> oldPopulation, LinkedList<CellSet> newPopulation)
	{}

	@Override
	public void validateConfiguration() throws InvalidConfigurationException
	{}

	@Override
	public String getName()
	{
		return "TopDown Hamming (Euclidean Cost)";
	}

	public long getSeed()
	{
		return seed;
	}

	public void setSeed(long seed)
	{
		this.seed = seed;
	}
}
