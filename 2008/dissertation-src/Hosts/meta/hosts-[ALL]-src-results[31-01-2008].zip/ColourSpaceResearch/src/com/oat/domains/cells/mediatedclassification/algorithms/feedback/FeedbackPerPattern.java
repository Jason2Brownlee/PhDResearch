/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006, 2007  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.cells.mediatedclassification.algorithms.feedback;

import java.util.Collections;
import java.util.LinkedList;
import java.util.Random;

import com.oat.EpochAlgorithm;
import com.oat.InvalidConfigurationException;
import com.oat.Problem;
import com.oat.domains.cells.mediatedclassification.ClassificationCell;
import com.oat.domains.cells.mediatedclassification.ClassificationSolution;
import com.oat.domains.cells.mediatedclassification.MaskMappingCell;
import com.oat.domains.cells.mediatedclassification.problems.PatternClassification;
import com.oat.domains.cells.opt.Cell;
import com.oat.utils.ArrayUtils;
import com.oat.utils.BitStringUtils;
import com.oat.utils.EvolutionUtils;
import com.oat.utils.RandomUtils;

/**
 * Description: Feedback per pattern
 *  
 * Date: 05/11/2007<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class FeedbackPerPattern extends EpochAlgorithm<ClassificationSolution>
{
	// config
	protected long seed = 1;
	protected int repertoireSize = 40;
	protected int cloningSize = 1;
	protected double mutationRate = 1.0/(3.0*64.0);
	
	// data
	protected Random rand;
	
	protected LinkedList<MaskMappingCell> bcells;
	protected LinkedList<ClassificationCell> tcells;
	
	
	@Override
	protected LinkedList<ClassificationSolution> internalInitialiseBeforeRun(Problem problem)
	{
		PatternClassification p = (PatternClassification) problem;
		rand = new Random(seed);	
		
		// prepare 
		bcells = new LinkedList<MaskMappingCell>();
		tcells = new LinkedList<ClassificationCell>();
		
		for (int i = 0; i < repertoireSize; i++)
		{
			// b-cell
			boolean [] bData = RandomUtils.randomBitString(rand, 3, 64);
			boolean [] bmask = RandomUtils.randomBitString(rand, 3, 64);
			bcells.add(new MaskMappingCell(bmask, bData));
			
			// t cell
			boolean [] tdata = RandomUtils.randomBitString(rand, 3, 64);
			int tclass = rand.nextInt(p.getNumClasses());
			//int tclass = (i % 8);			
			tcells.add(new ClassificationCell(tclass, tdata));
		}
		
		// no initial population
		return null;
	}	
	
	
	protected LinkedList<MaskMappingCell> cloningAndMutateBCell(MaskMappingCell bmu)
	{
		LinkedList<MaskMappingCell> newPop = new LinkedList<MaskMappingCell>();
					
		for (int j = 0; j < cloningSize; j++)
		{
			// copy
			boolean [] cloneData = ArrayUtils.copyArray(bmu.getData());
			boolean [] cloneMask = ArrayUtils.copyArray(bmu.getMask());
			// mutate
			EvolutionUtils.binaryMutate(cloneData, rand, mutationRate);
			EvolutionUtils.binaryMutate(cloneMask, rand, mutationRate);
			// store
			MaskMappingCell clone = new MaskMappingCell(cloneMask, cloneData);
			newPop.add(clone);
		}
		
		
		return newPop;
	}
	
	protected LinkedList<ClassificationCell> cloningAndMutateTCell(ClassificationCell bmu)
	{
		LinkedList<ClassificationCell> newPop = new LinkedList<ClassificationCell>();
					
		for (int j = 0; j < cloningSize; j++)
		{
			// copy
			boolean [] cloneData = ArrayUtils.copyArray(bmu.getData());			
			// mutate
			EvolutionUtils.binaryMutate(cloneData, rand, mutationRate);
			// store
			ClassificationCell clone = new ClassificationCell(bmu.getClassification(), cloneData);
			newPop.add(clone);
		}		
		
		return newPop;
	}
	
	
	protected ClassificationCell evaluateAndSelectTCell(MaskMappingCell bcell, LinkedList<ClassificationCell> pop, int expectedClass)
	{
		// find all with expected class
//		LinkedList<ClassificationCell> pop = new LinkedList<ClassificationCell>();
//		for(ClassificationCell c : p)
//		{
//			if(c.getClassification() == expectedClass)
//			{
//				pop.add(c);
//			}
//		}
//		
//		if(pop.isEmpty())
//		{
//			throw new RuntimeException("No t-cells assigned the class " + expectedClass);
//		}
		
		boolean [] data = bcell.getData();
		boolean [] mask = bcell.getMask();
		
		// assess first
		for(ClassificationCell c : pop)
		{
			boolean [] d = c.getData();
			
			// number of differences
			int count = 0;			
			for (int i = 0; i < data.length; i++)
			{
				if(mask[i])
				{
					// check for match
					if(data[i] != d[i])
					{
						count++;
					}
				}
			}
			
			// store
			c.evaluated(count);
		}
		
		Collections.sort(pop);	
		
		return pop.getFirst();
	}
	
	
	protected MaskMappingCell evaluateAndSelectBCell(PatternClassification p, LinkedList<MaskMappingCell> pop, int subProblemNumber)
	{
		// assess first
		for(MaskMappingCell c : pop)
		{
			p.costCell(c, subProblemNumber);
		}		
		// order by utility
		Collections.sort(pop);	
		
		return pop.getFirst();
	}	
	
	protected int exposure(PatternClassification p, int patternNo)
	{
		// select the b-cell
		MaskMappingCell bcell = evaluateAndSelectBCell(p, bcells, patternNo);
		// select the t-cell
		ClassificationCell tcell = evaluateAndSelectTCell(bcell, tcells, p.getClassIdForProblem(patternNo));
		
		// check if correctly classified
		if(p.isClassificationCorrect(tcell, patternNo))
		{
			// b cells
			LinkedList<MaskMappingCell> bCellClones = cloningAndMutateBCell(bcell);
			replacementBCells(bcells, bCellClones);
			// t cells
			LinkedList<ClassificationCell> tCellClones = cloningAndMutateTCell(tcell);
			//replacementTCells(tcells, tCellClones);
			
			p.costCell(tCellClones.getFirst(), patternNo);
			
			if(tCellClones.getFirst().getScore() < tcell.getScore())
			{
				tcells.remove(tcell);
				tcells.add(tCellClones.getFirst());
			}
		}
		
		return tcell.getClassification();
	}
	
	protected void replacementBCells(LinkedList<MaskMappingCell> pop, LinkedList<MaskMappingCell> clones)
	{		
		// clones can never replace each other, replace the 5 most similar with the clones
		
		for(MaskMappingCell c : clones)
		{
			MaskMappingCell s = getMostSimilarWithExclusion(c, pop, clones);
			pop.remove(s);
			pop.add(c);
		}
	}
	
	protected void replacementTCells(LinkedList<ClassificationCell> pop, LinkedList<ClassificationCell> clones)
	{		
		// clones can never replace each other, replace the 5 most similar with the clones
		
		for(ClassificationCell c : clones)
		{
			ClassificationCell s = getMostSimilarWithExclusion(c, pop, clones);
			pop.remove(s);
			pop.add(c);
		}
	}
	
	
	public static <C extends Cell> C getMostSimilarWithExclusion(C cell, LinkedList<C> set, LinkedList<C> exclude)
	{
		double  min = Double.POSITIVE_INFINITY;
		C best = null;
		
		for(C c : set)
		{
			if(exclude.contains(c))
			{
				continue;
			}
			
			double d = BitStringUtils.hammingDistance(cell.getData(), c.getData());
			if(d < min)
			{
				min = d;
				best = c;
			}
		}
		
		return best;		
	}

	@Override
	protected LinkedList<ClassificationSolution> internalExecuteEpoch(Problem problem, LinkedList<ClassificationSolution> cp)
	{
		PatternClassification p = (PatternClassification) problem;			
		int numSubProblems = p.getNumPatterns();
		
		int [] classifications = new int[numSubProblems];	
		
		// process each sub problem
		for (int i = 0; i < numSubProblems; i++)
		{
			classifications[i] = exposure(p, i);
		}		
		
		// create a cell set
		LinkedList<ClassificationSolution> nextgen = new LinkedList<ClassificationSolution>();
		nextgen.add(new ClassificationSolution(classifications));
		return nextgen;
	}

	@Override
	protected void internalPostEvaluation(Problem problem, LinkedList<ClassificationSolution> oldPopulation, LinkedList<ClassificationSolution> newPopulation)
	{}

	@Override
	public void validateConfiguration() throws InvalidConfigurationException
	{
		if(repertoireSize<0)
		{
			throw new InvalidConfigurationException("Invalid repertoireSize " + repertoireSize);
		}
	}

	@Override
	public String getName()
	{
		return "Feedback Per Pattern";
	}

	public long getSeed()
	{
		return seed;
	}

	public void setSeed(long seed)
	{
		this.seed = seed;
	}
}
