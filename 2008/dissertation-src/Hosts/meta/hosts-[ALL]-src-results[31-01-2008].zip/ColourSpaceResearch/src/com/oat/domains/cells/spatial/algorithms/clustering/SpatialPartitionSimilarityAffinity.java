/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006, 2007  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.cells.spatial.algorithms.clustering;

import java.util.LinkedList;
import java.util.Random;

import com.oat.EpochAlgorithm;
import com.oat.InvalidConfigurationException;
import com.oat.Problem;
import com.oat.domains.cells.opt.Cell;
import com.oat.domains.cells.patrec.CellSet;
import com.oat.domains.cells.spatial.SpatialCell;
import com.oat.domains.cells.spatial.SpatialUtils;
import com.oat.domains.cells.spatial.algorithms.SpatialRepertoire;
import com.oat.domains.cells.spatial.problems.SpatialPatternRecognition;
import com.oat.utils.ArrayUtils;
import com.oat.utils.EvolutionUtils;
import com.oat.utils.RandomUtils;

/**
 * 
 * Description: Backend pressure, similar selection, forced
 *  
 * Date: 03/11/2007<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class SpatialPartitionSimilarityAffinity extends EpochAlgorithm<CellSet>
	implements SpatialRepertoire
{
	// config
	protected long seed = 3;
	protected int repertoireSize = 15;
	protected int selectionSize = 1;
	protected int cloningSize = 5;	
	protected double mutationRate = 1.0/(3.0*64.0);
	
	// data
	protected Random rand;
	protected SpatialCell [][] repertoire;
	
	
	@Override
	protected LinkedList<CellSet> internalInitialiseBeforeRun(Problem problem)
	{
		SpatialPatternRecognition p = (SpatialPatternRecognition) problem;		
		rand = new Random(seed);		
		
		repertoire = new SpatialCell[repertoireSize][repertoireSize];
		for (int i = 0; i < repertoire.length; i++)
		{
			for (int j = 0; j < repertoire[i].length; j++)
			{
				boolean [] data = RandomUtils.randomBitString(rand, 3, 64);
				repertoire[i][j] = new SpatialCell(data);
				repertoire[i][j].setCoord(new int[]{i, j});
			}
		}		
		
		// no initial population
		return null;
	}	
	
	protected LinkedList<SpatialCell> cloningAndMutation(SpatialCell current)
	{
		LinkedList<SpatialCell> newPop = new LinkedList<SpatialCell>();		
					
		for (int j = 0; j < cloningSize; j++)
		{
			// copy
			boolean [] cloneData = ArrayUtils.copyArray(current.getData());
			// mutate
			EvolutionUtils.binaryMutate(cloneData, rand, mutationRate);
			// store
			SpatialCell clone = new SpatialCell(cloneData);
			newPop.add(clone);
		}	
		
		return newPop;
	}	
	
	protected void replacement(SpatialCell bmu, LinkedList<SpatialCell> clones)
	{		
		// square neighbourhood
		LinkedList<SpatialCell> neigh = SpatialUtils.getNeighbours(bmu, repertoire);		
		LinkedList<SpatialCell> exc = new LinkedList<SpatialCell>();
		
		for(SpatialCell c : clones)
		{
			// select most similar neighbour
			SpatialCell sim = SpatialUtils.getMostSimilarWithExclusion(c, neigh, exc);
						
			// check affinity
			if(c.getScore() < sim.getScore())
			{
				int [] o = sim.getCoord();			
				repertoire[o[0]][o[1]] = c;
				c.setCoord(o);
				// remove from neighbourhood
				neigh.remove(sim);
				// add to exclusion
				exc.add(sim);
			}
		}		
	}
	
	protected Cell singleExposure(SpatialPatternRecognition pr, int subProblemNo)
	{
		// locate the bmu
		SpatialCell bmu = evaluateAndGetBmu(pr, subProblemNo);		
		// do cloning and mutation
		LinkedList<SpatialCell> clones = cloningAndMutation(bmu);
		// evaluate clones (for visualisation)
		evaluateClones(pr, subProblemNo, clones);
		// do competative replacement
		replacement(bmu, clones);
		// return the original bmu		
		return bmu;
	}
	
	protected void evaluateClones(SpatialPatternRecognition p, int subProblemNo, LinkedList<SpatialCell> clones)
	{
		for(SpatialCell c : clones)
		{
			p.costCell(c, subProblemNo);
		}
	}
	
	protected SpatialCell evaluateAndGetBmu(SpatialPatternRecognition p, int subProblemNo)
	{
		LinkedList<SpatialCell> best = new LinkedList<SpatialCell>();
		
		for (int i = 0; i < repertoire.length; i++)
		{
			for (int j = 0; j < repertoire[i].length; j++)
			{
				p.costCell(repertoire[i][j], subProblemNo);
				// check for empty case
				if(best.isEmpty())
				{
					best.add( repertoire[i][j]);
				}
				// check for the same
				else if(repertoire[i][j].getScore() == best.getFirst().getScore())
				{
					best.add(repertoire[i][j]);
				}
				// check for better				
				else if(repertoire[i][j].getScore() < best.getFirst().getScore())
				{
					best.clear();
					best.add(repertoire[i][j]);
				}
			}
		}
		
		if(best.size() == 1)
		{
			return best.getFirst();
		}
		
		// tie handling
		return best.get(rand.nextInt(best.size()));
	}
	
	

	

	@Override
	protected LinkedList<CellSet> internalExecuteEpoch(Problem problem, LinkedList<CellSet> cp)
	{
		SpatialPatternRecognition p = (SpatialPatternRecognition) problem;			
		int numSubProblems = p.getNumInfections();
		
		Cell [] bmus = new Cell[numSubProblems];				
		
		// process each sub problem
		for (int i = 0; i < numSubProblems; i++)
		{
			bmus[i] = singleExposure(p, i);
		}	
		
		// create a cell set
		LinkedList<CellSet> nextgen = new LinkedList<CellSet>();
		nextgen.add(new CellSet(bmus));
		return nextgen;
	}

	@Override
	protected void internalPostEvaluation(Problem problem, LinkedList<CellSet> oldPopulation, LinkedList<CellSet> newPopulation)
	{}

	@Override
	public void validateConfiguration() throws InvalidConfigurationException
	{
		if(repertoireSize<0)
		{
			throw new InvalidConfigurationException("Invalid repertoireSize " + repertoireSize);
		}
	}

	@Override
	public String getName()
	{
		return "Spatial Clusterning (Similarity-Affinity)";
	}

	public long getSeed()
	{
		return seed;
	}

	public void setSeed(long seed)
	{
		this.seed = seed;
	}

	public SpatialCell[][] getRepertoire()
	{
		return repertoire;
	}
}

