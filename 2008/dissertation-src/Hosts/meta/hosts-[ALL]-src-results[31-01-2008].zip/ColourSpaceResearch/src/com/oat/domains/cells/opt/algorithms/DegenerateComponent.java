/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006, 2007  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.cells.opt.algorithms;

import java.util.Collections;
import java.util.LinkedList;
import java.util.Random;

import com.oat.EpochAlgorithm;
import com.oat.InvalidConfigurationException;
import com.oat.Problem;
import com.oat.domains.cells.opt.Cell;
import com.oat.domains.cells.opt.problems.Optimisation;
import com.oat.utils.ArrayUtils;
import com.oat.utils.EvolutionUtils;
import com.oat.utils.RandomUtils;


/**
 * Description: Degenerate component (RGB) based representation with greedy solution construction
 *  
 * Date: 30/10/2007<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class DegenerateComponent extends EpochAlgorithm<Cell>
{
	// config
	protected long seed = 1;
	
	// 3 times as many cells because we are working with degenerate receptors
	protected int repertoireSize = 100; // (300) 
	protected int selectionSize = 20; // (60)
	protected int cloningSize = 5;	// (15)
	protected double mutationRate = 1.0/64.0; 	
	
	// data
	protected LinkedList<Cell> cellsg1;
	protected LinkedList<Cell> cellsg2;
	protected LinkedList<Cell> cellsg3;
	
	protected Random rand;	
	
	
	@Override
	protected LinkedList<Cell> internalInitialiseBeforeRun(Problem problem)
	{
		rand = new Random(seed);
		cellsg1 = new LinkedList<Cell>();
		for (int i = 0; i < repertoireSize; i++)
		{
			boolean [] data = RandomUtils.randomBitString(rand, 1, 64);
			Cell c = new Cell(data, 0); // 0	
			cellsg1.add(c);
		}			
		cellsg2 = new LinkedList<Cell>();
		for (int i = 0; i < repertoireSize; i++)
		{
			boolean [] data = RandomUtils.randomBitString(rand, 1, 64);
			Cell c = new Cell(data, 1); // 1
			cellsg2.add(c);
		}
		cellsg3 = new LinkedList<Cell>();
		for (int i = 0; i < repertoireSize; i++)
		{
			boolean [] data = RandomUtils.randomBitString(rand, 1, 64);
			Cell c = new Cell(data, 2); // 2
			cellsg3.add(c);
		}		
		
		LinkedList<Cell> pop = new LinkedList<Cell>();
		
		// make a random 'real' cell set from the degenerate parts
		for (int i = 0; i < repertoireSize; i++)
		{
			// get a cell for each surface feature
			Cell gene1 = cellsg1.get(rand.nextInt(repertoireSize));
			Cell gene2 = cellsg2.get(rand.nextInt(repertoireSize));
			Cell gene3 = cellsg3.get(rand.nextInt(repertoireSize));
			// build it
			Cell master = createMasterCellFromDegenerateCells(gene1, gene2, gene3);
			pop.add(master);
		}			
		
		return pop;
	}
	
	protected Cell createMasterCellFromDegenerateCells(Cell g1, Cell g2, Cell g3)
	{
		boolean [] b = new boolean[3*64];
		
		// 1
		int off = 0;
		System.arraycopy(g1.getData(), 0, b, 0, g1.getData().length);
		off += g1.getData().length;
		// 2
		System.arraycopy(g2.getData(), 0, b, off, g2.getData().length);
		off += g2.getData().length;
		// 3
		System.arraycopy(g3.getData(), 0, b, off, g3.getData().length);		
		off += g3.getData().length;
		
		if(off != b.length)
		{
			throw new RuntimeException("Error in master cell creation");
		}
		
		return new Cell(b);
	}
	
	
	
	protected LinkedList<Cell> cloningAndMutation(Optimisation p, LinkedList<Cell> selectedSet)
	{
		LinkedList<Cell> newPop = new LinkedList<Cell>();
		
		for(Cell current : selectedSet)
		{			
			for (int j = 0; j < cloningSize; j++)
			{
				// copy
				boolean [] cloneData = ArrayUtils.copyArray(current.getData());
				// mutate
				EvolutionUtils.binaryMutate(cloneData, rand, mutationRate);
				// store
				Cell clone = new Cell(cloneData, current.getGene());
				newPop.add(clone);
			}
		}
		
		return newPop;
	}
	
	
	protected LinkedList<Cell> evaluateAndSelect(Optimisation p, LinkedList<Cell> pop)
	{
		// assess first
		for(Cell c : pop)
		{
			p.costSingleFeature(c);
		}
		
		// order by utility
		Collections.sort(pop);	
		
		LinkedList<Cell> selectedSet = new LinkedList<Cell>();		
		for (int i = 0; i < selectionSize; i++)
		{
			Cell current = (p.isMinimization()) ? pop.get(i) : pop.get(pop.size()-1-i);
			selectedSet.add(current);
		}
		
		return selectedSet;
	}
	

	@Override
	protected LinkedList<Cell> internalExecuteEpoch(Problem problem, LinkedList<Cell> pop)
	{		
		Optimisation p = (Optimisation) problem;
		
		// select good degenerate parts
		LinkedList<Cell> selectedg1 = evaluateAndSelect(p, cellsg1);
		LinkedList<Cell> selectedg2 = evaluateAndSelect(p, cellsg2);
		LinkedList<Cell> selectedg3 = evaluateAndSelect(p, cellsg3);		
		
		// build the next evaluation set
		// make a random 'real' cell set from the degenerate parts
		LinkedList<Cell> newPop = new LinkedList<Cell>();
		for (int i = 0; i < repertoireSize; i++)
		{
			// i know it is minimisation, thus take the 100 best
			
			// get a cell for each surface feature
			Cell gene1 = cellsg1.get(i);
			Cell gene2 = cellsg2.get(i);
			Cell gene3 = cellsg3.get(i);
			// build it
			Cell master = createMasterCellFromDegenerateCells(gene1, gene2, gene3);
			// add to next generation
			newPop.add(master);
		}			
		
		// do cloning and mutation for each degenerate pop
		cellsg1 = cloningAndMutation(p, selectedg1);
		cellsg2 = cloningAndMutation(p, selectedg2);
		cellsg3 = cloningAndMutation(p, selectedg3);
		
		return newPop;
	}

	@Override
	protected void internalPostEvaluation(Problem problem, LinkedList<Cell> oldPopulation, LinkedList<Cell> newPopulation)
	{}

	@Override
	public void validateConfiguration() throws InvalidConfigurationException
	{
		if(repertoireSize<0)
		{
			throw new InvalidConfigurationException("Invalid repertoireSize " + repertoireSize);
		}
	}

	@Override
	public String getName()
	{
		return "Degenerate-Component";
	}

	public long getSeed()
	{
		return seed;
	}

	public void setSeed(long seed)
	{
		this.seed = seed;
	}
}
