/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006, 2007  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.cells.patrec.algorithms;

import java.util.Collections;
import java.util.LinkedList;
import java.util.Random;

import com.oat.EpochAlgorithm;
import com.oat.InvalidConfigurationException;
import com.oat.Problem;
import com.oat.domains.cells.opt.Cell;
import com.oat.domains.cells.opt.DegenerateCell;
import com.oat.domains.cells.patrec.CellSet;
import com.oat.domains.cells.patrec.problems.PatternRecognition;
import com.oat.utils.ArrayUtils;
import com.oat.utils.EvolutionUtils;
import com.oat.utils.RandomUtils;

/**
 * Description: Degenerate Substring
 *  
 * Date: 31/10/2007<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class DegenerateSubstring extends EpochAlgorithm<CellSet>
{
	// config
	protected long seed = 1;
	protected int repertoireSize = 30;
	protected int selectionSize = 3;
	protected int cloningSize = 10;
	protected double mutationRate = 1.0/(64.0*3);
	
	// data
	protected Random rand;
	protected LinkedList<DegenerateCell> cells;
	
	
	@Override
	protected LinkedList<CellSet> internalInitialiseBeforeRun(Problem problem)
	{
		rand = new Random(seed);
		cells = new LinkedList<DegenerateCell>();
		
		for (int i = 0; i < repertoireSize; i++)
		{
			boolean [] data = RandomUtils.randomBitString(rand, 64*3);
			boolean [] mask = RandomUtils.randomBitString(rand, 64*3);
			
			// mask the whole thing except a block of 64 contigious bits
//			int start = rand.nextInt(data.length-64);
//			boolean [] mask = new boolean[data.length];
//			for (int j = start; j < 64; j++)
//			{				
//				mask[j] = true;
//			}
			
			
			DegenerateCell c = new DegenerateCell(data, mask);
			cells.add(c);
		}
		
		return null; // no initial population
	}	
	
	protected LinkedList<DegenerateCell> cloningAndMutation(LinkedList<DegenerateCell> selectedSet)
	{
		LinkedList<DegenerateCell> newPop = new LinkedList<DegenerateCell>();
		
		for(DegenerateCell current : selectedSet)
		{			
			for (int j = 0; j < cloningSize; j++)
			{
				// copy
				boolean [] cloneData = ArrayUtils.copyArray(current.getData());
				boolean [] cloneMask = ArrayUtils.copyArray(current.getMask());
				// mutate
				EvolutionUtils.binaryMutate(cloneData, rand, mutationRate);
				EvolutionUtils.binaryMutate(cloneMask, rand, mutationRate);
				// create and store
				DegenerateCell clone = new DegenerateCell(cloneData, cloneMask);
				newPop.add(clone);
			}
		}
		
		return newPop;
	}
	
	protected Cell probabilisticCellFromDegenerateRepertoire(LinkedList<DegenerateCell> pop)
	{
		// build a bit histogram
		int [][] histogram = new int[3*64][2];	// [i][0] == '0', [i][1] == '1'
		for (DegenerateCell c : pop)
		{
			boolean [] data = c.getData();
			boolean [] mask = c.getMask();			
			for (int i = 0; i < mask.length; i++)
			{
				if(mask[i])
				{
					if(data[i])
					{
						histogram[i][1]++;
					}
					else
					{
						histogram[i][0]++;
					}
				}
			}
		}
		// compress probabilities into crisp solution
		boolean [] data = new boolean[64*3];		
		for (int i = 0; i < data.length; i++)
		{
			// check for no information on the current bit
			// both zero or both the same
			if(histogram[i][0] == histogram[i][1])
			{
				// random
				data[i] = rand.nextBoolean();
			}
			else
			{
				// check for a zero case
				if(histogram[i][0] == 0)
				{
					data[i] = true;
				}
				else if(histogram[i][1] == 0)
				{
					data[i] = false;
				}
				else
				{
					// probability of zero
					double prob = histogram[i][0] / (histogram[i][0] + histogram[i][1]);
					data[i] = (rand.nextDouble() < prob) ? false : true;
				}
			} 
		}
		
		return new Cell(data);
	}
	
	
	protected LinkedList<DegenerateCell> evaluateAndSelect(
			PatternRecognition p, 
			LinkedList<DegenerateCell> pop, 
			int subProblemNumber)
	{
		// assess first
		for(DegenerateCell c : pop)
		{
			p.costSubStructure(c, subProblemNumber);
		}
		
		// order by utility
		Collections.sort(pop);	
		
		LinkedList<DegenerateCell> selectedSet = new LinkedList<DegenerateCell>();
		for (int i = 0; i < selectionSize; i++)
		{			
			// i know it is minimisation
			DegenerateCell current = pop.get(i);
			selectedSet.add(current);
		}
		
		return selectedSet;
	}	
	
	protected Cell compressSelectedSet(PatternRecognition p, LinkedList<DegenerateCell> selected, int subProblemNumber)
	{
		LinkedList<Cell> tmpRepertoire = new LinkedList<Cell>();
		
		// 30 per cell
		for (int i = 0; i < 30; i++)
		{
			// create
			Cell compressedCell = probabilisticCellFromDegenerateRepertoire(selected);
			// evaluate
			p.costCell(compressedCell, subProblemNumber);
			// store
			tmpRepertoire.add(compressedCell);
		}
		
		// order
		Collections.sort(tmpRepertoire);
		// return best
		return tmpRepertoire.getFirst();
	}
	

	@Override
	protected LinkedList<CellSet> internalExecuteEpoch(Problem problem, LinkedList<CellSet> currentPop)
	{
		PatternRecognition p = (PatternRecognition) problem;			
		int numSubProblems = p.getNumInfections();
		
		Cell [] bmus = new Cell[numSubProblems];		
		LinkedList<DegenerateCell> newCells = new LinkedList<DegenerateCell>();
		
		// process each sub problem
		for (int i = 0; i < numSubProblems; i++)
		{
			// select the activated set
			LinkedList<DegenerateCell> selected = evaluateAndSelect(p, cells, i);
			// compress to a single cell
			Cell compressedCell = compressSelectedSet(p, selected, i);
			// store the best matching unit
			bmus[i] = compressedCell;
			// cloning and mutation
			LinkedList<DegenerateCell> clones = cloningAndMutation(selected);
			// reduce clones back to the selected set
			clones = evaluateAndSelect(p, clones, i);
			// store in the new repertoire
			newCells.addAll(clones);
		}		
		// replace the current repertoire
		cells = newCells;
		
		// create a cell set
		LinkedList<CellSet> nextgen = new LinkedList<CellSet>();
		nextgen.add(new CellSet(bmus));
		return nextgen;
	}

	@Override
	protected void internalPostEvaluation(Problem problem, LinkedList<CellSet> oldPopulation, LinkedList<CellSet> newPopulation)
	{}

	@Override
	public void validateConfiguration() throws InvalidConfigurationException
	{}

	@Override
	public String getName()
	{
		return "Degenerate Substring";
	}

	public long getSeed()
	{
		return seed;
	}

	public void setSeed(long seed)
	{
		this.seed = seed;
	}
}
