/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006, 2007  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.cells.network.algorithms.classic;

import java.util.Collections;
import java.util.LinkedList;
import java.util.Random;

import com.oat.EpochAlgorithm;
import com.oat.InvalidConfigurationException;
import com.oat.Problem;
import com.oat.domains.cells.mediatedpattrec.CellUtils;
import com.oat.domains.cells.network.algorithms.Tissue;
import com.oat.domains.cells.network.problems.PRProblem;
import com.oat.domains.cells.opt.Cell;
import com.oat.domains.cells.patrec.CellSet;

/**
 * Description: 
 *  
 * Date: 13/11/2007<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class Classical extends EpochAlgorithm<CellSet>
	implements Tissue
{
	// config
	protected long seed = 1;
	protected int repertoireSize = 50;
	protected int selectionSize = 1;
	protected int cloningSize = 5;		
	
	// data
	protected Random rand;
	protected LinkedList<Cell> tmpRepertoire;
	protected LinkedList<Cell> cells;
	
	
	@Override
	protected LinkedList<CellSet> internalInitialiseBeforeRun(Problem problem)
	{
		rand = new Random(seed);			
		cells = CellUtils.getRandomRepertoire(rand, repertoireSize);		
		// no initial population
		return null;
	}	
	
	
	
	@Override
	public LinkedList<Cell> getRepertoire()
	{
		return cells;
	}



	protected void assessRepertoireAgainstAntigen(PRProblem p, int pattNo, LinkedList<Cell> repertoire)
	{
		for(Cell c : repertoire)
		{
			p.costCell(c, pattNo);
		}
	}		
	
	protected void addToNextREpertoire(LinkedList<Cell> contribution)
	{
		tmpRepertoire.addAll(contribution);
	}
	
	protected Cell exposure(PRProblem p, int pattNo)
	{		
		// assess repertoire
		assessRepertoireAgainstAntigen(p, pattNo, cells);
		// select the activated set
		LinkedList<Cell> selected = CellUtils.selectActivatedSet(cells, rand, selectionSize);
		Cell bmu = selected.getFirst();
		
		// cloning and mutation
		LinkedList<Cell> clones = CellUtils.cloningAndMutation(selected, cloningSize, rand);
		// store in temporary repertoire
		addToNextREpertoire(clones);
		
		return bmu;
	}
	
	
	

	@Override
	protected LinkedList<CellSet> internalExecuteEpoch(Problem problem, LinkedList<CellSet> cp)
	{
		PRProblem p = (PRProblem) problem;			
		int numSubProblems = p.getNumInfections();		
		Cell [] bmus = new Cell[numSubProblems];		
		
		tmpRepertoire = new LinkedList<Cell>();
		
		// process each sub problem
		for (int i = 0; i < numSubProblems; i++)
		{
			bmus[i] = exposure(p, i);
		}	
		
		// checking
		if(tmpRepertoire.size() != cells.size())
		{
			throw new RuntimeException("Temporary repertoire is the wrong size, "+tmpRepertoire.size()+", expected "+cells.size()+".");
		}
		
		// replace repertoire
		cells = tmpRepertoire;
		
		// create a cell set
		LinkedList<CellSet> nextgen = new LinkedList<CellSet>();
		nextgen.add(new CellSet(bmus));
		return nextgen;
	}

	@Override
	protected void internalPostEvaluation(Problem problem, LinkedList<CellSet> oldPopulation, LinkedList<CellSet> newPopulation)
	{}

	@Override
	public void validateConfiguration() throws InvalidConfigurationException
	{}

	@Override
	public String getName()
	{
		return "Classical";
	}

	public long getSeed()
	{
		return seed;
	}

	public void setSeed(long seed)
	{
		this.seed = seed;
	}
}
