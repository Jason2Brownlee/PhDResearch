/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006, 2007  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.cells.spatial.gui;

import java.awt.Color;
import java.awt.Graphics;
import java.util.LinkedList;

import com.oat.Algorithm;
import com.oat.AlgorithmEpochCompleteListener;
import com.oat.Problem;
import com.oat.Solution;
import com.oat.domains.cells.opt.problems.Optimisation;
import com.oat.domains.cells.patrec.problems.PatternRecognition;
import com.oat.domains.cells.spatial.SpatialCell;
import com.oat.domains.cells.spatial.SpatialUtils;
import com.oat.domains.cells.spatial.algorithms.SpatialRepertoire;
import com.oat.domains.cells.spatial.problems.SpatialPatternRecognition;
import com.oat.explorer.gui.AlgorithmChangedListener;
import com.oat.explorer.gui.ClearEventListener;
import com.oat.explorer.gui.plot.GenericProblemPlot;

/**
 * Description: 
 *  
 * Date: 01/11/2007<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class SpatialPatternsPlot extends GenericProblemPlot
	implements AlgorithmEpochCompleteListener, ClearEventListener, AlgorithmChangedListener
{	
	protected PatternRecognition problem;	
	protected SpatialRepertoire algorithm;
	
	protected Color [][] popColours;
	
	
	public SpatialPatternsPlot()
	{
		setName("Spatial Patterns");
	}
	
	@Override
	public void algorithmChangedEvent(Algorithm a)
	{
		synchronized(this)
		{			
			algorithm = null;
			clear();
		
			if(a instanceof SpatialRepertoire)
			{
				algorithm = (SpatialRepertoire) a;
			}
		}
		
		repaint();
	}

	@Override
	public void problemChangedEvent(Problem p)
	{
		synchronized(this)
		{			
			problem = null;
			clear();
		
			if(p instanceof PatternRecognition)
			{
				problem = (PatternRecognition) p;
			}
		}
		
		repaint();
	}

	@Override
	public void clear()
	{
		synchronized(this)
		{
			popColours = null;
		}
	}

	protected LinkedList<int []> bmusets;
	
	
	@Override
	public <T extends Solution> void epochCompleteEvent(Problem p, LinkedList<T> currentPop)
	{		
		synchronized(this)
		{
			if(problem == null || algorithm == null)
			{
				return;
			}			
			
			Optimisation [] subprobs = problem.getInfections();
			bmusets = new LinkedList<int[]>();
			
			SpatialCell [][] repertoire = algorithm.getRepertoire();
			popColours = new Color[repertoire.length][repertoire[0].length];
			for (int i = 0; i < repertoire.length; i++)
			{
				for (int j = 0; j < repertoire[i].length; j++)
				{
					popColours[i][j] = vectorToColor(repertoire[i][j].getDecodedData());
				}
			}
			
			// process each problem and locate bmu sets
			for (int i = 0; i < subprobs.length; i++)
			{
				LinkedList<SpatialCell> bmus = SpatialUtils.evaluateAndGetBmuSet((SpatialPatternRecognition)problem, i, repertoire); 
				for(SpatialCell b : bmus)
				{
					int [] o = b.getCoord();
					bmusets.add(o);
				}
			}
		}		
		
		repaint();
	}	
	
	protected Color vectorToColor(double [] v)
	{		
		return new Color((float)v[0], (float)v[1], (float)v[2]);
	}

	@Override
	protected void paintComponent(Graphics g)
	{
		synchronized(this)
		{
			if(popColours == null)
			{
				super.plotUnavailable(g);
				return;
			}
			
			// clear
			g.setColor(Color.WHITE);
			g.fillRect(0,0,getWidth(),getHeight());
			
			// calculate things
			int width = (int) Math.floor((double)getWidth() / popColours.length);
			int height = (int) Math.floor((double)getHeight() / popColours[0].length); 
			
			for (int i = 0; i < popColours.length; i++)
			{
				for (int j = 0; j < popColours[i].length; j++)
				{
					drawColor(g, popColours[i][j], i*width, j*height, width, height);
					// check if a bmu
//					if(bmusets.contains(popColours[i][j]))
//					{
//						g.setColor(Color.BLACK);
//						g.drawOval(i*width, j*height, width, height);
//					}
				}
			}	
			
			// bmu's
			for(int [] o : bmusets)
			{
				g.setColor(Color.BLACK);
				g.drawOval(o[0]*width, o[1]*height, width, height);
			}
		}
	}
	
	public void drawColor(Graphics g, Color c, int x, int y, int width, int height)
	{
		g.setColor(c);
		g.fillRect(x, y, width, height);				
		g.setColor(Color.BLACK);
		g.drawRect(x, y, width, height);
	}
	
}
