/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006, 2007  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.cells.opt.probes;

import java.util.LinkedList;

import com.oat.Problem;
import com.oat.Solution;
import com.oat.domains.cells.opt.Cell;
import com.oat.probes.GenericEpochCompletedProbe;
import com.oat.utils.BitStringUtils;

/**
 * Description: how different are all the solutions?
 *  
 * Date: 31/10/2007<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class DiversityComponent extends GenericEpochCompletedProbe
{
	protected double diversity = Double.NaN;

	@Override
	public Object getProbeObservation()
	{
		return new Double(diversity);
	}

	@Override
	public void reset()
	{
		diversity = Double.NaN;
	}

	@Override
	public <T extends Solution> void epochCompleteEvent(Problem p, LinkedList<T> currentPop)
	{
		// average hamming distance?
		int count = 0;
		double sumg1 = 0.0;
		double sumg2 = 0.0;
		double sumg3 = 0.0;
		
		for (int i = 0; i < currentPop.size(); i++)
		{
			Cell p1 = (Cell) currentPop.get(i);
			
			for (int j = i+1; j < currentPop.size(); j++)
			{
				Cell p2 = (Cell) currentPop.get(j);
				
				int offset = 0;
				sumg1 += BitStringUtils.hammingDistance(p1.getData(),offset, 64, p2.getData(), offset, 64);
				offset += 64;
				sumg2 += BitStringUtils.hammingDistance(p1.getData(),offset, 64, p2.getData(), offset, 64);
				offset += 64;
				sumg3 += BitStringUtils.hammingDistance(p1.getData(),offset, 64, p2.getData(), offset, 64);
				
				count++;
			}
		}
		
		// average each component
		sumg1 = sumg1 / count;
		sumg2 = sumg2 / count;
		sumg3 = sumg3 / count;
		
		// now record the average of the averages
		diversity = (sumg1 + sumg2 + sumg3) / 3.0;
	}

	@Override
	public String getName()
	{
		return "Component Diversity";
	}
}
