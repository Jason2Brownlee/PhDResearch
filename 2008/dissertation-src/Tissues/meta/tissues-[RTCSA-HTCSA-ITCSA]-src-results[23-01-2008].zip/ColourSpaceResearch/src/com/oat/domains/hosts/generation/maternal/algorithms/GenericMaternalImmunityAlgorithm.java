/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006-2008  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.hosts.generation.maternal.algorithms;

import java.util.LinkedList;

import com.oat.AlgorithmRunException;
import com.oat.Problem;
import com.oat.domains.cells.mediatedpattrec.CellUtils;
import com.oat.domains.cells.opt.Cell;
import com.oat.domains.hosts.population.transmission.algorithms.SingleRepertoire;
import com.oat.domains.tissues.InfectionProblem;

/**
 * Description: 
 *  
 * Date: 15/01/2008<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public abstract class GenericMaternalImmunityAlgorithm extends
		MinimalHostGenerationalAlgorithm
{	
	
	protected void doGenerationalChange(InfectionProblem problem)
	{
		// remember old population
		SingleRepertoire [] oldGeneration = hosts;		
		// create new hosts
		hosts = createPopulation((Problem)problem);
		// do inter-generational sharing
		doInterGenerationalSharing(oldGeneration, hosts);
		// trigger a change event
		triggerGenerationalChangeEvent(oldGeneration, hosts);
	}	
	
	
	/**
	 * Helper to clone cells from a host
	 * @param poolSize
	 * @param host
	 * @return
	 */
	protected LinkedList<Cell> copyRandomCellPool(int poolSize, SingleRepertoire host)
	{
		LinkedList<Cell> cells = new LinkedList<Cell>();
		
		// draw the random sample with reselection
		LinkedList<Cell> repertoire = host.getRepertoire();		
		while(cells.size() < poolSize)
		{
			Cell copy = new Cell(repertoire.get(rand.nextInt(repertoire.size())));
			cells.add(copy);
		}
		
		return cells;
	}
	
	
	/**
	 * Helper to integrate a pool of cells into a host
	 * @param host
	 * @param cells
	 */
	protected void selectivelyIntegrateSharedCells(SingleRepertoire host, LinkedList<Cell> cells)
	{
		LinkedList<Cell> repertoire = host.getRepertoire();
		
		for(Cell c : cells)
		{
			// Euclidean similarity tournament for competition
			Cell other = CellUtils.getMostSimilarEuclideanWithExclusion(c, host.getRepertoire(), cells);			
			repertoire.remove(other);
			repertoire.add(c);
		}
	}
	
	/**
	 * Helper to integrate a pool of cells into a host
	 * @param host
	 * @param cells
	 */
	protected void randomlyIntegrateSharedCells(SingleRepertoire host, LinkedList<Cell> cells)
	{
		LinkedList<Cell> repertoire = host.getRepertoire();
		
		for(Cell c : cells)
		{
			// random replacement
			Cell other = repertoire.get(rand.nextInt(repertoire.size()));			
			repertoire.remove(other);
			repertoire.add(c);
		}
	}
	
	
	/**
	 * Set a random set of hosts from the provided population
	 * @param aNumHosts
	 * @param pop
	 * @return
	 */
	protected LinkedList<SingleRepertoire> selectRandomSetOfHosts(int aNumHosts, SingleRepertoire [] pop)
	{
		if(aNumHosts > pop.length)
		{
			throw new AlgorithmRunException("The desired number of hosts ("+aNumHosts+") exceeds the number of hosts in the population ("+pop.length+").");
		}
		
		// select hosts to participate
		LinkedList<SingleRepertoire> sharingHosts = new LinkedList<SingleRepertoire>();
		// add all
		for (int i = 0; i < pop.length; i++)
		{
			sharingHosts.add(pop[i]);
		}
		// shrink to size
		while(sharingHosts.size() > aNumHosts)
		{
			sharingHosts.remove(rand.nextInt(sharingHosts.size()));
		}
		
		return sharingHosts;
	}
	
	
	protected abstract void doInterGenerationalSharing(SingleRepertoire [] oldGeneration, SingleRepertoire [] newGeneration);
	
	@Override
	public abstract String getName();
}
