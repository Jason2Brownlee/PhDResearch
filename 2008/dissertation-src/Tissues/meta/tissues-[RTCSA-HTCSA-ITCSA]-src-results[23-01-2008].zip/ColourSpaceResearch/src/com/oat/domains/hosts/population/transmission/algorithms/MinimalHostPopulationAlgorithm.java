/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006-2008  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.hosts.population.transmission.algorithms;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;

import com.oat.Problem;
import com.oat.domains.cells.opt.Cell;
import com.oat.domains.cells.patrec.CellSet;
import com.oat.domains.tissues.InfectionProblem;
import com.oat.utils.EvolutionUtils;

/**
 * Description: 
 *  
 * Date: 10/01/2008<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class MinimalHostPopulationAlgorithm extends GenericHostAlgorithm
{
	public static enum EXPOSURE_MODE {Symmetric, Random, Point, Infection}
	
	// config
	protected double preferenceProbability = 0.70; // 70% chance of staying	
	protected int durationLength = 15;
	protected EXPOSURE_MODE exposureMode = EXPOSURE_MODE.Infection;
	
	// state
	protected double [][] histogram;
	protected int currentDurationLength;
	protected int [] currentSelection;	
	
	@Override
	protected LinkedList<CellSet> internalInitialiseBeforeRun(Problem problem)
	{		
		InfectionProblem p = (InfectionProblem) problem;
		
		// reset things
		currentDurationLength = 0;
		histogram = new double[p.getNumInfections()][numHosts];		 
		currentSelection = new int[p.getNumInfections()];
		Arrays.fill(currentSelection, -1);
		// do the parental thing
		return super.internalInitialiseBeforeRun(problem);
	}

	public Cell repertoireExposureInfection(InfectionProblem p, int pattNo)
	{
		// check for a reset
		if(currentSelection[pattNo] == -1 || 
				currentDurationLength >= durationLength)
		{
			// make selection
			int selection = EvolutionUtils.biasedRouletteWheelSelection(histogram[pattNo], rand);
			// store selection
			currentSelection[pattNo] = selection;
			// reset count
			currentDurationLength = 0;
			// increment the frequency			
			histogram[pattNo][currentSelection[pattNo]]++;			
		}				
		
		// perform an exposure
		currentDurationLength++;		
		// simple one-to-one exposure scheme
		return doSpecificExposure(currentSelection[pattNo], p, pattNo);
	}

	
	public Cell repertoireExposureRandom(InfectionProblem p, int pattNo)
	{
		// select repertoire (wraps around the number of repertories)
		int repNo = rand.nextInt(numHosts);
		// simple one-to-one exposure scheme
		return doSpecificExposure(repNo, p, pattNo);
	}
	
	public Cell repertoireExposurePoint(InfectionProblem p, int pattNo)
	{
		// always the same
		int repNo = 1;		
		// simple one-to-one exposure scheme
		return doSpecificExposure(repNo, p, pattNo);
	}
	
	public Cell repertoireExposureSymmetric(InfectionProblem p, int pattNo)
	{
		LinkedList<Cell> repertoireBMUs = new LinkedList<Cell>();
		
		// expose to each repertoire
		for (int i = 0; i < hosts.length; i++)
		{
			// exposure
			Cell bmu = doSpecificExposure(i, p, pattNo);
			// record
			repertoireBMUs.add(bmu);
		}
		
		Collections.shuffle(repertoireBMUs, rand); // random tie handling
		Collections.sort(repertoireBMUs); // order by affinity
		return repertoireBMUs.getFirst(); // return the best
	}
	
	
	protected Cell doSpecificExposure(int hostNumber, InfectionProblem p, int pattNo)
	{
		// retrieve host
		SingleRepertoire host = hosts[hostNumber];
		// exposure
		Cell bmu = host.exposure(p, pattNo);
		// trigger event
		triggerExposureEvent(hostNumber, host, pattNo, p.getInfections()[pattNo]);
		return bmu;
	}
	
	
	@Override
	public Cell repertoireExposure(InfectionProblem p, int pattNo)
	{
		Cell bmu = null;
		
		switch(exposureMode)
		{			
		case Symmetric:
			bmu = repertoireExposureSymmetric(p, pattNo);
			break;
			
		case Random:
			bmu = repertoireExposureRandom(p, pattNo);
			break;
			
		case Point:
			bmu = repertoireExposurePoint(p, pattNo);
			break;
			
		case Infection: 
			bmu = repertoireExposureInfection(p, pattNo);
			break;
			
		default:
			throw new RuntimeException("Invalid exposure mode: " + exposureMode);
		}
		
		return bmu;
	}

	@Override
	public void hostInteractions(InfectionProblem p)
	{} // none

	@Override
	public String getName()
	{
		return "Minimal Host Population Algorithm";
	}

	public EXPOSURE_MODE getExposureMode()
	{
		return exposureMode;
	}

	public void setExposureMode(EXPOSURE_MODE exposureMode)
	{
		this.exposureMode = exposureMode;
	}	
}
