/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006, 2007  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.cells.spatial;

import java.util.LinkedList;

import com.oat.domains.cells.spatial.problems.SpatialPatternRecognition;
import com.oat.utils.BitStringUtils;

/**
 * Description: 
 *  
 * Date: 03/11/2007<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class SpatialUtils
{
	
	public static SpatialCell getMostSimilar(SpatialCell cell, LinkedList<SpatialCell> set)
	{
		double  min = Double.POSITIVE_INFINITY;
		SpatialCell best = null;
		
		for(SpatialCell c : set)
		{
			double d = BitStringUtils.hammingDistance(cell.getData(), c.getData());
			if(d < min)
			{
				min = d;
				best = c;
			}
		}
		
		return best;		
	}
	
	public static SpatialCell getMostSimilarWithExclusion(SpatialCell cell, LinkedList<SpatialCell> set, LinkedList<SpatialCell> exclude)
	{
		double  min = Double.POSITIVE_INFINITY;
		SpatialCell best = null;
		
		for(SpatialCell c : set)
		{
			if(exclude.contains(c))
			{
				continue;
			}
			
			double d = BitStringUtils.hammingDistance(cell.getData(), c.getData());
			if(d < min)
			{
				min = d;
				best = c;
			}
		}
		
		return best;		
	}
	
	
	public static LinkedList<SpatialCell> evaluateAndGetBmuSet(SpatialPatternRecognition p, int subProblemNo, SpatialCell[][] rep)
	{
		LinkedList<SpatialCell> best = new LinkedList<SpatialCell>();
		
		for (int i = 0; i < rep.length; i++)
		{
			for (int j = 0; j < rep[i].length; j++)
			{
				p.costCell(rep[i][j], subProblemNo);
				// check for empty case
				if(best.isEmpty())
				{
					best.add(rep[i][j]);
				}
				// check for the same
				else if(rep[i][j].getScore() == best.getFirst().getScore())
				{
					best.add(rep[i][j]);
				}
				// check for better				
				else if(rep[i][j].getScore() < best.getFirst().getScore())
				{
					best.clear();
					best.add(rep[i][j]);
				}
			}
		}
		
		return best;
	}
	
	/**
	 * Get spatial neighbourhood
	 * @param cell
	 * @param r
	 * @return
	 */
	public static LinkedList<SpatialCell> getNeighbours(SpatialCell cell, SpatialCell[][] r)
	{
		LinkedList<SpatialCell> neighbours = new LinkedList<SpatialCell>();
		int [] origin = cell.getCoord();
		
		// lines
		for (int x = origin[0]-1; x <= origin[0]+1; x++)
		{
			int px = x;
			
			if(px<0)
			{
				px = r.length-1;
			}
			else if(px>r.length-1)
			{
				px = 0;
			}
			
			// positions
			for (int y = origin[1]-1; y <= origin[1]+1; y++)
			{
				int py = y;
				if(py<0)
				{
					py = r.length-1;
				}
				else if(py>r.length-1)
				{
					py = 0;
				}
				
				// do it
				neighbours.add(r[px][py]);
			}
		}
		
		if(neighbours.size() != 9)
		{
			throw new RuntimeException("Error collecting neighbours");
		}
		
		return neighbours;
	}
}
