/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006, 2007  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.cells.spatial;

import java.util.Collections;
import java.util.LinkedList;

import com.oat.Algorithm;
import com.oat.Domain;
import com.oat.Problem;
import com.oat.RunProbe;
import com.oat.StopCondition;
import com.oat.domains.cells.opt.stopcondition.FoundOptimaOrMaxEpochs;
import com.oat.domains.cells.opt.stopcondition.FoundOptimaStopCondition;
import com.oat.domains.cells.spatial.algorithms.clustering.SpatialPartitionRandom;
import com.oat.domains.cells.spatial.algorithms.clustering.SpatialPartitionRandomAffinity;
import com.oat.domains.cells.spatial.algorithms.clustering.SpatialPartitionSimilarity;
import com.oat.domains.cells.spatial.algorithms.clustering.SpatialPartitionSimilarityAffinity;
import com.oat.domains.cells.spatial.algorithms.degenerate.SpatialComponentsBottomUp;
import com.oat.domains.cells.spatial.algorithms.degenerate.SpatialComponentsTopDown;
import com.oat.domains.cells.spatial.algorithms.partitions.SpatialPartitionBackend;
import com.oat.domains.cells.spatial.algorithms.partitions.SpatialPartitionUpfront;
import com.oat.domains.cells.spatial.gui.CellularSpatialMasterPanel;
import com.oat.domains.cells.spatial.probes.AverageBMUs;
import com.oat.domains.cells.spatial.probes.PatternDiversity;
import com.oat.domains.cells.spatial.probes.SpatialPatternDiversity;
import com.oat.domains.cells.spatial.problems.SpatialPatternRecognition;
import com.oat.explorer.gui.panels.MasterPanel;
import com.oat.explorer.gui.plot.GenericProblemPlot;

/**
 * Description: 
 *  
 * Date: 01/11/2007<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class CellsSpatialDomain extends Domain
{
	@Override
	public MasterPanel getExplorerPanel()
	{
		return new CellularSpatialMasterPanel(this);
	}

	@Override
	public String getHumanReadableName()
	{
		return "Cellular Spatial";
	}

	@Override
	public String getShortName()
	{
		return "cellspatial";
	}

	@Override
	public Algorithm[] loadAlgorithmList() throws Exception
	{
		return new Algorithm[]
		                     {				
				new SpatialPartitionUpfront(),
				new SpatialPartitionBackend(),
				
				new SpatialPartitionRandom(),
				new SpatialPartitionRandomAffinity(),
				new SpatialPartitionSimilarity(),
				new SpatialPartitionSimilarityAffinity(),
				
				new SpatialComponentsTopDown(),
				new SpatialComponentsBottomUp()
		                     };
	}

	@Override
	public Problem[] loadProblemList() throws Exception
	{
		return new Problem[]
		                   {
				new SpatialPatternRecognition()
		                   };
	}

	@Override
	public GenericProblemPlot prepareProblemPlot()
	{
		return null;
	}
	
	@Override
	public LinkedList<StopCondition> loadDomainStopConditions()
	{
		LinkedList<StopCondition> list = super.loadDomainStopConditions();
		list.add(new FoundOptimaStopCondition());		
		list.add(new FoundOptimaOrMaxEpochs());
		Collections.sort(list);		
		return list;
	}
	
	@Override
	public LinkedList<RunProbe> loadDomainRunProbes()
	{
		LinkedList<RunProbe> list = super.loadDomainRunProbes();		
		
		list.add(new SpatialPatternDiversity());
		list.add(new AverageBMUs());
		list.add(new PatternDiversity());
		
		Collections.sort(list);		
		return list;
	}
}
