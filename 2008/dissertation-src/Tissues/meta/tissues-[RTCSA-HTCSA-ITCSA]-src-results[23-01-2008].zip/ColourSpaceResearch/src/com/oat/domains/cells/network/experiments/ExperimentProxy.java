/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006, 2007  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.cells.network.experiments;

import java.util.LinkedList;

import com.oat.Domain;
import com.oat.StopCondition;
import com.oat.domains.cells.network.NetworkDomain;
import com.oat.domains.cells.network.algorithms.proxy.ProxyResponseAggregate;
import com.oat.domains.cells.network.algorithms.proxy.ProxyResponseAntigen;
import com.oat.domains.cells.network.algorithms.proxy.ProxyResponseBottomUp;
import com.oat.domains.cells.network.algorithms.proxy.ProxyResponseTopDown;
import com.oat.domains.cells.network.problems.PRProblem2;
import com.oat.domains.cells.opt.stopcondition.FoundOptimaOrMaxEpochs;
import com.oat.experimenter.ExperimentalRun;
import com.oat.experimenter.TemplateExperiment;

/**
 * Description: 
 *  
 * Date: 16/11/2007<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class ExperimentProxy extends TemplateExperiment
{
	public static void main(String[] args)
	{
		new ExperimentProxy().run();
	}
	

	@Override
	public LinkedList<ExperimentalRun> createRunList()
	{
		LinkedList<ExperimentalRun> list = new LinkedList<ExperimentalRun>();
		int id = 0;
		
		// 2-pattern problem
		
		// 4 different approaches		
		list.add(new ExperimentalRun("R"+(id++), new ProxyResponseTopDown(), new PRProblem2(), 30));
		list.add(new ExperimentalRun("R"+(id++), new ProxyResponseBottomUp(), new PRProblem2(), 30));
		list.add(new ExperimentalRun("R"+(id++), new ProxyResponseAntigen(), new PRProblem2(), 30));
		list.add(new ExperimentalRun("R"+(id++), new ProxyResponseAggregate(), new PRProblem2(), 30));
		
		return list;
	}

	@Override
	public Domain getDomain()
	{
		return new NetworkDomain();
	}

	@Override
	public String getExperimentDescription()
	{
		return "Network Proxy";
	}

	@Override
	public String getExperimentName()
	{
		return "NetProxy1";
	}

	@Override
	public StopCondition getStopCondition()
	{
		return new FoundOptimaOrMaxEpochs(5000); // 5K
	}
}
