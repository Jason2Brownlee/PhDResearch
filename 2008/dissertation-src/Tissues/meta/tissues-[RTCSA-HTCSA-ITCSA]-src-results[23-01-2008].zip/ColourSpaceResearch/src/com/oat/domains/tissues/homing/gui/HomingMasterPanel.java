/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006  Jason Brownlee

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/
package com.oat.domains.tissues.homing.gui;

import javax.swing.JPanel;

import com.oat.Domain;
import com.oat.domains.tissues.recirulation.gui.ExposurePlot;
import com.oat.domains.tissues.recirulation.gui.PatternRecognitionPlot;
import com.oat.domains.tissues.recirulation.gui.TissuePlot;
import com.oat.explorer.gui.panels.MasterPanel;

/**
 * Description: 
 *  
 * Date: 07/01/2008<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class HomingMasterPanel extends MasterPanel
{	
	protected PatternRecognitionPlot populationViewer;
	protected TissuePlot tissuePlot;
	protected ExposurePlot exposurePlot;
	protected PreferencePlot preferencePlot;

	
    public HomingMasterPanel(Domain domain)
	{
		super(domain);
	}

	@Override
    protected JPanel[] prepareAdditionalCentralPanels()
    {
		populationViewer = new PatternRecognitionPlot();		
		tissuePlot = new TissuePlot();
		exposurePlot = new ExposurePlot();
		preferencePlot = new PreferencePlot();
		
		return new JPanel[]{populationViewer, tissuePlot, exposurePlot, preferencePlot};
    }

    @Override
    protected void prepareAdditionalListeners()
    {
        // patt rec
        problemPanel.registerProblemChangedListener(populationViewer); // problem changes
        controlPanel.registerClearableListener(populationViewer); //clearing
        algorithmPanel.registerAlgorithmIterationCompleteListener(populationViewer); // algorithm epochs
        
        // tissue plot
        problemPanel.registerProblemChangedListener(tissuePlot); // problem changes
        controlPanel.registerClearableListener(tissuePlot); //clearing
        algorithmPanel.registerAlgorithmIterationCompleteListener(tissuePlot); // algorithm epochs
        algorithmPanel.registerAlgorithmChangedListener(tissuePlot);
        
        // exposure plot
        problemPanel.registerProblemChangedListener(exposurePlot); // problem changes
        controlPanel.registerClearableListener(exposurePlot); //clearing
        algorithmPanel.registerAlgorithmIterationCompleteListener(exposurePlot); // algorithm epochs
        algorithmPanel.registerAlgorithmChangedListener(exposurePlot);        
        
        // preference plot
        problemPanel.registerProblemChangedListener(preferencePlot); // problem changes
        controlPanel.registerClearableListener(preferencePlot); //clearing
        algorithmPanel.registerAlgorithmIterationCompleteListener(preferencePlot); // algorithm epochs
        algorithmPanel.registerAlgorithmChangedListener(preferencePlot);
    }    
}
