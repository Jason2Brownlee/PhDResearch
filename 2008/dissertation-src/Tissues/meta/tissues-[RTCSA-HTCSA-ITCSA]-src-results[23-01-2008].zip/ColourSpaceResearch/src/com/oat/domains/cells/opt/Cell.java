/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006, 2007  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.cells.opt;

import com.oat.Solution;
import com.oat.SolutionEvaluationException;
import com.oat.domains.cells.mediatedpattrec.CellUtils;
import com.oat.utils.ArrayUtils;
import com.oat.utils.BitStringUtils;

/**
 * Description: 
 *  
 * Date: 14/01/2008<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class Cell extends Solution
{
	protected final boolean [] data;
	protected final int gene;
	
	protected double [] decodedData;
	
	public Cell(Cell aOtherCell)
	{
		data = ArrayUtils.copyArray(aOtherCell.data);
		gene = aOtherCell.gene;
		if(aOtherCell.decodedData != null)
		{
			decodedData = ArrayUtils.copyArray(aOtherCell.decodedData);
		}
		if(aOtherCell.isEvaluated)
		{
			evaluated(aOtherCell.getScore());
		}
	}
	
	public Cell(boolean [] aData)
	{
		this(aData, -1);
	}
	
	public Cell(boolean [] aData, int aGene)
	{
		data = aData;
		gene = aGene;
		
		// check for a full colour
		if(data.length == 64*3 && gene == -1)
		{
			// hack
			CellUtils.forceDecode(this);
		}
	}
	
	
	@Override
    public void evaluated(double aCost)
		throws SolutionEvaluationException
	{
		// allow re-evaluation
	    isEvaluated = false;
	    super.evaluated(aCost);
	} 
	

	@Override
	public boolean equals(Object o)
	{
		return this == o;
	}
	
	public String toString()
	{
		return BitStringUtils.toString(data);
	}



	public double[] getDecodedData()
	{
		return decodedData;
	}



	public void setDecodedData(double[] decodedData)
	{
		this.decodedData = decodedData;
	}



	public boolean[] getData()
	{
		return data;
	}

	public int getGene()
	{
		return gene;
	}
}
