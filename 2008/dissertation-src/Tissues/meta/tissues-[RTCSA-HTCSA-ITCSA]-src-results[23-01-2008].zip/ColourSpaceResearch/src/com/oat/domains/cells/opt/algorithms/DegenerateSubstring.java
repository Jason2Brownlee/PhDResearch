/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006, 2007  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.cells.opt.algorithms;

import java.util.Collections;
import java.util.LinkedList;
import java.util.Random;

import com.oat.EpochAlgorithm;
import com.oat.InvalidConfigurationException;
import com.oat.Problem;
import com.oat.domains.cells.opt.Cell;
import com.oat.domains.cells.opt.DegenerateCell;
import com.oat.domains.cells.opt.problems.Optimisation;
import com.oat.utils.ArrayUtils;
import com.oat.utils.EvolutionUtils;
import com.oat.utils.RandomUtils;


/**
 * Description: Degenerate substring representation with probabilistic generation of solutions
 *  
 * Date: 31/10/2007<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class DegenerateSubstring extends EpochAlgorithm<Cell>
{
	// config
	protected long seed = 1;
	
	// 3 times as many cells because we are working with degenerate receptors
	protected int repertoireSize = 300; // (300) 
	protected int selectionSize = 60; // (60)
	protected int cloningSize = 15;	// (15)	 	
	protected double mutationRate = 1.0/(3.0*64.0);
	
	protected int realRepertoireSize = 100;
	
	// data
	protected LinkedList<DegenerateCell> cells;	
	protected Random rand;	
	
	
	@Override
	protected LinkedList<Cell> internalInitialiseBeforeRun(Problem problem)
	{
		rand = new Random(seed);
		cells = new LinkedList<DegenerateCell>();
		
		for (int i = 0; i < repertoireSize; i++)
		{
			boolean [] data = RandomUtils.randomBitString(rand, 64*3);
			boolean [] mask = RandomUtils.randomBitString(rand, 64*3);
			DegenerateCell c = new DegenerateCell(data, mask);
			cells.add(c);
		}		
		
		LinkedList<Cell> pop = new LinkedList<Cell>();	
		for (int i = 0; i < realRepertoireSize; i++)
		{
			pop.add(probabilisticCellFromDegenerateRepertoire(cells));
		}
		
		return pop;
	}
	
	protected Cell probabilisticCellFromDegenerateRepertoire(LinkedList<DegenerateCell> pop)
	{
		// build a bit histogram
		int [][] histogram = new int[3*64][2];	// [i][0] == '0', [i][1] == '1'
		for (DegenerateCell c : pop)
		{
			boolean [] data = c.getData();
			boolean [] mask = c.getMask();			
			for (int i = 0; i < mask.length; i++)
			{
				if(mask[i])
				{
					if(data[i])
					{
						histogram[i][1]++;
					}
					else
					{
						histogram[i][0]++;
					}
				}
			}
		}
		// compress probabilities into crisp solution
		boolean [] data = new boolean[64*3];		
		for (int i = 0; i < data.length; i++)
		{
			// check for no information on the current bit
			// both zero or both the same
			if(histogram[i][0] == histogram[i][1])
			{
				// random
				data[i] = rand.nextBoolean();
			}
			else
			{
				// check for a zero case
				if(histogram[i][0] == 0)
				{
					data[i] = true;
				}
				else if(histogram[i][1] == 0)
				{
					data[i] = false;
				}
				else
				{
					// probability of zero
					double prob = histogram[i][0] / (histogram[i][0] + histogram[i][1]);
					data[i] = (rand.nextDouble() < prob) ? false : true;
				}
			} 
		}
		
		return new Cell(data);
	}
	
	
	
	protected LinkedList<DegenerateCell> cloningAndMutation(Optimisation p, LinkedList<DegenerateCell> selectedSet)
	{
		LinkedList<DegenerateCell> newPop = new LinkedList<DegenerateCell>();
		
		for(DegenerateCell current : selectedSet)
		{			
			for (int j = 0; j < cloningSize; j++)
			{
				// copy
				boolean [] cloneData = ArrayUtils.copyArray(current.getData());
				boolean [] cloneMask = ArrayUtils.copyArray(current.getMask());
				// mutate
				EvolutionUtils.binaryMutate(cloneData, rand, mutationRate);
				EvolutionUtils.binaryMutate(cloneMask, rand, mutationRate);
				// create and store
				DegenerateCell clone = new DegenerateCell(cloneData, cloneMask);
				newPop.add(clone);
			}
		}
		
		return newPop;
	}
	

	
	
	protected LinkedList<DegenerateCell> evaluateAndSelect(Optimisation p, LinkedList<DegenerateCell> pop)
	{
		// assess first
		for(DegenerateCell c : pop)
		{
			p.costSubStructure(c);
		}
		
		// order by utility
		Collections.sort(pop);	
		
		LinkedList<DegenerateCell> selectedSet = new LinkedList<DegenerateCell>();		
		for (int i = 0; i < selectionSize; i++)
		{
			DegenerateCell current = (p.isMinimization()) ? pop.get(i) : pop.get(pop.size()-1-i);
			selectedSet.add(current);
		}
		
		return selectedSet;
	}
	

	@Override
	protected LinkedList<Cell> internalExecuteEpoch(Problem problem, LinkedList<Cell> pop)
	{				
		Optimisation p = (Optimisation) problem;
		
		// select good degenerate parts
		LinkedList<DegenerateCell> selected = evaluateAndSelect(p, cells);
		
		// build next generation from the selected set
		LinkedList<Cell> nextgen = new LinkedList<Cell>();		
		for (int i = 0; i < realRepertoireSize; i++)
		{
			nextgen.add(probabilisticCellFromDegenerateRepertoire(selected));
		}			
		
		// do cloning and mutation for each degenerate pop
		cells = cloningAndMutation(p, selected);
		
		return nextgen;
	}

	@Override
	protected void internalPostEvaluation(Problem problem, LinkedList<Cell> oldPopulation, LinkedList<Cell> newPopulation)
	{}

	@Override
	public void validateConfiguration() throws InvalidConfigurationException
	{
		if(repertoireSize<0)
		{
			throw new InvalidConfigurationException("Invalid repertoireSize " + repertoireSize);
		}
	}

	@Override
	public String getName()
	{
		return "Degenerate-Substring";
	}

	public long getSeed()
	{
		return seed;
	}

	public void setSeed(long seed)
	{
		this.seed = seed;
	}
}
