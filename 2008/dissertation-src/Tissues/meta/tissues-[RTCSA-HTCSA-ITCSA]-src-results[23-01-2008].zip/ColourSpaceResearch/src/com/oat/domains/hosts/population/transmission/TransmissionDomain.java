/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006, 2007  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.hosts.population.transmission;

import java.util.Collections;
import java.util.LinkedList;

import com.oat.Algorithm;
import com.oat.Domain;
import com.oat.Problem;
import com.oat.RunProbe;
import com.oat.StopCondition;
import com.oat.domains.cells.mediatedpattrec.probes.AEEuclidean;
import com.oat.domains.cells.mediatedpattrec.probes.AEHamming;
import com.oat.domains.cells.mediatedpattrec.probes.OptimaDiversity;
import com.oat.domains.cells.mediatedpattrec.probes.RMSEEuclidean;
import com.oat.domains.cells.mediatedpattrec.probes.RMSEHamming;
import com.oat.domains.cells.mediatedpattrec.probes.SolutionDiversity;
import com.oat.domains.cells.opt.stopcondition.FoundOptimaOrMaxEpochs;
import com.oat.domains.cells.opt.stopcondition.FoundOptimaStopCondition;
import com.oat.domains.hosts.population.transmission.algorithms.MinimalHostPopulationAlgorithm;
import com.oat.domains.hosts.population.transmission.algorithms.minimal.HostMinimalInfection;
import com.oat.domains.hosts.population.transmission.algorithms.minimal.HostMinimalPoint;
import com.oat.domains.hosts.population.transmission.algorithms.minimal.HostMinimalRandom;
import com.oat.domains.hosts.population.transmission.algorithms.pathogen.PathogenDynamics;
import com.oat.domains.hosts.population.transmission.algorithms.pathogen.randompairings.PathogenDynamicsPairingInfection;
import com.oat.domains.hosts.population.transmission.algorithms.pathogen.randompairings.PathogenDynamicsPairingPoint;
import com.oat.domains.hosts.population.transmission.algorithms.pathogen.randompairings.PathogenDynamicsPairingRandom;
import com.oat.domains.hosts.population.transmission.algorithms.pathogen.spatial.PathogenDynamicsSpatialInfection;
import com.oat.domains.hosts.population.transmission.algorithms.pathogen.spatial.PathogenDynamicsSpatialPoint;
import com.oat.domains.hosts.population.transmission.algorithms.pathogen.spatial.PathogenDynamicsSpatialRandom;
import com.oat.domains.hosts.population.transmission.algorithms.vaccination.blind.BlindVaccination;
import com.oat.domains.hosts.population.transmission.algorithms.vaccination.blind.BlindVaccinationInfection;
import com.oat.domains.hosts.population.transmission.algorithms.vaccination.blind.BlindVaccinationPoint;
import com.oat.domains.hosts.population.transmission.algorithms.vaccination.blind.BlindVaccinationRandom;
import com.oat.domains.hosts.population.transmission.algorithms.vaccination.selective.SelectiveVaccination;
import com.oat.domains.hosts.population.transmission.algorithms.vaccination.selective.SelectiveVaccinationInfection;
import com.oat.domains.hosts.population.transmission.algorithms.vaccination.selective.SelectiveVaccinationPoint;
import com.oat.domains.hosts.population.transmission.algorithms.vaccination.selective.SelectiveVaccinationRandom;
import com.oat.domains.hosts.population.transmission.gui.TransmissionMasterPanel;
import com.oat.domains.hosts.population.transmission.probes.AverageExposuresPerEpoch;
import com.oat.domains.hosts.population.transmission.probes.AverageHostDiversity;
import com.oat.domains.hosts.population.transmission.probes.AverageHostError;
import com.oat.domains.hosts.population.transmission.probes.InterHostDiversity;
import com.oat.domains.tissues.recirulation.problems.ICSP_1;
import com.oat.domains.tissues.recirulation.problems.ICSP_10;
import com.oat.domains.tissues.recirulation.problems.InfectionColourSpaceProblem;
import com.oat.explorer.gui.panels.MasterPanel;
import com.oat.explorer.gui.plot.GenericProblemPlot;

/**
 * Description: 
 *  
 * Date: 10/01/2008<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class TransmissionDomain extends Domain
{
	@Override
	public MasterPanel getExplorerPanel()
	{
		return new TransmissionMasterPanel(this);
	}

	@Override
	public String getHumanReadableName()
	{
		return "Transmission";
	}

	@Override
	public String getShortName()
	{
		return "trans";
	}

	@Override
	public Algorithm[] loadAlgorithmList() throws Exception
	{
		return new Algorithm[]		                  
		                     {
		      // minimal population
			  new MinimalHostPopulationAlgorithm(),
			  // others
			  new HostMinimalInfection(),
			  new HostMinimalPoint(),
			  new HostMinimalRandom(),
			  
			  // pathogen dynamics
			  new PathogenDynamics(),
			  // pairing
			  new PathogenDynamicsPairingInfection(),
			  new PathogenDynamicsPairingPoint(),
			  new PathogenDynamicsPairingRandom(),			  
			  // spatial
			  new PathogenDynamicsSpatialInfection(),
			  new PathogenDynamicsSpatialPoint(),
			  new PathogenDynamicsSpatialRandom(),
			  
			  // blind vaccination
			  new BlindVaccination(),
			  // experiment
			  new BlindVaccinationInfection(),
			  new BlindVaccinationPoint(),
			  new BlindVaccinationRandom(),
			  
			  // selective vaccination
			  new SelectiveVaccination(),
			  // exp
			  new SelectiveVaccinationInfection(),
			  new SelectiveVaccinationPoint(),
			  new SelectiveVaccinationRandom(),

		                     };
	}

	@Override
	public Problem[] loadProblemList() throws Exception
	{
		return new Problem[]
		                   {
				new InfectionColourSpaceProblem(),
				new ICSP_10(),
				new ICSP_1(),
				
		                   };
	}

	@Override
	public GenericProblemPlot prepareProblemPlot()
	{
		return null;
	}
	
	
	@Override
	public LinkedList<StopCondition> loadDomainStopConditions()
	{
		LinkedList<StopCondition> list = super.loadDomainStopConditions();
		list.add(new FoundOptimaStopCondition());		
		list.add(new FoundOptimaOrMaxEpochs());
		Collections.sort(list);		
		return list;
	}
	
	@Override
	public LinkedList<RunProbe> loadDomainRunProbes()
	{
		LinkedList<RunProbe> list = super.loadDomainRunProbes();		
		
		// cell set based probes
		list.add(new SolutionDiversity());
		list.add(new OptimaDiversity());
		list.add(new RMSEEuclidean());
		list.add(new RMSEHamming());
		list.add(new AEHamming());
		list.add(new AEEuclidean());
		
		// host probes
		list.add(new AverageExposuresPerEpoch());
		list.add(new AverageHostDiversity());
		list.add(new AverageHostError());
		list.add(new InterHostDiversity());
		
		Collections.sort(list);		
		return list;
	}
}
