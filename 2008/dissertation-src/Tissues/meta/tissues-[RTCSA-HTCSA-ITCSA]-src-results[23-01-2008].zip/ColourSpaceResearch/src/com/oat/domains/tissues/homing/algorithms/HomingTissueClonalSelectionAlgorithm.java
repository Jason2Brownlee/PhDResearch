/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006, 2007  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.tissues.homing.algorithms;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Random;

import com.oat.Algorithm;
import com.oat.EpochAlgorithm;
import com.oat.InvalidConfigurationException;
import com.oat.Problem;
import com.oat.domains.cells.network.algorithms.Tissue;
import com.oat.domains.cells.opt.Cell;
import com.oat.domains.cells.opt.problems.Optimisation;
import com.oat.domains.cells.patrec.CellSet;
import com.oat.domains.tissues.ExposureListener;
import com.oat.domains.tissues.InfectionProblem;
import com.oat.domains.tissues.TissueAlgorithm;
import com.oat.domains.tissues.homing.HomingCell;
import com.oat.domains.tissues.recirulation.algorithms.TER;
import com.oat.utils.EvolutionUtils;

/**
 * Description: Specialization of RTCSA
 * - Homing cells and Homing RCCSA
 * - preferential migration based on preferential tissue id
 *  
 * Date: 26/11/2007<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class HomingTissueClonalSelectionAlgorithm extends EpochAlgorithm<CellSet> 
	implements TissueAlgorithm
{		
	// config
	protected int numTissues = 10;
	protected long seed = 1;
	protected int numCells = 50;
	protected int selectionSize = 1;
	protected int cloneSize = 5;
	protected int probabilistExposureDurationLength = 15;
	protected TER exposureMode = TER.Probabilistic;
	// new config
	protected int migrationSize = 5;
	protected double preferenceProbability = 0.80; // 80% chance of staying	
	protected int numCellsToImprint = 1;
	
	// general state
	protected HomingRCCSA [] tissues;
	protected Random rand;	
	protected LinkedList<ExposureListener> listeners;
	// probabilistic exposure state
	protected double [][] histogram;
	protected int currentDurationLength;
	protected int [] currentSelection;	
	
	
	public HomingTissueClonalSelectionAlgorithm()
	{
		listeners = new LinkedList<ExposureListener>();
	}			
	
	public void trafficLymphocytes(InfectionProblem p)
	{
		if(migrationSize<0)
		{
			return;
		}
		
		LinkedList<HomingCell> [] migrants = new LinkedList[tissues.length];
		
		// select migrants
		for (int i = 0; i < tissues.length; i++)
		{
			migrants[i] = selectMigrants(tissues[i].getRepertoire(), tissues[i].getTissueId());
		}
		
		// insert migrants
		for (int i = 0; i < tissues.length; i++)
		{
			LinkedList<HomingCell> target = tissues[i].getRepertoire();
			LinkedList<HomingCell> source = null;
			
			if(i == 0)
			{
				source = migrants[migrants.length-1];
			}
			else if(i == migrants.length-1)
			{
				source = migrants[0];
			}
			else
			{
				source = migrants[i + 1];
			}
		
			target.addAll(source);
		}
	}
	
	protected LinkedList<HomingCell> selectMigrants(LinkedList<HomingCell> repertoire, int repertoireId)
	{
		LinkedList<HomingCell> migrants = new LinkedList<HomingCell>();
		
		// support for differential migration based on preference
		
		while(migrants.size() < migrationSize)
		{
			// select a random cell
			int selectionIndex = rand.nextInt(repertoire.size());
			HomingCell selectedCell = repertoire.get(selectionIndex);
			boolean migrate = false;
			// check for no preference
			if(selectedCell.getPreferredRepertoireNumber() == HomingCell.NO_PREFERENCE)
			{
				migrate = true; // no pref
			}
			// check for no expressed preference
			else if(selectedCell.getPreferredRepertoireNumber() != repertoireId)
			{
				migrate = true; // does not apply
			}
			else if(rand.nextDouble() > preferenceProbability)
			{
				// preference is expressed but ignored
				migrate = true; // does not apply
			}
			// else preference is asserted
			
			
			// do migration
			if(migrate)
			{
				// remove from repertoire and store in buffer
				migrants.add(repertoire.remove(selectionIndex));
			}
		}
		
		return migrants;
	}
	
	
	
	protected void initialiseProbabilisticExposures(int numInfections)
	{
		currentDurationLength = 0;
		histogram = new double[numInfections][numTissues];		 
		currentSelection = new int[numInfections];
		Arrays.fill(currentSelection, -1);
	}

	public Cell repertoireExposureInfection(InfectionProblem p, int pattNo)
	{
		// check for a reset
		if(currentSelection[pattNo] == -1 || 
				currentDurationLength >= probabilistExposureDurationLength)
		{
			// make selection
			int selection = EvolutionUtils.biasedRouletteWheelSelection(histogram[pattNo], rand);
			// store selection
			currentSelection[pattNo] = selection;
			// reset count
			currentDurationLength = 0;
			// increment the frequency			
			histogram[pattNo][currentSelection[pattNo]]++;			
		}				
		
		// perform an exposure
		currentDurationLength++;		
		// simple one-to-one exposure scheme
		return doSpecificExposure(currentSelection[pattNo], p, pattNo);
	}

	
	public Cell repertoireExposureRandom(InfectionProblem p, int infectionNumber)
	{
		// select repertoire (wraps around the number of repertories)
		int repNo = rand.nextInt(tissues.length);
		// simple one-to-one exposure scheme
		return doSpecificExposure(repNo, p, infectionNumber);
	}
	
	public Cell repertoireExposurePoint(InfectionProblem p, int infectionNumber)
	{
		// always the same
		int repNo = 1;		
		// simple one-to-one exposure scheme
		return doSpecificExposure(repNo, p, infectionNumber);
	}
	
	public Cell repertoireExposureAsymmetric(InfectionProblem p, int infectionNumber)
	{
		// select repertoire (wraps around the number of repertories)
		int repNo = infectionNumber % numTissues;				
		// trigger exposure event
		return doSpecificExposure(repNo, p, infectionNumber);
	}
	
	public Cell repertoireExposureSymmetric(InfectionProblem p, int infectionNumber)
	{
		LinkedList<Cell> repertoireBMUs = new LinkedList<Cell>();
		
		// expose to each repertoire
		for (int i = 0; i < tissues.length; i++)
		{
			// exposure
			Cell bmu = doSpecificExposure(i, p, infectionNumber);
			// record
			repertoireBMUs.add(bmu);
		}
		
		Collections.shuffle(repertoireBMUs, rand); // random tie handling
		Collections.sort(repertoireBMUs); // order by affinity
		return repertoireBMUs.getFirst(); // return the best
	}
	
	
	protected Cell doSpecificExposure(int tissueNumber, InfectionProblem p, int infectionNumber)
	{
		// retrieve host
		HomingRCCSA tissue = tissues[tissueNumber];
		// exposure
		Cell bmu = tissue.exposure(p, infectionNumber);
		// trigger event
		triggerExposureEvent(tissueNumber, tissue, infectionNumber, p.getInfections()[infectionNumber]);
		return bmu;
	}
	
	
	
	public Cell repertoireExposure(InfectionProblem p, int infectionNumber)
	{
		Cell bmu = null;
		
		switch(exposureMode)
		{			
		case Asymmetric:
			bmu = repertoireExposureAsymmetric(p, infectionNumber);
			break;
		
		case Symmetric:
			bmu = repertoireExposureSymmetric(p, infectionNumber);
			break;
			
		case Random:
			bmu = repertoireExposureRandom(p, infectionNumber);
			break;
			
		case Point:
			bmu = repertoireExposurePoint(p, infectionNumber);
			break;
			
		case Probabilistic: 
			bmu = repertoireExposureInfection(p, infectionNumber);
			break;
			
		default:
			throw new RuntimeException("Invalid exposure mode: " + exposureMode);
		}
		
		return bmu;
	}

	
	@Override
	protected LinkedList<CellSet> internalInitialiseBeforeRun(Problem problem)
	{
		rand = new Random(seed);
		// prepare exposure things
		InfectionProblem infection = (InfectionProblem) problem;
		initialiseProbabilisticExposures(infection.getNumInfections());
		// prepare tissues
		tissues = prepareTissues(problem);		
		return null;
	}	
	
	protected HomingRCCSA[] prepareTissues(Problem problem)
	{
		HomingRCCSA [] ccsas = new HomingRCCSA[numTissues];
		for (int i = 0; i < ccsas.length; i++)
		{
			// create
			ccsas[i] = new HomingRCCSA(i+1);
			// configure
			ccsas[i].setSeed(rand.nextLong());
			ccsas[i].setNumCells(numCells);
			ccsas[i].setSelectionSize(selectionSize);
			ccsas[i].setCloningSize(cloneSize);
			ccsas[i].setNumCellsToImprint(numCellsToImprint);
			// initialise
			ccsas[i].internalInitialiseBeforeRun(problem);
		}
		
		return ccsas;
	}
	
	
	
	public CellSet systemExposure(InfectionProblem p)
	{
		int numSubProblems = p.getNumInfections();		
		Cell [] bmus = new Cell[numSubProblems];
		// process each sub problem
		for (int i = 0; i < numSubProblems; i++)
		{
			bmus[i] = repertoireExposure(p, i);
		}		
		return new CellSet(bmus);
	}
	
	
	@Override
	protected LinkedList<CellSet> internalExecuteEpoch(Problem problem, LinkedList<CellSet> population)
	{
		InfectionProblem p = (InfectionProblem) problem;
		// perform exposure
		LinkedList<CellSet> nextgen = new LinkedList<CellSet>();
		CellSet set = systemExposure(p);
		nextgen.add(set);
		
		// traffic cells
		trafficLymphocytes(p);
		
		return nextgen;
	}

	
	public void registerExposureListener(ExposureListener aListener)
	{
		listeners.add(aListener);
	}
	
	protected void triggerExposureEvent(int repNo, Algorithm rep, int patNo, Optimisation pat)
	{
		for(ExposureListener list : listeners)
		{
			list.exposure(repNo, rep, patNo, pat);
		}
	}
	
	public boolean removeExposureListener(ExposureListener aListener)
	{
		return listeners.remove(aListener);
	}


	@Override
	protected void internalPostEvaluation(Problem problem, LinkedList<CellSet> oldPopulation, LinkedList<CellSet> newPopulation)
	{
		for (int i = 0; i < tissues.length; i++)
		{
			tissues[i].internalPostEvaluation(problem, oldPopulation, newPopulation);
		}
	}

	@Override
	public void validateConfiguration() 
		throws InvalidConfigurationException
	{
		// sub repertoire configuration
		if(numCells<=0)
		{
			throw new InvalidConfigurationException("Repertoire size must be > 0.");
		}
		if(selectionSize>numCells)
		{
			throw new InvalidConfigurationException("Selection size must be less than the repertoire size.");
		}
		if(selectionSize<=0)
		{
			throw new InvalidConfigurationException("Selection size must be > 0.");
		}
		if(cloneSize<=0)
		{
			throw new InvalidConfigurationException("Clone size must be > 0.");
		}
		if(cloneSize>numCells)
		{
			throw new InvalidConfigurationException("Clone size must be less than the repertoire size.");
		}
		
		// master repertoire configuration
		if(numTissues<=0)
		{
			throw new InvalidConfigurationException("Number of tissues must be > 0.");
		}
		
		if(migrationSize<0)
		{
			throw new InvalidConfigurationException("Migration size must be > 0.");
		}
		if(migrationSize>numCells)
		{
			throw new InvalidConfigurationException("Migration size must be < repertoire size.");
		}
		// cannot validate sub-repertoires because they are not created yet
	}

	

	

	@Override
	public String getName()
	{
		return "Homing Tissue Clonal Selection Algorithm (HTCSA)";
	}

	public long getSeed()
	{
		return seed;
	}

	public void setSeed(long seed)
	{
		this.seed = seed;
	}

	

	public int getSelectionSize()
	{
		return selectionSize;
	}

	public void setSelectionSize(int selectionSize)
	{
		this.selectionSize = selectionSize;
	}

	public int getCloneSize()
	{
		return cloneSize;
	}

	public void setCloneSize(int cloneSize)
	{
		this.cloneSize = cloneSize;
	}

	public Tissue[] getTissues()
	{
		return tissues;
	}
	
	public TER getExposureMode()
	{
		return exposureMode;
	}

	public void setExposureMode(TER exposureMode)
	{
		this.exposureMode = exposureMode;
	}

	public int getProbabilistExposureDurationLength()
	{
		return probabilistExposureDurationLength;
	}

	public void setProbabilistExposureDurationLength(
			int probabilistExposureDurationLength)
	{
		this.probabilistExposureDurationLength = probabilistExposureDurationLength;
	}
	
	public int getNumTissues()
	{
		return numTissues;
	}

	public void setNumTissues(int numTissues)
	{
		this.numTissues = numTissues;
	}

	public int getNumCells()
	{
		return numCells;
	}

	public void setNumCells(int numCells)
	{
		this.numCells = numCells;
	}

	public int getMigrationSize()
	{
		return migrationSize;
	}

	public void setMigrationSize(int migrationSize)
	{
		this.migrationSize = migrationSize;
	}

	public double getPreferenceProbability()
	{
		return preferenceProbability;
	}

	public void setPreferenceProbability(double preferenceProbability)
	{
		this.preferenceProbability = preferenceProbability;
	}

	public int getNumCellsToImprint()
	{
		return numCellsToImprint;
	}

	public void setNumCellsToImprint(int numCellsToImprint)
	{
		this.numCellsToImprint = numCellsToImprint;
	}	
}
