/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006, 2007  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.hosts.population.transmission.experiments;

import java.util.LinkedList;

import com.oat.Domain;
import com.oat.RunProbe;
import com.oat.StopCondition;
import com.oat.domains.cells.mediatedpattrec.probes.AEEuclidean;
import com.oat.domains.cells.opt.stopcondition.FoundOptimaOrMaxEpochs;
import com.oat.domains.hosts.population.transmission.TransmissionDomain;
import com.oat.domains.hosts.population.transmission.algorithms.minimal.HostMinimalInfection;
import com.oat.domains.hosts.population.transmission.algorithms.minimal.HostMinimalPoint;
import com.oat.domains.hosts.population.transmission.algorithms.minimal.HostMinimalRandom;
import com.oat.domains.hosts.population.transmission.algorithms.vaccination.blind.BlindVaccinationInfection;
import com.oat.domains.hosts.population.transmission.algorithms.vaccination.blind.BlindVaccinationPoint;
import com.oat.domains.hosts.population.transmission.algorithms.vaccination.blind.BlindVaccinationRandom;
import com.oat.domains.hosts.population.transmission.algorithms.vaccination.selective.SelectiveVaccinationInfection;
import com.oat.domains.hosts.population.transmission.algorithms.vaccination.selective.SelectiveVaccinationPoint;
import com.oat.domains.hosts.population.transmission.algorithms.vaccination.selective.SelectiveVaccinationRandom;
import com.oat.domains.hosts.population.transmission.probes.AverageHostDiversity;
import com.oat.domains.hosts.population.transmission.probes.AverageHostError;
import com.oat.domains.hosts.population.transmission.probes.InterHostDiversity;
import com.oat.domains.tissues.recirulation.problems.ICSP_1;
import com.oat.domains.tissues.recirulation.problems.ICSP_10;
import com.oat.experimenter.ExperimentalRun;
import com.oat.experimenter.ExperimentalRunMatrix;
import com.oat.experimenter.TemplateExperiment;

/**
 * Description: 
 *  
 * Date: 10/01/2008<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class Study2VaccinationDynamics extends TemplateExperiment
{
	public static void main(String[] args)
	{
		new Study2VaccinationDynamics().run();
	}

	@Override
	public LinkedList<ExperimentalRun> createRunList()
	{
		ExperimentalRunMatrix matrix = new ExperimentalRunMatrix();
		// 30 repats
		matrix.setRepeats(30);
		// problems
		matrix.addProblem(new ICSP_10());
		// standard
		matrix.addAlgorithm(new HostMinimalInfection());
		matrix.addAlgorithm(new HostMinimalPoint());
		matrix.addAlgorithm(new HostMinimalRandom());
		// vaccination dynamics blind
		matrix.addAlgorithm(new BlindVaccinationInfection());
		matrix.addAlgorithm(new BlindVaccinationPoint());
		matrix.addAlgorithm(new BlindVaccinationRandom());
		// vaccination dynamics selective		
		matrix.addAlgorithm(new SelectiveVaccinationInfection());
		matrix.addAlgorithm(new SelectiveVaccinationPoint());
		matrix.addAlgorithm(new SelectiveVaccinationRandom());
		
		return matrix.toRunList();
	}

	@Override
	public Domain getDomain()
	{
		return new TransmissionDomain();
	}

	@Override
	public String getExperimentDescription()
	{
		return "Assess various vaccination dynamics transmission schemes.";
	}

	@Override
	public String getExperimentName()
	{
		return "HostTrans2";
	}

	@Override
	public StopCondition getStopCondition()
	{
		return new FoundOptimaOrMaxEpochs(1000);
	}
	
	@Override
	public LinkedList<RunProbe> getReportingStatistics()
	{
		// select statistics to report on
		LinkedList<RunProbe> reportStats = new LinkedList<RunProbe>();
		// system level
		reportStats.add(new InterHostDiversity());
		reportStats.add(new AEEuclidean());
		// host level
		reportStats.add(new AverageHostDiversity());
		reportStats.add(new AverageHostError());	
		
		return reportStats;
	}
	
	@Override
	public boolean performAnalysys()
	{
		return true;
	}
}
