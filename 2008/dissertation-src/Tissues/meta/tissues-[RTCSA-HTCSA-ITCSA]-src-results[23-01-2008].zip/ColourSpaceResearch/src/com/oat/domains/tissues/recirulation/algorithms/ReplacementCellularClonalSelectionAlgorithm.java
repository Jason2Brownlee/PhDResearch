/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006, 2007  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.tissues.recirulation.algorithms;

import java.util.LinkedList;
import java.util.Random;

import com.oat.EpochAlgorithm;
import com.oat.InvalidConfigurationException;
import com.oat.Problem;
import com.oat.domains.cells.mediatedpattrec.CellUtils;
import com.oat.domains.cells.network.algorithms.Tissue;
import com.oat.domains.cells.opt.Cell;
import com.oat.domains.cells.patrec.CellSet;
import com.oat.domains.tissues.InfectionProblem;

/**
 * Description: 
 *  
 * Date: 26/11/2007<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class ReplacementCellularClonalSelectionAlgorithm extends EpochAlgorithm<CellSet>
	implements Tissue<Cell>
{
	// config
	protected long seed = 1;
	protected int numCells = 100;
	protected int selectionSize = 1;
	protected int cloningSize = 5;		
	
	// data
	protected Random rand;
	protected LinkedList<Cell> cells;
	
	
	@Override
	protected LinkedList<CellSet> internalInitialiseBeforeRun(Problem problem)
	{
		rand = new Random(seed);			
		cells = CellUtils.getRandomRepertoire(rand, numCells);		
		// no initial population
		return null;
	}	
	
	@Override
	public LinkedList<Cell> getRepertoire()
	{
		return cells;
	}
	
	protected void assessRepertoireAgainstAntigen(InfectionProblem p, int pattNo, LinkedList<Cell> repertoire)
	{
		for(Cell c : repertoire)
		{
			p.costCell(c, pattNo);
		}
	}	
		
	public void replaceIntoRepertoire(LinkedList<Cell> progeny, LinkedList<Cell> repertoire)
	{
		for(Cell c : progeny)
		{
			// Euclidean similarity tournament for competition
			Cell similar = CellUtils.getMostSimilarEuclideanWithExclusion(c, repertoire, progeny);
			// fitness tournament for resources
			if(c.getScore() < similar.getScore())
			{
				repertoire.remove(similar);
				repertoire.add(c);
			}
		}
	}
	
	public Cell exposure(InfectionProblem p, int pattNo)
	{		
		// assess repertoire
		assessRepertoireAgainstAntigen(p, pattNo, cells);
		// select the activated set
		LinkedList<Cell> selected = CellUtils.selectActivatedSet(cells, rand, selectionSize);		
		// cloning and mutation
		LinkedList<Cell> clones = CellUtils.cloningAndMutation(selected, cloningSize, rand);
		// assess the clones against the antigen
		assessRepertoireAgainstAntigen(p, pattNo, clones);		
		// compete for position within the repertoire
		replaceIntoRepertoire(clones, cells);
		// return the bmu
		return selected.getFirst();
	}	

	@Override
	protected LinkedList<CellSet> internalExecuteEpoch(Problem problem, LinkedList<CellSet> cp)
	{
		InfectionProblem p = (InfectionProblem) problem;
		int numSubProblems = p.getNumInfections();		
		Cell [] bmus = new Cell[numSubProblems];
		
		// process each sub problem
		for (int i = 0; i < numSubProblems; i++)
		{
			bmus[i] = exposure(p, i);
		}
		
		// create a cell set
		LinkedList<CellSet> nextgen = new LinkedList<CellSet>();
		nextgen.add(new CellSet(bmus));
		return nextgen;
	}

	@Override
	protected void internalPostEvaluation(Problem problem, LinkedList<CellSet> oldPopulation, LinkedList<CellSet> newPopulation)
	{}

	
	@Override
	public void validateConfiguration() 
		throws InvalidConfigurationException
	{
		if(numCells<=0)
		{
			throw new InvalidConfigurationException("Repertoire size must be > 0.");
		}
		if(selectionSize>numCells)
		{
			throw new InvalidConfigurationException("Selection size must be less than the repertoire size.");
		}
		if(selectionSize<=0)
		{
			throw new InvalidConfigurationException("Selection size must be > 0.");
		}
		if(cloningSize<=0)
		{
			throw new InvalidConfigurationException("Clone size must be > 0.");
		}
		if(cloningSize>numCells)
		{
			throw new InvalidConfigurationException("Clone size must be less than the repertoire size.");
		}
	}

	@Override
	public String getName()
	{
		return "Replacement Cellular Clonal Selection Algorithm (RCCSA)";
	}

	public long getSeed()
	{
		return seed;
	}

	public void setSeed(long seed)
	{
		this.seed = seed;
	}

	public int getNumCells()
	{
		return numCells;
	}

	public void setNumCells(int numCells)
	{
		this.numCells = numCells;
	}

	public int getSelectionSize()
	{
		return selectionSize;
	}

	public void setSelectionSize(int selectionSize)
	{
		this.selectionSize = selectionSize;
	}

	public int getCloningSize()
	{
		return cloningSize;
	}

	public void setCloningSize(int cloningSize)
	{
		this.cloningSize = cloningSize;
	}

	public Random getRand()
	{
		return rand;
	}	
}

