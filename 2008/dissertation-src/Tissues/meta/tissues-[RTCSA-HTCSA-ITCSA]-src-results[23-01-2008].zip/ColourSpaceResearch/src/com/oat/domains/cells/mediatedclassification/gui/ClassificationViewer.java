/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006, 2007  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.cells.mediatedclassification.gui;

import java.awt.Color;
import java.awt.Graphics;
import java.util.LinkedList;

import com.oat.AlgorithmEpochCompleteListener;
import com.oat.Problem;
import com.oat.Solution;
import com.oat.domains.cells.mediatedclassification.ClassificationSolution;
import com.oat.domains.cells.mediatedclassification.problems.PatternClassification;
import com.oat.domains.cells.opt.Cell;
import com.oat.domains.cells.opt.problems.Optimisation;
import com.oat.explorer.gui.ClearEventListener;
import com.oat.explorer.gui.plot.GenericProblemPlot;

/**
 * Description: 
 *  
 * Date: 05/11/2007<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class ClassificationViewer extends GenericProblemPlot
	implements AlgorithmEpochCompleteListener, ClearEventListener
{	
	protected PatternClassification problem;	
	protected LinkedList<Color> problemColours;
	protected LinkedList<Color> problemClasses;
	protected LinkedList<Color> popClasses;
	
	
	public ClassificationViewer()
	{
		setName("Population View");
		problemColours = new LinkedList<Color>();
		problemClasses = new LinkedList<Color>();
		popClasses = new LinkedList<Color>();
	}
	
	@Override
	public void problemChangedEvent(Problem p)
	{
		synchronized(this)
		{			
			clear();
		
			if(p instanceof PatternClassification)
			{
				problem = (PatternClassification) p;
			}
		}
		
		repaint();
	}

	@Override
	public void clear()
	{
		synchronized(this)
		{
			problemColours.clear();
			problemClasses.clear();
			popClasses.clear();
		}
	}

	@Override
	public <T extends Solution> void epochCompleteEvent(Problem p, LinkedList<T> currentPop)
	{		
		synchronized(this)
		{
			if(problem == null)
			{
				return;
			}			
			// lazy, so we know the problem has been initialised
			if(problemColours.isEmpty())
			{
				Optimisation [] subprobs = problem.getSubproblems();
				for (int i = 0; i < subprobs.length; i++)
				{
					// get problem colours
					double [] optima = subprobs[i].getGlobalOptima()[0].getCoordinate();
					problemColours.add(vectorToColor(optima));
					// get problem classifications
					problemClasses.add(problem.getClassificationColourForPattern(i));
				}
			}
			
			// convert the current population to colours
			popClasses.clear();			
			// expect a population of size 1
			if(currentPop.size() == 1)
			{
				int [] classifications = ((ClassificationSolution)currentPop.getFirst()).getClassifications();				
				for (int classId : classifications)
				{
					Color c = problem.getClassificationColourForClassId(classId);
					popClasses.add(c);					
				}
			}
		}		
		
		repaint();
	}	
	
	protected Color vectorToColor(double [] v)
	{		
		return new Color((float)v[0], (float)v[1], (float)v[2]);
	}

	@Override
	protected void paintComponent(Graphics g)
	{
		synchronized(this)
		{
			if(problem == null)
			{
				super.plotUnavailable(g);
				return;
			}
			
			// clear
			g.setColor(Color.WHITE);
			g.fillRect(0,0,getWidth(),getHeight());
			
			// calculate things
			int width = (int) Math.floor((double)getWidth() / 2.0);
			int height = (int) Math.floor((double)getHeight() / problemColours.size()); 
			
			// draw the population colours
			for (int i = 0; i < popClasses.size(); i++)
			{
				drawColor(g, popClasses.get(i), 0, i*height, width, height);
			}
			
			int wh = width/2;
			int hh = height/2;
			int hhh = hh/2;
			
			// draw the problem patterns
			for (int i = 0; i < problemColours.size(); i++)
			{
				drawColor(g, problemColours.get(i), width, i*height, width, height);
				// draw the classification
				drawColor(g, problemClasses.get(i), width, i*height+hhh, wh, hh);
			}		
		}
	}
	
	
	public void drawColor(Graphics g, Color c, int x, int y, int width, int height)
	{
		g.setColor(c);
		g.fillRect(x, y, width, height);				
		g.setColor(Color.BLACK);
		g.drawRect(x, y, width, height);
	}	
}
