/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006, 2007  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.cells.mediatedpattrec;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;

import com.oat.Algorithm;
import com.oat.Domain;
import com.oat.Problem;
import com.oat.RunProbe;
import com.oat.StopCondition;
import com.oat.domains.cells.mediatedpattrec.algorithms.ClassicalReplacement;
import com.oat.domains.cells.mediatedpattrec.algorithms.FixingReplacement;
import com.oat.domains.cells.mediatedpattrec.algorithms.bottomup.cells.manytomany.BottomUpMappingManyToMany;
import com.oat.domains.cells.mediatedpattrec.algorithms.bottomup.cells.onetoone.BottomUpEuclidean;
import com.oat.domains.cells.mediatedpattrec.algorithms.bottomup.cells.onetoone.BottomUpEuclideanForced;
import com.oat.domains.cells.mediatedpattrec.algorithms.bottomup.cells.onetoone.BottomUpMappingEuclidean;
import com.oat.domains.cells.mediatedpattrec.algorithms.bottomup.cells.onetoone.BottomUpMappingEuclideanForced;
import com.oat.domains.cells.mediatedpattrec.algorithms.bottomup.cells.onetoone.BottomUpMappingHammingForced;
import com.oat.domains.cells.mediatedpattrec.algorithms.topdown.cells.manytomany.TopDownManyToManyCells;
import com.oat.domains.cells.mediatedpattrec.algorithms.topdown.cells.manytoone.TopDownManyToOneCellsEuclidean;
import com.oat.domains.cells.mediatedpattrec.algorithms.topdown.cells.manytoone.TopDownManyToOneCellsVoting;
import com.oat.domains.cells.mediatedpattrec.algorithms.topdown.cells.onetomany.TopDownOneToManyCells;
import com.oat.domains.cells.mediatedpattrec.algorithms.topdown.cells.onetoone.TopDownEuclidean;
import com.oat.domains.cells.mediatedpattrec.algorithms.topdown.cells.onetoone.TopDownHamming;
import com.oat.domains.cells.mediatedpattrec.algorithms.topdown.cells.onetoone.TopDownHammingWithEuclideanCost;
import com.oat.domains.cells.mediatedpattrec.algorithms.topdown.components.TopDownManyToOneComponentsEuclidean;
import com.oat.domains.cells.mediatedpattrec.algorithms.topdown.components.TopDownManyToOneComponentsVoting;
import com.oat.domains.cells.mediatedpattrec.algorithms.topdown.components.TopDownOneToManyComponents;
import com.oat.domains.cells.mediatedpattrec.algorithms.topdown.substring.TopDownManyToOneSubstringsDistance;
import com.oat.domains.cells.mediatedpattrec.algorithms.topdown.substring.TopDownManyToOneSubstringsVoting;
import com.oat.domains.cells.mediatedpattrec.algorithms.topdown.substring.TopDownRandom;
import com.oat.domains.cells.mediatedpattrec.algorithms.topdown.substring.TopDownSubstring;
import com.oat.domains.cells.mediatedpattrec.gui.MediatedPatternRecognitionMasterPanel;
import com.oat.domains.cells.mediatedpattrec.probes.AEEuclidean;
import com.oat.domains.cells.mediatedpattrec.probes.AEHamming;
import com.oat.domains.cells.mediatedpattrec.probes.BCellDiversity;
import com.oat.domains.cells.mediatedpattrec.probes.OptimaDiversity;
import com.oat.domains.cells.mediatedpattrec.probes.RMSEEuclidean;
import com.oat.domains.cells.mediatedpattrec.probes.RMSEHamming;
import com.oat.domains.cells.mediatedpattrec.probes.SolutionDiversity;
import com.oat.domains.cells.mediatedpattrec.probes.TCellDiversity;
import com.oat.domains.cells.mediatedpattrec.problems.MediatedPatternRecognition;
import com.oat.domains.cells.opt.stopcondition.FoundOptimaOrMaxEpochs;
import com.oat.domains.cells.opt.stopcondition.FoundOptimaStopCondition;
import com.oat.explorer.gui.panels.MasterPanel;
import com.oat.explorer.gui.plot.GenericProblemPlot;

/**
 * Description: 
 *  
 * Date: 06/11/2007<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class MediatedPatternRecognitionDomain extends Domain
{
	@Override
	public MasterPanel getExplorerPanel()
	{
		return new MediatedPatternRecognitionMasterPanel(this);
	}

	@Override
	public String getHumanReadableName()
	{
		return "Mediated Pattern Recognition";
	}

	@Override
	public String getShortName()
	{
		return "cmpr";
	}

	@Override
	public Algorithm[] loadAlgorithmList() throws Exception
	{
		Algorithm [] a = new Algorithm[]
		                     {		
				// classical
				new ClassicalReplacement(),
				new FixingReplacement(),				
				// top-down 
				new TopDownEuclidean(),
				new TopDownHamming(),
				new TopDownHammingWithEuclideanCost(),
				new TopDownSubstring(),
				new TopDownRandom(),	
				new TopDownManyToOneCellsEuclidean(),
				new TopDownManyToOneCellsVoting(),
				new TopDownManyToOneComponentsEuclidean(),
				new TopDownManyToOneComponentsVoting(),		
				new TopDownManyToOneSubstringsDistance(),
				new TopDownManyToOneSubstringsVoting(),
				new TopDownManyToManyCells(),				
				new TopDownOneToManyCells(),
				new TopDownOneToManyComponents(),
				
				new BottomUpEuclidean(),
				new BottomUpEuclideanForced(),
				
				// others
				new BottomUpMappingEuclidean(),
				new BottomUpMappingEuclideanForced(),
				new BottomUpMappingHammingForced(),
				new BottomUpMappingManyToMany(),
				
				
				
		                     };
		
		Arrays.sort(a);
		return a;
	}

	@Override
	public Problem[] loadProblemList() throws Exception
	{
		return new Problem[]
		                   {
				new MediatedPatternRecognition()
		                   };
	}

	@Override
	public GenericProblemPlot prepareProblemPlot()
	{
		return null;
	}
	
	@Override
	public LinkedList<StopCondition> loadDomainStopConditions()
	{
		LinkedList<StopCondition> list = super.loadDomainStopConditions();
		list.add(new FoundOptimaStopCondition());		
		list.add(new FoundOptimaOrMaxEpochs());
		Collections.sort(list);		
		return list;
	}
	
	@Override
	public LinkedList<RunProbe> loadDomainRunProbes()
	{
		LinkedList<RunProbe> list = super.loadDomainRunProbes();		
		
		list.add(new SolutionDiversity());
		list.add(new BCellDiversity());
		list.add(new TCellDiversity());
		list.add(new OptimaDiversity());
		list.add(new RMSEEuclidean());
		list.add(new RMSEHamming());
		list.add(new AEHamming());
		list.add(new AEEuclidean());
		
		Collections.sort(list);		
		return list;
	}
}
