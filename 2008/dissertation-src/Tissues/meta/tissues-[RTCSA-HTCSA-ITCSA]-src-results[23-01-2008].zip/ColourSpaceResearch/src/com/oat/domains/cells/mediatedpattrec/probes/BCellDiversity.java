/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006, 2007  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.cells.mediatedpattrec.probes;

import java.util.LinkedList;

import com.oat.Algorithm;
import com.oat.InitialisationException;
import com.oat.Problem;
import com.oat.Solution;
import com.oat.domains.cells.mediatedpattrec.CellUtils;
import com.oat.domains.cells.mediatedpattrec.algorithms.MediatedClonalSelection;
import com.oat.domains.cells.opt.Cell;
import com.oat.domains.cells.patrec.CellSet;
import com.oat.domains.cells.spatial.algorithms.SpatialRepertoire;
import com.oat.probes.GenericEpochCompletedProbe;
import com.oat.utils.BitStringUtils;

/**
 * Description: 
 *  
 * Date: 10/11/2007<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class BCellDiversity extends GenericEpochCompletedProbe
{
	protected double diversity = Double.NaN;
	protected MediatedClonalSelection algorithm;

	@Override
	public Object getProbeObservation()
	{
		return new Double(diversity);
	}
	
	@Override
    public void initialiseBeforeRunInternal(Problem p, Algorithm a) throws InitialisationException
	{
		super.initialiseBeforeRunInternal(p, a);
		algorithm = null;
		if(a instanceof MediatedClonalSelection)
		{
			algorithm = (MediatedClonalSelection) a;
		}
	}
	

	@Override
	public void reset()
	{
		diversity = Double.NaN;
	}

	@Override
	public <T extends Solution> void epochCompleteEvent(Problem p, LinkedList<T> cp)
	{	
		LinkedList<Cell> bcells = algorithm.getBCells();
		
		if(bcells != null)
		{
			diversity = CellUtils.averageHammingDistance(bcells);
		}
	}

	@Override
	public String getName()
	{
		return "Diversity B-Cell";
	}
}
