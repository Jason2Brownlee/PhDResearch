/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006, 2007  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.cells.patrec.algorithms;

import java.util.Collections;
import java.util.LinkedList;
import java.util.Random;

import com.oat.EpochAlgorithm;
import com.oat.InvalidConfigurationException;
import com.oat.Problem;
import com.oat.domains.cells.opt.Cell;
import com.oat.domains.cells.patrec.CellSet;
import com.oat.domains.cells.patrec.problems.PatternRecognition;
import com.oat.utils.ArrayUtils;
import com.oat.utils.EvolutionUtils;
import com.oat.utils.RandomUtils;

/**
 * Description: Degenerate Composition
 *  
 * Date: 31/10/2007<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class DegenerateComposition extends EpochAlgorithm<CellSet>
{
	// config
	protected long seed = 1;
	protected int repertoireSize = 10; // *3
	protected int selectionSize = 1;
	protected int cloningSize = 10;
	protected double mutationRate = 1.0/64.0;
	
	// data
	protected Random rand;
	protected LinkedList<Cell>[] cells;
	
	
	@Override
	protected LinkedList<CellSet> internalInitialiseBeforeRun(Problem problem)
	{
		PatternRecognition p = (PatternRecognition) problem;
		
		rand = new Random(seed);		
		
		cells = new LinkedList[3];		
		for (int i = 0; i < cells.length; i++)
		{
			cells[i] = new LinkedList<Cell>();
			
			for (int j = 0; j < repertoireSize; j++)
			{
				boolean [] data = RandomUtils.randomBitString(rand, 64);
				Cell c = new Cell(data, i);
				cells[i].add(c);
			}
		}
		
		return null; // no initial population
	}	
	
	protected LinkedList<Cell> cloningAndMutation(LinkedList<Cell> selectedSet)
	{
		LinkedList<Cell> newPop = new LinkedList<Cell>();
		
		for(Cell current : selectedSet)
		{			
			for (int j = 0; j < cloningSize; j++)
			{
				// copy
				boolean [] cloneData = ArrayUtils.copyArray(current.getData());
				// mutate
				EvolutionUtils.binaryMutate(cloneData, rand, mutationRate);
				// create and store
				Cell clone = new Cell(cloneData, current.getGene());
				newPop.add(clone);
			}
		}
		
		return newPop;
	}
	
	protected LinkedList<Cell> evaluateAndSelect(PatternRecognition p, LinkedList<Cell> pop, int subProblemNumber)
	{
		// assess first
		for(Cell c : pop)
		{
			p.costSingleFeature(c, subProblemNumber);
		}
		
		// order by utility
		Collections.sort(pop);	
		
		LinkedList<Cell> selectedSet = new LinkedList<Cell>();		
		for (int i = 0; i < selectionSize; i++)
		{			
			// i know it is minimisation
			Cell current = pop.get(i);
			selectedSet.add(current);
		}
		
		return selectedSet;
	}	
	
	
	protected Cell createMasterCellFromDegenerateCells(Cell g1, Cell g2, Cell g3)
	{
		boolean [] b = new boolean[3*64];
		
		// 1
		int off = 0;
		System.arraycopy(g1.getData(), 0, b, 0, g1.getData().length);
		off += g1.getData().length;
		// 2
		System.arraycopy(g2.getData(), 0, b, off, g2.getData().length);
		off += g2.getData().length;
		// 3
		System.arraycopy(g3.getData(), 0, b, off, g3.getData().length);		
		off += g3.getData().length;
		
		if(off != b.length)
		{
			throw new RuntimeException("Error in master cell creation");
		}
		
		return new Cell(b);
	}

	@Override
	protected LinkedList<CellSet> internalExecuteEpoch(Problem problem, LinkedList<CellSet> currentPop)
	{
		PatternRecognition p = (PatternRecognition) problem;			
		int numSubProblems = p.getNumInfections();
		
		Cell [] bmus = new Cell[numSubProblems];
		LinkedList<Cell>[] newCells = new LinkedList[cells.length];
		for (int i = 0; i < newCells.length; i++)
		{
			newCells[i] = new LinkedList<Cell>();
		}			
		
		// process each sub problem
		for (int i = 0; i < numSubProblems; i++)
		{
			Cell [] subBmus = new Cell[3];
			
			// process each component for the current problem
			for (int j = 0; j < cells.length; j++)
			{
				// select the activated set
				LinkedList<Cell> selected = evaluateAndSelect(p, cells[j], i);
				// store the best matching unit
				subBmus[j] = selected.getFirst();
				// cloning and mutation
				LinkedList<Cell> clones = cloningAndMutation(selected);
				// selection on the clonal set
				clones = evaluateAndSelect(p, clones, i);
				// store
				newCells[j].addAll(clones);
			}
			
			// collate the sub-bmu's into a master bmu
			bmus[i] = createMasterCellFromDegenerateCells(subBmus[0], subBmus[1], subBmus[2]);
		}
		
		// replace the current repertoire
		cells = newCells;
		
		// create a cell set
		LinkedList<CellSet> nextgen = new LinkedList<CellSet>();
		nextgen.add(new CellSet(bmus));
		return nextgen;
	}

	@Override
	protected void internalPostEvaluation(Problem problem, LinkedList<CellSet> oldPopulation, LinkedList<CellSet> newPopulation)
	{}

	@Override
	public void validateConfiguration() throws InvalidConfigurationException
	{}

	@Override
	public String getName()
	{
		return "Degenerate Composition";
	}

	public long getSeed()
	{
		return seed;
	}

	public void setSeed(long seed)
	{
		this.seed = seed;
	}
}
