/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006, 2007  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.cells.mediatedpattrec.algorithms.topdown.substring;

import java.util.Collections;
import java.util.LinkedList;
import java.util.Random;

import com.oat.EpochAlgorithm;
import com.oat.InvalidConfigurationException;
import com.oat.Problem;
import com.oat.domains.cells.mediatedpattrec.CellUtils;
import com.oat.domains.cells.mediatedpattrec.algorithms.MediatedClonalSelection;
import com.oat.domains.cells.mediatedpattrec.problems.MediatedPatternRecognition;
import com.oat.domains.cells.opt.Cell;
import com.oat.domains.cells.opt.DegenerateCell;
import com.oat.domains.cells.patrec.CellSet;
import com.oat.utils.ArrayUtils;
import com.oat.utils.BitStringUtils;
import com.oat.utils.EvolutionUtils;
import com.oat.utils.RandomUtils;

/**
 * Description: 
 *  
 * Date: 08/11/2007<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class TopDownRandom extends EpochAlgorithm<CellSet>
	implements MediatedClonalSelection
{
	// config
	protected long seed = 1;
	
	protected int numBCells = 100;
	protected int numTCells = 100;
	
	protected int numBCellClones = 10;
	protected int numTCellClones = 10;		
	
	// data
	protected Random rand;
	protected LinkedList<DegenerateCell> bcells;
	protected LinkedList<DegenerateCell> tcells;
	
	
	@Override
	protected LinkedList<CellSet> internalInitialiseBeforeRun(Problem problem)
	{	
		rand = new Random(seed);		
		
		// bcells
		bcells = new LinkedList<DegenerateCell>();		
		for (int i = 0; i < numTCells; i++)
		{
			boolean [] data = RandomUtils.randomBitString(rand, 3, 64);
			boolean [] mask = RandomUtils.randomBitString(rand, 3, 64);
			DegenerateCell c = new DegenerateCell(data, mask);
			bcells.add(c);
		}
		
		// tcells
		tcells = new LinkedList<DegenerateCell>();		
		for (int i = 0; i < numTCells; i++)
		{
			boolean [] data = RandomUtils.randomBitString(rand, 3, 64);
			boolean [] mask = RandomUtils.randomBitString(rand, 3, 64);
			DegenerateCell c = new DegenerateCell(data, mask);
			tcells.add(c);
		}
		
		// no initial population
		return null;
	}	
	
	@Override
	public LinkedList<Cell> getBCells()
	{
		return null;
	}

	@Override
	public LinkedList<Cell> getTCells()
	{
		return null;
	}
	
	
	
	protected LinkedList<DegenerateCell> cloningAndMutation(DegenerateCell bmu, int numClones)
	{
		LinkedList<DegenerateCell> newPop = new LinkedList<DegenerateCell>();		
					
		for (int j = 0; j < numClones; j++)
		{
			// copy
			boolean [] cloneData = ArrayUtils.copyArray(bmu.getData());
			boolean [] cloneMask = ArrayUtils.copyArray(bmu.getMask());
			// mutate
			EvolutionUtils.binaryMutate(cloneData, rand, 1.0/cloneData.length);
			EvolutionUtils.binaryMutate(cloneMask, rand, 1.0/cloneMask.length);
			// store
			DegenerateCell clone = new DegenerateCell(cloneData, cloneMask);
			newPop.add(clone);
		}
		
		
		return newPop;
	}
	
	
	
	protected DegenerateCell evaluateAndSelectTCell(DegenerateCell bcell, LinkedList<DegenerateCell> tCells)
	{		
		// assess first
		evaluateTCells(bcell, tCells);		
		// random tie handling
		Collections.shuffle(tCells);
		// order by utility
		Collections.sort(tCells);	
		return tCells.getFirst();
	}
	
	protected void evaluateTCells(DegenerateCell bcell, LinkedList<DegenerateCell> tCells)
	{	
		boolean [] m1 = bcell.getMask();
		
		for(DegenerateCell c : tCells)
		{			
			double d = BitStringUtils.hammingDistance(m1, c.getMask());
			c.evaluated(d);
		}
	}
		
	
	
	
	protected DegenerateCell evaluateAndSelectBCell(
			MediatedPatternRecognition p, 
			LinkedList<DegenerateCell> pop, 
			int subProblemNumber)
	{
		// assess first
		evaluateBCells(p, pop, subProblemNumber);		
		// random tie handling
		Collections.shuffle(pop);
		// order by utility
		Collections.sort(pop);	
		return pop.getFirst();
	}
	
	
	protected void evaluateBCells(MediatedPatternRecognition p, LinkedList<DegenerateCell> bcells, int subProblemNumber)
	{
		for(DegenerateCell c : bcells)
		{
			p.costCell(c, subProblemNumber);
		}
	}
	
	
	protected Cell exposure(MediatedPatternRecognition p, int patternNo)
	{		
		// activate b cell
		DegenerateCell activatedBCell = evaluateAndSelectBCell(p, bcells, patternNo);
		// activate t cell
		DegenerateCell bmu = evaluateAndSelectTCell(activatedBCell, tcells);		
		// back propagate bcells
		backPropagateBCells(p, patternNo, activatedBCell);		
		// back propagate tcells
		backPropagateTCells(activatedBCell, bmu);		
		
		Cell c = new Cell(bmu.getData());		
		return c;		
	}
	
	protected void backPropagateBCells(MediatedPatternRecognition p, int patternNo, DegenerateCell bcell)
	{
		// clone b cell
		LinkedList<DegenerateCell> bCellClones = cloningAndMutation(bcell, numBCellClones);
		// evaluate
		evaluateBCells(p, bCellClones, patternNo);
		// similarity-affinity replacement (exclude clones)
		LinkedList<DegenerateCell> bCellExclude = new LinkedList<DegenerateCell>();
		for(DegenerateCell c : bCellClones)
		{
			DegenerateCell mostSimilar = CellUtils.getMostSimilarMaskedWithExclusion(c, bcells, bCellExclude);				
			if(c.getScore() < mostSimilar.getScore())
			{
				bcells.remove(mostSimilar);
				bcells.add(c);
				bCellExclude.add(c);
			}
		}
	}
	
	protected void backPropagateTCells(DegenerateCell bcell, DegenerateCell tcell)
	{
		for (DegenerateCell c : tcells)
		{
			CellUtils.forceDecode(c);
		}
		
		// clone t cell
		LinkedList<DegenerateCell> tCellClones = cloningAndMutation(tcell, numTCellClones);
		// evaluate t cell clones against b cell
		evaluateTCells(bcell, tCellClones);
		// similarity-affinity replacement (exclude clones)
		LinkedList<DegenerateCell> tCellExclude = new LinkedList<DegenerateCell>();
		for(DegenerateCell c : tCellClones)
		{
			CellUtils.forceDecode(c);
			
			DegenerateCell mostSimilar = CellUtils.getMostSimilarMaskedWithExclusion(c, tcells, tCellExclude);				
			if(c.getScore() < mostSimilar.getScore())
			{
				tcells.remove(mostSimilar);
				tcells.add(c);
				tCellExclude.add(c);
			}
		}
	}

	@Override
	protected LinkedList<CellSet> internalExecuteEpoch(Problem problem, LinkedList<CellSet> cp)
	{
		MediatedPatternRecognition p = (MediatedPatternRecognition) problem;			
		int numSubProblems = p.getNumInfections();		
		Cell [] bmus = new Cell[numSubProblems];		
		
		// process each sub problem
		for (int i = 0; i < numSubProblems; i++)
		{
			bmus[i] = exposure(p, i);
		}		
		
		// create a cell set
		LinkedList<CellSet> nextgen = new LinkedList<CellSet>();
		nextgen.add(new CellSet(bmus));
		return nextgen;
	}

	@Override
	protected void internalPostEvaluation(Problem problem, LinkedList<CellSet> oldPopulation, LinkedList<CellSet> newPopulation)
	{}

	@Override
	public void validateConfiguration() throws InvalidConfigurationException
	{}

	@Override
	public String getName()
	{
		return "TopDown Random";
	}

	public long getSeed()
	{
		return seed;
	}

	public void setSeed(long seed)
	{
		this.seed = seed;
	}
}
