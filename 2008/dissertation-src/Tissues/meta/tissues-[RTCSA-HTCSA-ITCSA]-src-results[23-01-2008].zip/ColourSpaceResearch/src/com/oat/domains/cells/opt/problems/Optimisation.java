/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006, 2007  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.cells.opt.problems;

import java.util.Random;

import com.oat.AlgorithmRunException;
import com.oat.InitialisationException;
import com.oat.InvalidConfigurationException;
import com.oat.Problem;
import com.oat.Solution;
import com.oat.SolutionEvaluationException;
import com.oat.domains.cells.mediatedpattrec.CellUtils;
import com.oat.domains.cells.opt.Cell;
import com.oat.domains.cells.opt.DegenerateCell;
import com.oat.domains.cfo.CFOProblemInterface;
import com.oat.domains.cfo.CFOSolution;
import com.oat.utils.AlgorithmUtils;
import com.oat.utils.ArrayUtils;
import com.oat.utils.BinaryDecodeMode;
import com.oat.utils.BitStringUtils;
import com.oat.utils.RandomUtils;

/**
 * Description: Optimisation Problem 
 *  
 * Date: 30/10/2007<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class Optimisation extends Problem implements CFOProblemInterface
{
	// config
	protected long seed = 99;
	protected BinaryDecodeMode decodeMode = BinaryDecodeMode.GrayCode;
		
	// data
	protected double [] goalcoordinate;
	protected boolean [] bitstring;
	
	public final static double [][] minmax = new double [][]{{0,1},{0,1},{0,1}};
	
	

	@Override
	public void checkSolutionForSafety(Solution solution)
			throws SolutionEvaluationException
	{
		if(solution instanceof Cell)
		{
			Cell c = (Cell) solution;
			if(c.getData().length != bitstring.length)
			{
				throw new SolutionEvaluationException("String length "+c.getData().length+" does not match expected "+bitstring.length+".");
			}
		}
		else if(solution instanceof CFOSolution)
		{
			checkSolutionForSafety(((CFOSolution)solution).getCoordinate());
		}
		else
		{
			throw new SolutionEvaluationException("Unknown type: " + solution.getClass().getName());
		}		
	}
	
	public void checkSolutionForSafety(double [] v)
		throws SolutionEvaluationException
	{
        if(v.length < getDimensions())
        {
            throw new AlgorithmRunException("Solution coordinate does cont contain the desired number of dimensions " + getDimensions());
        }
        
        double [][] minmax = getMinmax();
        for (int i = 0; i < getDimensions(); i++)
        {
            if(!AlgorithmUtils.inBounds(v[i], minmax[i][0], minmax[i][1]))
            {
                throw new AlgorithmRunException("Unable to evaluate, coordinate is out of function bounds (dimension ["+i+"])" +" val["+v[i]+"] max["+minmax[i][0]+"], val["+v[i]+"], max["+minmax[i][1]+"].");
            }
        }
	}

	@Override
	public void cleanupAfterRun() throws InitialisationException
	{
		
	}

	@Override
	public void initialiseBeforeRun() throws InitialisationException
	{
		Random rand = new Random(seed);
		
		boolean [] b = RandomUtils.randomBitString(rand, 64*3);
		initialiseBeforeRunManually(b);
		//goalcoordinate = BitStringUtils.decode(decodeMode, bitstring, minmax);
	}
	
	public void initialiseBeforeRunManually(boolean [] aBitstring)
	{
		bitstring = aBitstring;
		goalcoordinate = BitStringUtils.decode(decodeMode, bitstring, minmax);
	}
	

	@Override
	public boolean isMinimization()
	{
		return true;
	}
	
	public double costCell(Cell solution)
	{
		return problemSpecificCost(solution);
	}
	
	public double costCell(DegenerateCell solution)
	{
		DegenerateCell c = (DegenerateCell) solution; 
		// check if already decoded
		if(c.getDecodedData() == null)
		{
			// decode will make sure the cell has enough bits!
			double [] data = BitStringUtils.decode(decodeMode, c.getData(), minmax);
			c.setDecodedData(data);
		}
		return AlgorithmUtils.euclideanDistance(c.getDecodedData(), goalcoordinate);
	}
	
	public double costCellHamming(Cell solution)
	{
		return BitStringUtils.hammingDistance(solution.getData(), bitstring);
	}

	@Override
	protected double problemSpecificCost(Solution solution)
			throws SolutionEvaluationException
	{
		if(solution instanceof CFOSolution)
		{
			return AlgorithmUtils.euclideanDistance(((CFOSolution)solution).getCoordinate(), goalcoordinate);
		}
		else if(solution instanceof Cell)
		{			
			Cell c = (Cell) solution; 
			// check if already decoded
			if(c.getDecodedData() == null)
			{
				// decode will make sure the cell has enough bits!
				double [] data = BitStringUtils.decode(decodeMode, c.getData(), minmax);
				c.setDecodedData(data);
			}
			return AlgorithmUtils.euclideanDistance(c.getDecodedData(), goalcoordinate);
		}
		
		throw new SolutionEvaluationException("Unsupported type: " + solution.getClass().getName());
	}
	
	
	
	
	public void costSubStructure(DegenerateCell partialSolution)
		throws SolutionEvaluationException
	{
		boolean [] data = partialSolution.getData();
		boolean [] mask = partialSolution.getMask();
		
		// number of differences
		int count = 0;
		
		for (int i = 0; i < mask.length; i++)
		{
			if(mask[i])
			{
				// check for match
				if(data[i] != bitstring[i])
				{
					count++;
				}
			}
		}
		
		// store
		partialSolution.evaluated(count);
	}
	
	public void costSingleFeature(Cell partialSolution)
		throws SolutionEvaluationException
	{
		if(!AlgorithmUtils.inBounds(partialSolution.getGene(), 0, 2))
		{
			throw new SolutionEvaluationException("Expect gene value to be [0,2]");
		}
		
		// decode the single value
		if(partialSolution.getDecodedData() == null)
		{
			// decode will make sure the cell has enough bits!
			double [] data = BitStringUtils.decode(decodeMode, partialSolution.getData(), new double[][]{minmax[partialSolution.getGene()]});
			// validate
			//checkSolutionForSafety(data);
			// store
			partialSolution.setDecodedData(data);
		}
		
		double score = AlgorithmUtils.euclideanDistance(partialSolution.getDecodedData(), new double[]{goalcoordinate[partialSolution.getGene()]});
		partialSolution.evaluated(score);
	}
	
	
	public void costCellByComponent(Cell solution, int componentNumber)
	{
		if(!AlgorithmUtils.inBounds(componentNumber, 0, 2))
		{
			throw new SolutionEvaluationException("Invalid component number "+componentNumber+", expect the following 0=R, 1=B, 2=G");
		}
		
		// decode all components as required
		CellUtils.forceDecode(solution);
		// calculate difference for single component
		double diff = solution.getDecodedData()[componentNumber] - goalcoordinate[componentNumber];
		// calculate score
		double score = Math.sqrt(diff * diff);
		// credit assignment
		solution.evaluated(score);
	}
	

	@Override
	protected void validateConfigurationInternal()
			throws InvalidConfigurationException
	{
		if(decodeMode == null)
		{
			throw new InvalidConfigurationException("Decode mode not set.");
		}
	}

	@Override
	public String getName()
	{
		return "Colour Space Optimisation";
	}

	@Override
	public int getBitPrecision()
	{
		return 64;
	}

	@Override
	public BinaryDecodeMode getDecodeMode()
	{
		return decodeMode;
	}

	@Override
	public int getDimensions()
	{
		return 3;
	}

	@Override
	public CFOSolution[] getGlobalOptima()
	{
		return new CFOSolution[]{new CFOSolution(ArrayUtils.copyArray(goalcoordinate))};
	}

	@Override
	public double[][] getMinmax()
	{
		return minmax;
	}
	

	@Override
	public boolean isToroidal()
	{
		return false;
	}

	public long getSeed()
	{
		return seed;
	}

	public void setSeed(long seed)
	{
		this.seed = seed;
	}
	
	@Override
    public boolean isUserConfigurable()
    {
    	return true;
    }
	
	public boolean [] getBitString()
	{
		return bitstring;
	}

	public double[] getGoalcoordinate()
	{
		return goalcoordinate;
	}
	
	
}
