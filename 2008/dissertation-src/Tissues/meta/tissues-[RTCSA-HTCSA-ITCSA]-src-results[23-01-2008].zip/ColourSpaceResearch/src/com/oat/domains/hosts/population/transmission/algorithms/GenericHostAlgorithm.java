/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006, 2007  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.hosts.population.transmission.algorithms;

import java.util.LinkedList;
import java.util.Random;

import com.oat.Algorithm;
import com.oat.EpochAlgorithm;
import com.oat.InvalidConfigurationException;
import com.oat.Problem;
import com.oat.domains.cells.network.algorithms.Tissue;
import com.oat.domains.cells.opt.Cell;
import com.oat.domains.cells.opt.problems.Optimisation;
import com.oat.domains.cells.patrec.CellSet;
import com.oat.domains.hosts.HostAlgorithm;
import com.oat.domains.tissues.ExposureListener;
import com.oat.domains.tissues.InfectionProblem;

/**
 * Description: 
 *  
 * Date: 10/01/2008<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public abstract class GenericHostAlgorithm extends EpochAlgorithm<CellSet> 
	implements HostAlgorithm
{
	protected LinkedList<ExposureListener> listeners = new LinkedList<ExposureListener>();
	// config
	protected int numHosts = 10;
	protected long seed = 1;
	protected int repertoireSize = 50;
	protected int selectionSize = 1;
	protected int cloneSize = 5;

	// data
	protected SingleRepertoire [] hosts;
	protected Random rand;	
	
	
	public GenericHostAlgorithm()
	{}
	

	
	@Override
	protected LinkedList<CellSet> internalInitialiseBeforeRun(Problem problem)
	{
		rand = new Random(seed);
		// create the population
		hosts = createPopulation(problem);
		return null;
	}	
	
	protected SingleRepertoire [] createPopulation(Problem problem)
	{
		SingleRepertoire [] pop = new SingleRepertoire[numHosts];
		for (int i = 0; i < pop.length; i++)
		{
			// create
			pop[i] = new SingleRepertoire();
			// configure
			pop[i].setSeed(rand.nextLong());
			pop[i].setRepertoireSize(repertoireSize);
			pop[i].setSelectionSize(selectionSize);
			pop[i].setCloningSize(cloneSize);
			// initialise
			pop[i].internalInitialiseBeforeRun(problem);
		}
		
		return pop;
	}
	
	
	public abstract Cell repertoireExposure(InfectionProblem p, int pattNo);
	public abstract void hostInteractions(InfectionProblem p);
	
	
	public CellSet systemExposure(InfectionProblem p)
	{
		int numSubProblems = p.getNumInfections();		
		Cell [] bmus = new Cell[numSubProblems];		
		// process each sub problem
		for (int i = 0; i < numSubProblems; i++)
		{
			bmus[i] = repertoireExposure(p, i);
		}		
		return new CellSet(bmus);
	}
	
	
	@Override
	protected LinkedList<CellSet> internalExecuteEpoch(Problem problem, LinkedList<CellSet> population)
	{
		InfectionProblem p = (InfectionProblem) problem;
		// perform exposure
		LinkedList<CellSet> nextgen = new LinkedList<CellSet>();
		CellSet set = systemExposure(p);
		nextgen.add(set);		
		// do inter-host interactions
		hostInteractions(p);
		
		return nextgen;
	}

	
	public void registerExposureListener(ExposureListener aListener)
	{
		listeners.add(aListener);
	}
	
	protected void triggerExposureEvent(int repNo, Algorithm rep, int patNo, Optimisation pat)
	{
		for(ExposureListener list : listeners)
		{
			list.exposure(repNo, rep, patNo, pat);
		}
	}
	
	public boolean removeExposureListener(ExposureListener aListener)
	{
		return listeners.remove(aListener);
	}


	@Override
	protected void internalPostEvaluation(Problem problem, LinkedList<CellSet> oldPopulation, LinkedList<CellSet> newPopulation)
	{
		for (int i = 0; i < hosts.length; i++)
		{
			hosts[i].internalPostEvaluation(problem, oldPopulation, newPopulation);
		}
	}

	@Override
	public void validateConfiguration() 
		throws InvalidConfigurationException
	{
		// sub repertoire configuration
		if(repertoireSize<=0)
		{
			throw new InvalidConfigurationException("Repertoire size must be > 0.");
		}
		if(selectionSize>repertoireSize)
		{
			throw new InvalidConfigurationException("Selection size must be less than the repertoire size.");
		}
		if(selectionSize<=0)
		{
			throw new InvalidConfigurationException("Selection size must be > 0.");
		}
		if(cloneSize<=0)
		{
			throw new InvalidConfigurationException("Clone size must be > 0.");
		}
		if(cloneSize>repertoireSize)
		{
			throw new InvalidConfigurationException("Clone size must be less than the repertoire size.");
		}
		
		// master repertoire configuration
		if(numHosts<=0)
		{
			throw new InvalidConfigurationException("Number of hosts must be > 0.");
		}
		
		// cannot validate sub-repertoires because they are not created yet
	}

	

	public int getNumHosts()
	{
		return numHosts;
	}

	public void setNumHosts(int numHosts)
	{
		this.numHosts = numHosts;
	}

	public long getSeed()
	{
		return seed;
	}

	public void setSeed(long seed)
	{
		this.seed = seed;
	}

	public int getRepertoireSize()
	{
		return repertoireSize;
	}

	public void setRepertoireSize(int repertoireSize)
	{
		this.repertoireSize = repertoireSize;
	}

	public int getSelectionSize()
	{
		return selectionSize;
	}

	public void setSelectionSize(int selectionSize)
	{
		this.selectionSize = selectionSize;
	}

	public int getCloneSize()
	{
		return cloneSize;
	}

	public void setCloneSize(int cloneSize)
	{
		this.cloneSize = cloneSize;
	}

	public Tissue[] getHosts()
	{
		return hosts;
	}
}
