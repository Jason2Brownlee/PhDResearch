/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006-2008  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.hosts.population.sharing.algorithms;

import java.util.LinkedList;

import com.oat.AlgorithmRunException;
import com.oat.InvalidConfigurationException;
import com.oat.domains.cells.mediatedpattrec.CellUtils;
import com.oat.domains.cells.opt.Cell;
import com.oat.domains.hosts.population.transmission.algorithms.SingleRepertoire;
import com.oat.domains.tissues.InfectionProblem;

/**
 * Description: Host Population Sharing Algorithm (HPSA)
 *  
 * Date: 14/01/2008<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class HostPopulationSharingAlgorithm extends GeneticSharingAlgorithm
{
	protected int numHostsToDoSharing = 1;
	protected int numCellsToShare = 5;
	protected int numHostsToShareTo = 5;

	
	protected LinkedList<SingleRepertoire> selectRandomSetOfHosts(int aNumHosts)
	{
		if(aNumHosts > hosts.length)
		{
			throw new AlgorithmRunException("The desired number of hosts ("+aNumHosts+") exceeds the number of hosts in the population ("+hosts.length+").");
		}
		
		// select hosts to participate
		LinkedList<SingleRepertoire> sharingHosts = new LinkedList<SingleRepertoire>();
		// add all
		for (int i = 0; i < hosts.length; i++)
		{
			sharingHosts.add(hosts[i]);
		}
		// shrink to size
		while(sharingHosts.size() > aNumHosts)
		{
			sharingHosts.remove(rand.nextInt(sharingHosts.size()));
		}
		
		return sharingHosts;
	}
	
	protected LinkedList<Cell> copyRandomCellPool(int poolSize, SingleRepertoire host)
	{
		LinkedList<Cell> cells = new LinkedList<Cell>();
		
		// draw the random sample with reselection
		LinkedList<Cell> repertoire = host.getRepertoire();		
		while(cells.size() < poolSize)
		{
			Cell copy = new Cell(repertoire.get(rand.nextInt(repertoire.size())));
			cells.add(copy);
		}
		
		return cells;
	}
	
	protected void integrateSharedCells(SingleRepertoire host, LinkedList<Cell> cells)
	{
		LinkedList<Cell> repertoire = host.getRepertoire();
		
		for(Cell c : cells)
		{
			// Euclidean similarity tournament for competition
			Cell other = CellUtils.getMostSimilarEuclideanWithExclusion(c, host.getRepertoire(), cells);			
			// random replacement
			//Cell other = repertoire.get(rand.nextInt(repertoire.size()));
			
			repertoire.remove(other);
			repertoire.add(c);
		}
	}
	
	protected void shareCells(SingleRepertoire host, LinkedList<SingleRepertoire> recpipientHosts)
	{
		for(SingleRepertoire receptHost : recpipientHosts)
		{
			// select a pool of cells from the host
			LinkedList<Cell> pool = copyRandomCellPool(numCellsToShare, host);
			// integrate into the recept host
			integrateSharedCells(receptHost, pool);
		}
	}
	
	@Override
	protected void doSharing(InfectionProblem p)
	{
		// check for enabled 
		if(numHostsToDoSharing > 0)
		{
			// select sharing hosts
			LinkedList<SingleRepertoire> sharingHosts = selectRandomSetOfHosts(numHostsToDoSharing);
			// do sharing 
			for(SingleRepertoire host : sharingHosts)
			{
				// select hosts to share with
				LinkedList<SingleRepertoire> recpipientHosts = selectRandomSetOfHosts(numHostsToShareTo);
				// perform sharing
				shareCells(host, recpipientHosts);
			}
		}
	}

	@Override
	public String getName()
	{
		return "Host Population Sharing Algorithm (HPSA)";
	}
	
	@Override
	public void validateConfiguration() 
		throws InvalidConfigurationException
	{
		super.validateConfiguration();
		
		if(numHostsToDoSharing < 0 || numHostsToDoSharing>numHosts)
		{
			throw new InvalidConfigurationException("numHostsToDoSharing must be >= and <= numhosts="+numHosts);
		}
		// check for enabled
		if(numHostsToDoSharing != 0)
		{
			if(numCellsToShare < 1 || numCellsToShare>repertoireSize)
			{
				throw new InvalidConfigurationException("numCellsToShare must be >= 1 and <= repertoireSize="+repertoireSize);
			}
			if(numHostsToShareTo<1 || numHostsToShareTo>numHosts)
			{
				throw new InvalidConfigurationException("numHostsToShareTo must be >= 1 and <= numHosts="+numHosts);
			}
		}		
	}	

	public int getNumHostsToDoSharing()
	{
		return numHostsToDoSharing;
	}

	public void setNumHostsToDoSharing(int numHostsToDoSharing)
	{
		this.numHostsToDoSharing = numHostsToDoSharing;
	}

	public int getNumCellsToShare()
	{
		return numCellsToShare;
	}

	public void setNumCellsToShare(int numCellsToShare)
	{
		this.numCellsToShare = numCellsToShare;
	}

	public int getNumHostsToShareTo()
	{
		return numHostsToShareTo;
	}

	public void setNumHostsToShareTo(int numHostsToShareTo)
	{
		this.numHostsToShareTo = numHostsToShareTo;
	}	
}
