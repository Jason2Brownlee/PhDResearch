/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006-2008  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.hosts.generation.maternal.algorithms;

import java.util.LinkedList;

import com.oat.InvalidConfigurationException;
import com.oat.Problem;
import com.oat.domains.cells.patrec.CellSet;
import com.oat.domains.hosts.population.transmission.algorithms.MinimalHostPopulationAlgorithm;
import com.oat.domains.hosts.population.transmission.algorithms.SingleRepertoire;
import com.oat.domains.tissues.InfectionProblem;

/**
 * Description: 
 *  
 * Date: 15/01/2008<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class MinimalHostGenerationalAlgorithm extends MinimalHostPopulationAlgorithm
{
	// config
	protected int numEpochsPerGeneration = 100;

	// state
	protected int epochsSinceLasterGeneration;
	protected LinkedList<GenerationalChangeListener> generationListeners;
	
	public MinimalHostGenerationalAlgorithm()
	{
		generationListeners = new LinkedList<GenerationalChangeListener>();
	}
	
	public void registerGenerationalChangeListener(GenerationalChangeListener l)
	{
		generationListeners.add(l);
	}
	
	public boolean removeGenerationalChangeListener(GenerationalChangeListener l)
	{
		return generationListeners.remove(l);
	}
	
	public void triggerGenerationalChangeEvent(SingleRepertoire [] oldGeneration, SingleRepertoire [] newGeneration)
	{
		for(GenerationalChangeListener l : generationListeners)
		{
			l.generationChange(oldGeneration, newGeneration);
		}
	}
	
	@Override
	protected LinkedList<CellSet> internalInitialiseBeforeRun(Problem problem)
	{		
		// reset
		epochsSinceLasterGeneration = 0;		
		// do parent init
		return super.internalInitialiseBeforeRun(problem);
	}
	
	
	@Override
	public void hostInteractions(InfectionProblem p)
	{
		// check for a generational change
		if(++epochsSinceLasterGeneration >= numEpochsPerGeneration)
		{
			// perform generational change
			doGenerationalChange(p);
			// reset the epochs since laster generational change
			epochsSinceLasterGeneration = 0;
		}
	}
	
	protected void doGenerationalChange(InfectionProblem problem)
	{
		// remember old population
		SingleRepertoire [] oldGeneration = hosts;		
		// create new hosts
		hosts = createPopulation((Problem)problem);		
		// trigger a change event
		triggerGenerationalChangeEvent(oldGeneration, hosts);
	}	
	


	@Override
	public String getName()
	{
		return "Minimal Host Generational Algorithm";
	}
	
	
	@Override
	public void validateConfiguration() 
		throws InvalidConfigurationException
	{
		super.validateConfiguration();
		
		if(numEpochsPerGeneration <= 0)
		{
			throw new InvalidConfigurationException("numEpochsPerGeneration must be > 0");
		}
	}
	

	public int getNumEpochsPerGeneration()
	{
		return numEpochsPerGeneration;
	}

	public void setNumEpochsPerGeneration(int numEpochsPerGeneration)
	{
		this.numEpochsPerGeneration = numEpochsPerGeneration;
	}
}
