/*
Optimization Algorithm Toolkit (OAT)
http://sourceforge.net/projects/optalgtoolkit
Copyright (C) 2006, 2007  Jason Brownlee

OAT is free software; you can redistribute it and/or modify it under the terms
of the GNU Lesser General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any 
later version.

OAT is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
more details.

You should have received a copy of the GNU Lesser General Public License 
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Jason Brownlee
Project Lead
*/
package com.oat.domains.hosts.generation.maternal.experiments;

import java.util.LinkedList;

import com.oat.Domain;
import com.oat.RunProbe;
import com.oat.StopCondition;
import com.oat.domains.cells.mediatedpattrec.probes.AEEuclidean;
import com.oat.domains.cells.opt.stopcondition.FoundOptimaOrMaxEpochs;
import com.oat.domains.hosts.generation.maternal.MaternalDomain;
import com.oat.domains.hosts.generation.maternal.algorithms.parentchild.ParentChildInfectionLarge;
import com.oat.domains.hosts.generation.maternal.algorithms.parentchild.ParentChildInfectionMedium;
import com.oat.domains.hosts.generation.maternal.algorithms.parentchild.ParentChildInfectionSmall;
import com.oat.domains.hosts.generation.maternal.algorithms.parentchild.ParentChildPointLarge;
import com.oat.domains.hosts.generation.maternal.algorithms.parentchild.ParentChildPointMedium;
import com.oat.domains.hosts.generation.maternal.algorithms.parentchild.ParentChildPointSmall;
import com.oat.domains.hosts.generation.maternal.algorithms.parentchild.ParentChildRandomLarge;
import com.oat.domains.hosts.generation.maternal.algorithms.parentchild.ParentChildRandomMedium;
import com.oat.domains.hosts.generation.maternal.algorithms.parentchild.ParentChildRandomSmall;
import com.oat.domains.hosts.generation.maternal.algorithms.parentchild.ParentChildSymmetricLarge;
import com.oat.domains.hosts.generation.maternal.algorithms.parentchild.ParentChildSymmetricMedium;
import com.oat.domains.hosts.generation.maternal.algorithms.parentchild.ParentChildSymmetricSmall;
import com.oat.domains.hosts.population.transmission.algorithms.minimal.HostMinimalInfection;
import com.oat.domains.hosts.population.transmission.algorithms.minimal.HostMinimalPoint;
import com.oat.domains.hosts.population.transmission.algorithms.minimal.HostMinimalRandom;
import com.oat.domains.hosts.population.transmission.algorithms.minimal.HostMinimalSymmetric;
import com.oat.domains.hosts.population.transmission.probes.AverageHostDiversity;
import com.oat.domains.hosts.population.transmission.probes.AverageHostError;
import com.oat.domains.hosts.population.transmission.probes.InterHostDiversity;
import com.oat.domains.tissues.recirulation.problems.ICSP_10;
import com.oat.experimenter.ExperimentalRun;
import com.oat.experimenter.ExperimentalRunMatrix;
import com.oat.experimenter.TemplateExperiment;

/**
 * Description: 
 *  
 * Date: 14/01/2008<br/>
 * @author Jason Brownlee 
 *
 * <br/>
 * <pre>
 * Change History
 * ----------------------------------------------------------------------------
 * 
 * </pre>
 */
public class ComparisonStudy2 extends TemplateExperiment
{
	public static void main(String[] args)
	{
		new ComparisonStudy2().run();
	}

	@Override
	public LinkedList<ExperimentalRun> createRunList()
	{
		ExperimentalRunMatrix matrix = new ExperimentalRunMatrix();
		// 30 repeats
		matrix.setRepeats(30);
		// problems
		matrix.addProblem(new ICSP_10());
		// random - infection
		
		
		// random point
		
		
		// random random
		
		
		// random symmetric
		

		return matrix.toRunList();
	}

	@Override
	public Domain getDomain()
	{
		return new MaternalDomain();
	}

	@Override
	public String getExperimentDescription()
	{
		return "Assess various sharing schemes on the Maternal Immunity Sharing Algorithm, study2";
	}

	@Override
	public String getExperimentName()
	{
		return "HostMater2";
	}

	@Override
	public StopCondition getStopCondition()
	{
		return new FoundOptimaOrMaxEpochs(1000);
	}
	
	@Override
	public LinkedList<RunProbe> getReportingStatistics()
	{
		// select statistics to report on
		LinkedList<RunProbe> reportStats = new LinkedList<RunProbe>();
		// system level
		reportStats.add(new InterHostDiversity());
		reportStats.add(new AEEuclidean());
		// host level
		reportStats.add(new AverageHostDiversity());
		reportStats.add(new AverageHostError());
		
		return reportStats;
	}
	
	@Override
	public boolean performAnalysys()
	{
		return true;
	}
}
