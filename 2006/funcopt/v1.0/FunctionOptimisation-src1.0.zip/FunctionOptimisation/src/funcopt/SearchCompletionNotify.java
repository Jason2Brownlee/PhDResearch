
package funcopt;

public interface SearchCompletionNotify
{
    void searchComplete(Solution best);
}
