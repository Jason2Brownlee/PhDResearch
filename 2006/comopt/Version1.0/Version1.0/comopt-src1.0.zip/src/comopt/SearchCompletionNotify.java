
package comopt;

public interface SearchCompletionNotify
{
    void searchComplete(Solution best);
}
